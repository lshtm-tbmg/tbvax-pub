optimize.params=function(Ti){ # for example the transition matrix ...
  M.list = Ti$parameter.matrices
  n = length(M.list)
  if (n==1)
    return(Ti)
  M = M.list[[1]]
  n.elements = nrow(M)*ncol(M)
  uniq = 0*(1:n)+T
  uniq[1]=F
  for (i in 2:length(M.list)){
    if (sum(M.list[[i]]==M)==n.elements)
      uniq[i]=F
    else
      return(Ti)
  }
  if (sum(uniq)==0){
    Ti$parameter.matrices = list(M)
    Ti$age.groups = Ti$age.groups[1]
    Ti$age.from.index = Ti$age.from.index[1]
    Ti$age.thru.index = Ti$age.thru.index[n]
    return(Ti)
  }
}


fractions.by.stage.at.birth=function(p){
  n = p$nVXaSESRISKHIVTB
  c = length(p$DIMNAMES)
  M = matrix(0,n,c)
  colnames(M)=p$DIMNAMES
  
  ind = calc.indices.for.dim(p,"VXa")
  for (i in 1:p$nVXa)
    M[,"VXa"][ind==i]=p$iVXa[i]
  
  ind = calc.indices.for.dim(p,"SES")
  for (i in 1:p$nSES)
    M[,"SES"][ind==i]=p$iSES[i]
  
  ind = calc.indices.for.dim(p,"RISK")
  for (i in 1:p$nRISK)
    M[,"RISK"][ind==i]=p$iRISK[i]
  
  ind = calc.indices.for.dim(p,"HIV")
  for (i in 1:p$nHIV)
    M[,"HIV"][ind==i]=p$iHIV[i]
  
  ind = calc.indices.for.dim(p,"TB")
  for (i in 1:p$nTB)
    M[,"TB"][ind==i]=p$iTB[i]
  
  x = M[,1]
  for (i in 2:c)
    x = x * M[,i]
  x
}



replace.NAs.by=function(nodes,attrib,replace=0,first=NA,n=NA){
  v = as.numeric(xml_attr(nodes,attrib))
  if (sum(is.na(v))==n){
    v = rep(0.,n)
    if (!is.na(first))
      v[1]=first
  }else{
    v[is.na(v)]=0.
  }
  v
}

check.sum.to.1 = function(v){
  if (abs(sum(v)-1.0)>1e-6)
    stop(paste("values of ",names(v)," should add up to 1.0",sep=""))
  v
}



create.approx.fun.for.dataframe=function(df){
  x = as.integer(rownames(df))
  y = 1:nrow(df)
  approxfun(x,y,rule=2)
}

get.deathrate=function(p, t){
  return(p$deathrate[p$deathfn(t),])
}

create.approx.fun=function(row, df=NULL){
  if (!is.null(df)){
    sel = is.na(df$VXa) & is.na(df$SES) & is.na(df$RISK) & is.na(df$HIV) & is.na(df$age.group)
    df  = df[sel,c("name","value")]
    eval(parse(text = paste0(df$name,"=",df$value)))
    x = as.numeric(unlist(strsplit(row["times" ],",")))
    values = unlist(strsplit(row["values"],","))
    y = 0 * x
    for (i in 1:length(y)){
      eval(parse(text = paste0("y[i]=",values[i])))
    }
    y = as.numeric(y)
    return(approxfun(x,y,rule=2))
  }else{
  x = as.numeric(unlist(strsplit(row["times" ],",")))
  y = as.numeric(unlist(strsplit(row["values"],",")))
  return(approxfun(x,y,rule=2))
  }
}

calc.birthrate = function(fname=NA, countrycode=NA){
  if (!is.na(countrycode)){
    pop = read.csv(fname,header=F, fileEncoding = 'UTF-8-BOM')
    pop = pop[pop[,1]==countrycode,]
    nr  = nrow(pop)
    nc  = ncol(pop)
    x   = pop[2:nr,2]
    y   = pop[2:nr,3]/rowSums(pop[1:(nr-1),3:102])
    return(approxfun(x,y,rule=2))
  }
  return(NULL)
}

scale.population = function(pop=NA,fname=NA){
    if (!is.na(fname)){
      sumpop        = sum(pop)
      pop           = 0*pop
      pop.fracs     = as.matrix(read.delim(file=fname,sep="\t",header=T,stringsAsFactors = F, row.names=1, fileEncoding = 'UTF-8-BOM'))
      assert_that(dim(pop)[2]==dim(pop.fracs)[2])
      sum.pop.fracs = sum(pop.fracs)
      if (sum.pop.fracs<0.99 | sum.pop.fracs>1.01)
        warning(paste("The file ",fname, " does not appear to contain fractions adding up to 1.0 ?",sep=""))
      rowsel = rownames(pop) %in% rownames(pop.fracs)
      pop[rowsel,] = pop.fracs
      return(pop * sumpop)
    }
  NULL
}

seed.initial.population=function(parms,VXa.stage.nr=1, SES.stage.nr=1, RISK.stage.nr=1,HIV.stage.nr=1, df){
  if (!is.null(df)){
    for (i in 1:nrow(df)){
      row = calc.index.by.nr(parms,VXa.stage.nr,SES.stage.nr, RISK.stage.nr, HIV.stage.nr, which(parms$TB==df$stage[i]))
      range = parms$AGES >= df$age.from[i] & parms$AGES <= df$age.thru[i]
      parms$y.ini[row,range]=df$n[i]
    }
  }
}
init.constants = function(p,xml){
  p$xml = xml
  with(p,{
    DAYSPERYEAR = 365.2425
    TB   = xml_attr(xml_find_all(xml$doc,"//TB/TB.stages/stage"),"name")     ; nTB   = length(TB) 
    HIV  = xml_attr(xml_find_all(xml$doc,"//HIV/HIV.stages/stage"),"name")   ; nHIV  = length(HIV) 
    RISK = xml_attr(xml_find_all(xml$doc,"//RISK/RISK.stages/stage"),"name") ; nRISK = length(RISK) 
    SES  = xml_attr(xml_find_all(xml$doc,"//SES/SES.stages/stage"),"name")   ; nSES  = length(SES) 
    VXa  = xml_attr(xml_find_all(xml$doc,"//VXa/VXa.stages/stage"),"name")   ; nVXa  = length(VXa)

    iTB   = check.sum.to.1(replace.NAs.by(xml_find_all(xml$doc,"//TB/TB.stages/stage"),"fraction.at.birth",0,1,nTB))  
    iHIV  = check.sum.to.1(replace.NAs.by(xml_find_all(xml$doc,"//HIV/HIV.stages/stage"),"fraction.at.birth",0,1,nHIV))     
    iRISK = check.sum.to.1(replace.NAs.by(xml_find_all(xml$doc,"//RISK/RISK.stages/stage"),"fraction.at.birth",0,1,nRISK))     
    iSES  = check.sum.to.1(replace.NAs.by(xml_find_all(xml$doc,"//SES/SES.stages/stage"),"fraction.at.birth",0,1,nSES))     
    iVXa  = check.sum.to.1(replace.NAs.by(xml_find_all(xml$doc,"//VXa/VXa.stages/stage"),"fraction.at.birth",0,1,nVXa))     

    # NOTE : the order below VXa - SES - RISK - HIV - TB should NEVER be changed !!!
    
    DIMNAMES     = c("VXa","SES","RISK","HIV","TB")
    DIMNAMESLIST = list(VXa=VXa,SES=SES,RISK=RISK,HIV=HIV,TB=TB)
    DIMLENGTHS   = c(nVXa,nSES,nRISK,nHIV,nTB)
    names(DIMLENGTHS)=DIMNAMES
    
    HIVTB = NULL ; RISKHIVTB = NULL ; SESRISKHIVTB = NULL ; VXaSESRISKHIVTB = NULL;
    nHIV  = length(HIV)
    for (i in 1:nHIV) 
      HIVTB = c(HIVTB,paste(HIV[i],TB,sep="-")) 
    nHIVTB  = length(HIVTB)
    for (i in 1:nRISK) 
      RISKHIVTB = c(RISKHIVTB,paste(RISK[i],HIVTB,sep="-")) 
    nRISKHIVTB  = length(RISKHIVTB)
    for (i in 1:nSES)  
      SESRISKHIVTB = c(SESRISKHIVTB,paste(SES[i],RISKHIVTB,sep="-"))
    nSESRISKHIVTB  = length(SESRISKHIVTB)
    for (i in 1:nVXa)  
      VXaSESRISKHIVTB = c(VXaSESRISKHIVTB,paste(VXa[i],SESRISKHIVTB,sep="-"))
    nVXaSESRISKHIVTB  = length(VXaSESRISKHIVTB)

    all.dim.names = list(VXa=dim.names.for.all(environment(),"VXa"),
                         NULL,
                         NULL,
                         HIV=dim.names.for.all(environment(),"HIV"),
                         NULL)

    # AGES  = c(0:79,80,90); names(AGES) = paste("A",AGES,sep="") ; nAGES = length(AGES) 

    ALIVE     = !grepl(".*dead.*",VXaSESRISKHIVTB,ignore.case=F)
    
    DEATH.matrix = create.death.matrix(environment())
  })
}

init.parameters=function(xmlfile=NA,xmlrunfile=NA, params=NULL){
  assert <<- T
  if (is.null(params)){
    run.params = parse.run.spec(xmlrunfile)
    p = new.env()
    init.constants(p,xml=read.xml(xmlfile,"/TB.Vx.model.inputfile"))
  }else{
    p = params
  }
  with(p,{
    
    eval(parse(text=paste("AGES=c(",xml_attr(xml_find_all(xml$doc,"//ages"),"lower.limits"),")",sep="")))
    # AGES  = c(0:79,80,90)
    names(AGES) = paste("A",AGES,sep="") ; nAGES = length(AGES) 
    xmlfile = xmlfile
    xmlrunfile = xmlrunfile
    run.params = run.params
    h = run.params$dt 
    years = run.params$start+cumsum(c(0,rep(h,(run.params$stop-run.params$start)/h)))
    
    final.population.as.fraction = run.params$final.population.as.fraction
    
    detailed.output = run.params$detailed.output
    incidence.output = run.params$incidence.output
    if (!is.null(incidence.output)){
      inci.output.years    = incidence.output$years
      inci.output.recorded = rep(F,length(inci.output.years)) 
    }
    
    aging.matrix = create.aging.matrix(environment())
    
    at.birth = fractions.by.stage.at.birth(environment())

    deathrate = NULL
    birthrate = NULL  
    birthrate.is.number = run.params$birthrate.is.number
    if (!is.na(run.params$population.csv)){
      y.ini = read.population(p           = environment(),
                              rownms      = p$VXaSESRISKHIVTB, 
                              colnms      = p$AGES, 
                              fname       = run.params$population.csv, 
                              countrycode = run.params$countrycode, 
                              year        = run.params$start)
      
      if (run.params$birthrate.from.data){
        birthrate = calc.birthrate(fname=run.params$population.csv, countrycode = run.params$countrycode)
      }
      if (run.params$deathrate.from.data){
        deathrate = deathrate.from.data(environment(),fname=run.params$population.csv, countrycode=run.params$countrycode)
      }
    }else if (!is.na(run.params$population.fractions)){
      y.ini = create.empty.population(rownms = p$VXaSESRISKHIVTB, colnms = p$AGES) 
      y.ini[1,1] = run.params$population.total # seems weird but should work
      y.ini = scale.population(pop = y.ini, fname = run.params$population.fractions) 
      
    }
    N.ALIVE = sum(y.ini)
    if (is.null(deathrate))
      deathrate     = read.mortality(environment(),fname=run.params$deathrate.txt)
    deathfn       = create.approx.fun.for.dataframe(deathrate)
    if (is.null(birthrate))
        birthrate = run.params$birthrate    

    if (!is.na(run.params$contact.matrix.txt)){
      # contacts.M.original = Matrix(expand.age.matrix(environment(),read.contact.matrix(run.params$contact.matrix.txt)))
      # contacts.M = t(contacts.M.original)
      contacts.M = Matrix(expand.contact.matrix(environment(),read.contact.matrix(run.params$contact.matrix.txt)))
      contacts.MplustM = contacts.M+t(contacts.M)
      update.contact.matrix(environment(),colSums(y.ini[ALIVE,]))
    }else{
      contacts = matrix(0,nAGES,nAGES)
      rownames(contacts) = colnames(contacts) = names(AGES)
    }
    
    seed.initial.population(environment(),df=run.params$seeded.infections)
    
    inci = list()
    
    for (i in seq_along(run.params$incidence.files)){
        inci[[i]] = init.incidence(environment(), fname=run.params$incidence.files[[i]], countrycode  = run.params$countrycode)
    }

    Ti    = init.parameters.from.xml(environment(), xmlpath=     "//TB/TB.progression", 
                                     xmlparameter="TB.parameter", 
                                     xmltransitions=xml_find_all(xml$doc,"//TB/TB.progression/transition.matrix/transition"))
    
    Ti = optimize.params(Ti) # for example the transition matrix ...
    
    nodeset = xml_find_all(xml$doc,"//TB/TB.progression/treatment.matrix")
    
    
    if (length(nodeset)>0){
      Tr    = list()
      for (i in 1:length(nodeset)){
        Tr[[i]] = init.parameters.from.xml(environment(), xmlpath=        "//TB/TB.progression",
                                       xmlparameter=   "TB.parameter",
                                       xmltransitions= xml_find_all(nodeset[i],"transition"),
                                       xmltimedparams= xml_find_all(nodeset[i],"multiplier"))
        names(Tr)[i]=xml_attr(nodeset[i],"name")
      }
      #Tr = optimize.params(Tr)
    }else
      Tr = NULL
    
    rm(nodeset)
    # NOTE: TB death is included in the transition rates (mu_C and mu_S for subclinical and clinical)
    Tm    = init.parameters.from.xml(environment(), xmlpath=        "//TB/TB.transmission",
                                     xmlparameter=   "TB.parameter",
                                     xmltransitions= xml_find_all(xml$doc,"//TB/TB.transmission/transition.matrix/transition"),
                                     xmltimedparams= xml_find_all(xml$doc,"//TB/TB.transmission/contact.rate.multiplier"))
    Tm = optimize.params(Tm) 
    
    Infc  = init.parameters.from.xml(environment(), xmlpath=    "//TB/TB.infectivity",
                                     xmlparameter   = "TB.parameter",
                                     xmltransitions = xml_find_all(xml$doc,"//TB/TB.infectivity/infectivity.matrix/infectivity"),
                                     values=T)  
    Infc = optimize.params(Infc) 
    
    PROGRESSION = list()
    
    HIVp = RISKp = SESp = VXAp = NULL
    
    if (nHIV>1){
      xmlpath = "//HIV/HIV.progression"
      if (length(xml_find_all(xml$doc,xmlpath))>0){
        HIVp  = init.parameters.from.xml(environment(),xmlpath,xmlparameter="HIV.parameter",xmlmatrix="transition.matrix/transition")
        HIVp = optimize.params(HIVp) 
        PROGRESSION$HIV=HIVp
      }
    }
    if (nRISK>1){
      xmlpath = "//RISK/RISK.progression"
      if (length(xml_find_all(xml$doc,xmlpath))>0){
        RISKp = init.parameters.from.xml(environment(),xmlpath,xmlparameter="RISK.parameter",xmlmatrix="transition.matrix/transition")
        PROGRESSION$RISK=RISKp
      }
    } 
    if (nSES>1){
      xmlpath = "//SES/SES.progression"
      if (length(xml_find_all(xml$doc,xmlpath))>0){
        SESp  = init.parameters.from.xml(environment(), xmlpath,xmlparameter= "SES.parameter",xmlmatrix="transition.matrix/transition")
        PROGRESSION$SES=SESp
      }
    }
    if (nVXa>1){
      xmlpath = "//VXa/VXa.progression"
      if (length(xml_find_all(xml$doc,xmlpath))>0){
        VXAp  = init.parameters.from.xml(environment(), xmlpath,xmlparameter= "VXa.parameter",xmlmatrix="transition.matrix/transition")
        PROGRESSION$VXa=VXAp
      }
    }
  })
  p
}

