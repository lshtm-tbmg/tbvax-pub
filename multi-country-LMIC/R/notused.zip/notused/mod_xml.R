
read.xml.file = function(xmlfile){
  assert_that(is.readable(xmlfile))
  # read the XML document
  doc = read_xml(xmlfile)
  # find the reference to the XML Schema in the XML doc
  xmlschemafile = xml_attr(xml_find_first(doc,"/TB.Vx.model.inputfile"),"noNamespaceSchemaLocation")
  # make sure the XML schema is a readable file
  assert_that(is.readable(xmlschemafile))
  # read the XML Schema file (i.e. the .xsd)
  schema = read_xml(xmlschemafile)
  # and validate the XML doc
  assert_that(xml_validate(doc,schema))
  doc  
}
if (F){
modify.node.attr = function(xmldoc, xpath, name, value){
  parameters=xml_find_all(xmldoc,xpath)
  index = xml_attr(parameters,"name") == name
  node = parameters[index]
  xml_set_attr(node,"value",value)
  print(value)
  xmldoc
}
}

# new version with extra argument
modify.node.attr = function(xmldoc, xpath, name=NA, value=NULL, xattr=NULL){
  assert_that(!(is.na(name) & is.null(xattr)),msg="name and xattr cannot both be NA / NULL")
  parameters=xml_find_all(xmldoc,xpath)
  if (!is.null(xattr)){
    assert_that(!is.null(names(xattr)),msg="xattr should be a named character vector")  
    index = xml_attr(parameters,names(xattr)) == xattr
    index[is.na(index)]=FALSE
  }else{
    index = xml_attr(parameters,"name") == name
  }
  node = parameters[index]
  xml_set_attr(node,"value",value)
  cat(as.character(name),'=',signif(as.numeric(value),5),' ')
  xmldoc
}

mod_xml = function(df){
  i=1
  while (i<=nrow(df)){
    xmldoc = read.xml.file(df$source_file[i])
    xmldoc = modify.node.attr(xmldoc, df$xpath[i], df$attr_name[i], df$attr_value[i])
    while (is.na(df$target_file[i])){
      i = i + 1
      xmldoc = modify.node.attr(xmldoc, df$xpath[i], df$attr_name[i], df$attr_value[i])
    }
    write_xml(xmldoc,df$target_file[i])
    i = i + 1
  }
} 
