single.run = function(model=NULL){
  assert_that(!is.null(model))
  targets = model$targets
  fparams = model$fixed.params
  fitted.params = model$fitted.params
  param.values = model$param.values
  fparams$xml$doc = update.fitted.parameters(fparams,fitted.params,param.values)
  params = init.parameters(fparams$xmlfile,fparams$xmlrunfile, fparams)
  output = run.model(params, write.to.file=T)
  out    = eval.output.vs.targets(output,targets,p=params)
  return(list(output=output,hits=out))
}

init.model.parameters.and.targets = function(targets.file=NA,fitparams.file=NA,xml.file=NA,xmlrun.file=NA,opts=NA){
  model = new.env()
  with(model,{
    selected.parameters = read.csv(fitparams.file,stringsAsFactors = F, header=T, fileEncoding = 'UTF-8-BOM')
    constant            = grepl("^con.*",selected.parameters$dist) | !selected.parameters$choose 
    targets             = read.targets(targets.file)
    params              = init.parameters(xmlfile=xml.file,xmlrunfile=xmlrun.file)
    params$xml$doc      = update.constant.parameters(params,selected.parameters[constant,])
  })
  model
}

run.blast = function(targets.file,fitparams.file,xml.file,xmlrun.file,opts){
  
  model         = init.model.parameters.and.targets(targets.file,fitparams.file,xml.file,xmlrun.file,opts)
  
  with(model,{
    my_layout=function(level, ...) {
      msg <- paste0("taskID=",Sys.getenv(opts$taskenvvar)," runnr=",runnr,...)
      sprintf("%s\n", msg)
    }
    timestamp     = as.character(as.integer(seconds(now())))
    logfile       = paste0("./",opts$outdir,"/",unlist(strsplit(opts$xmlinput,".xml"))[1],"-blast-",timestamp,Sys.getenv(opts$taskenvvar),".log")
    log           = file_appender(file=logfile, append = TRUE, layout = my_layout)
    fitted.params = selected.parameters[!constant,]
    for (i in 1:opts$nruns){
      runnr                   <<- i
      new.param.values        = runif(nrow(fitted.params),fitted.params$min,fitted.params$max)
      names(new.param.values) = fitted.params$unique.name
      params$xml$doc          = update.fitted.parameters(params,fitted.params,new.param.values)
      temp.params             = init.parameters(params$xmlfile,params$xmlrunfile,params)
      
      output                  = run.model(temp.params)
      out                     = eval.output.vs.targets(output,targets,p=temp.params)
      md5mdl                  = digest(params,algo="sha1")
      datetime                = format(Sys.time(), "%F_%Hh%Mm%Ss")
      log(                msg = paste0(" nHITS=",signif(sum(out$fit)),
                                       " SSwR=",signif(sum(out$weighted_residuals^2)),
                                       " SHA=",md5mdl, " ",datetime, " ",
                                       paste0(names(new.param.values),"=",signif(new.param.values),collapse=" "),
                                       paste0(selected.parameters[constant,]$unique.name,"=",signif(selected.parameters[constant,]$mean),collapse=" ")))
      score = sum(out$fit)/length(out$fit)
      if (score>=opts$minhitsfrac){
        write.table(output$z,file = paste0("./",opts$outdir,"/",md5mdl,"_",datetime,"_",round(score,2),"_blast_full.txt"), quote=F,sep="\t",row.names=F)
        write.table(out,file = paste0("./",opts$outdir,"/",md5mdl,"_",datetime,"_",round(score,2),"_blast.txt"), quote=F,sep="\t",row.names=F)
        write_xml(temp.params$xml$doc, file = paste0("./",opts$outdir,"/",md5mdl,"_",datetime,"_",round(score,2),"_blast.xml"), option="as_xml")
        selected.parameters[!constant,]$mean = new.param.values
        write.csv(selected.parameters,file=paste0("./",opts$outdir,"/",md5mdl,"_",datetime,"_",round(score,2),"_blast_params.csv"),quote=F,row.names=F)
      }
    }
  })
}

run.optimization = function(targets.file,fitparams.file,xml.file,xmlrun.file,opts,lmcontrol){
  
  model         = init.model.parameters.and.targets(targets.file,fitparams.file,xml.file,xmlrun.file,opts)
  
  model$levmarqcontrol = NULL
  if (!is.null(lmcontrol)){
    df = read.csv(lmcontrol,fileEncoding = "UTF-8-BOM")
    ctrl = new.env()
    eval(parse(text=paste(df$parameter,"=",df$value)),envir = ctrl)
    model$levmarqcontrol = as.list(ctrl)
  }
  
  with(model,{
    
    my_layout=function(level, ...) {
      msg <- paste0("taskID=",Sys.getenv(opts$taskenvvar)," runnr=",runnr,...)
      sprintf("%s\n", msg)
    }
    timestamp     = as.character(as.integer(seconds(now())))
    logfile       = paste0("./",opts$outdir,"/",unlist(strsplit(opts$xmlinput,".xml"))[1],"-optim-",timestamp,Sys.getenv(opts$taskenvvar),".log")
    log           = file_appender(file=logfile, append = TRUE, layout = my_layout)
    fitted.params = selected.parameters[!constant,]

    for (i in 1:opts$nruns){
      runnr                   <<- i
      if (i==1){
        new.param.values      = fitted.params$mean # i.e. we start at mean values
      }else{
        new.param.values      = runif(nrow(fitted.params),fitted.params$min,fitted.params$max) # i.e. we start at random values
      }
      names(new.param.values) = fitted.params$unique.name
      params$xml$doc          = update.fitted.parameters(params,fitted.params,new.param.values)
      temp.params             = init.parameters(params$xmlfile,params$xmlrunfile,params)

      if (!is.null(levmarqcontrol)){
        control = levmarqcontrol
        control$diag = control$diag/model$fitted.params$mean
      }else{
        control = NULL
      }
      result                  = optimize(fn=fit.model, model=model, control=control, logfn=log)
      names(result$par)       = fitted.params$unique.name
      params$xml$doc          = update.fitted.parameters(params,fitted.params,result$par)
      temp.params             = init.parameters(params$xmlfile,params$xmlrunfile,params)
      output                  = run.model(temp.params)
      out                     = eval.output.vs.targets(output,targets,p=temp.params)
      md5mdl                  = digest(params,algo="sha1")
      datetime                = format(Sys.time(), "%F_%Hh%Mm%Ss")
      log(                msg = paste0(" nHITS=",signif(sum(out$fit)),
                                       " SSwR=",signif(sum(out$weighted_residuals^2)),
                                       " SHA=",md5mdl, " ",datetime, " ",
                                       paste0(names(result$par),"=",signif(result$par),collapse=" "),
                                       paste0(selected.parameters[constant,]$unique.name,"=",signif(selected.parameters[constant,]$mean),collapse=" ")))
      score = sum(out$fit)/length(out$fit)
      if (score>=opts$minhitsfrac){
        write.table(out,file = paste0("./",opts$outdir,"/",md5mdl,"_",datetime,"_",round(score,2),"_optim.txt"), quote=F,sep="\t",row.names=F)
        write_xml(temp.params$xml$doc, file = paste0("./",opts$outdir,"/",md5mdl,"_",datetime,"_",round(score,2),"_optim.xml"), option="as_xml")
        selected.parameters[!constant,]$mean = result$par
        write.csv(selected.parameters,file=paste0("./",opts$outdir,"/",md5mdl,"_",datetime,"_",round(score,2),"_optim_params.csv"),quote=F,row.names=F)
        write.table(output$z,file = paste0("./",opts$outdir,"/",md5mdl,"_",datetime,"_",round(score,2),"_optim_full.txt"), quote=F,sep="\t",row.names=F)
      }
    }
  })
}

optimize = function(fn=NULL, model=NA, control = NA, logfn=NULL){
  modFit(f=fn,p=model$new.param.values,fitted.params=model$fitted.params, fparams=model$temp.params, 
         targets=model$targets, logfn=logfn, lower=model$fitted.params$min, upper=model$fitted.params$max, 
         method="Marq",control=control)
}

fit.model = function(param.values=NA, fitted.params=NA, fparams=NA, targets=NA, logfn=NULL){
  fparams$xml$doc = update.fitted.parameters(fparams,fitted.params,param.values)
  params = init.parameters(fparams$xmlfile,fparams$xmlrunfile, fparams)
  output = run.model(params)
  fit    = eval.output.vs.targets(output,targets,p=params)
  # print(fit$weighted_residuals)
  #result = data.frame(name=fit$name,year=fit$year,w_resid=fit$weighted_residuals,data=fit$value,model=fit$model,rss=fit$weighted_residuals^2)
  #rez = result[order(result$w_resid^2),]
  #RSS=sum(rez$w_resid^2)
  #print(rez)
  # print(sum(fit$weighted_residuals^2))
  logfn(msg=paste0(" SSwR=",signif(sum(fit$weighted_residuals^2),4)," ",paste0(names(param.values),"=",signif(param.values,4),collapse=" ")))
  return(fit$weighted_residuals)
}
# NOTE: though fit.model returns residuals, only Marq uses these. Nelder Mead takes the TSS

