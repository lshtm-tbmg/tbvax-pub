output.to.array=function(Y,parms){
  years = Y[[1]]
  n     = length(years)
  idxs  = 1:n
  dimZ  = c(n,parms$nVXa, parms$nSES, parms$nRISK, parms$nHIV,parms$nTB,parms$nAGES)
  ndim  = length(dimZ)
  Z     = array(0,dim=dimZ)
  tb    = 1:parms$nTB
  if(ndim==7){
    for (i in idxs){
      for (vxa in 1:parms$nVXa)
        for (ses in 1:parms$nSES)
          for (risk in 1:parms$nRISK)
            for (hiv in 1:parms$nHIV){
              Z[i,vxa,ses,risk,hiv,,]=Y[[2]][[i]][calc.index.by.nr(parms,vxa,ses,risk,hiv,tb),]  
            }
    }
    dimnames(Z)=list(YEAR=years,VXa=names(parms$VXa), SES=names(parms$SES), RISK=names(parms$RISK), HIV=names(parms$HIV), TB=names(parms$TB), AGE=parms$AGES)
  }else{
    stop("unsupported number of dimensions in output")
  }
  Z
}

generate.filename = function(fparams,s){
  s1 = unlist(strsplit(fparams$xmlfile,"/",fixed=T))
  s2 = unlist(strsplit(s1[length(s1)],".xml",fixed=T))
  s3 = unlist(strsplit(fparams$xmlrunfile,"/",fixed=T))
  s4 = unlist(strsplit(s3[length(s3)],".xml",fixed=T))
  s5 = as.character(as.integer(seconds(now())) %% 100000)
  md5run = digest(fparams$run.params,algo="sha1")
  md5mdl = digest(fparams,algo="sha1")
  sig  = paste(substring(md5mdl,nchar(md5mdl)-4),"_",substring(md5run,nchar(md5run)-4),sep="")
  paste("./output/",s2,"_",s4,"_",sig,"_",s5,s,".txt",sep="")
}

generate.detailed.output=function(t,state,fparams,round.to=2){
    df = NULL
    nrows = nrow(state[[1]])
    detailed = fparams$detailed.output
    for (i in 1:length(t)){
      if (t[i]>=detailed$from.year & t[i]<=detailed$thru.year){
        YEAR = rep(t[i],nrows)
        M  = round(state[[i]],round.to)
        # now add col with spec
        VXa  = calc.names.for.dim(fparams,"VXa")
        SES  = calc.names.for.dim(fparams,"SES")
        RISK = calc.names.for.dim(fparams,"RISK")
        HIV  = calc.names.for.dim(fparams,"HIV")
        TB   = calc.names.for.dim(fparams,"TB")
        row.names(M)=NULL
        if (sum(is.na(detailed$age.from))==0){
          Q = NULL
          age.from = c(detailed$age.from,200)
          for (i in 1:(length(age.from)-1)){
            from  = age.from[i]
            to    = age.from[i+1]
            range = as.integer(colnames(M))>=from & as.integer(colnames(M))<to 
            Q = cbind(Q,as.numeric(rowSums(M[,range])))
          }
          colnames(Q)=paste("A",detailed$age.from,sep="")
          M = Q
        }else{
          colnames(M)=paste("A",colnames(M),sep="")
        }
        M    = cbind(YEAR,VXa,SES,RISK,HIV,TB,M)
        if (is.null(df))
          df = M
        else
          df   = rbind(df,M)
      }
    }
    df      = as.data.frame(df)
    df$YEAR = as.numeric(df$YEAR)
    for (i in 7:ncol(df)){
      df[,i]=as.numeric(df[,i])
    }
    df
}
generate.output=function(t,state,params,round.to=2){
  if (!is.null(params$detailed.output)){
    return(list(data=generate.detailed.output(t,state,params,round.to=round.to)))
  }
  NULL
}

write.output=function(data,filename){
  write.table(data,file=filename,row.names=F,sep="\t",quote=F)
  print(filename)
}


add.dY.inci=function(A,f,t,Y,p,q,include=F){
  if (include){
    res      = f(t,Y,p,q)
    A$dY     = A$dY     + res$dY
    A$dY.in  = A$dY.in  + res$dY.in
    A$dY.out = A$dY.out + res$dY.out
  }
  A
}

add.dY=function(A,f,t,Y,p,include=F){
  if (include){
    res      = f(t,Y,p)
    A$dY     = A$dY + res$dY
    A$dY.in  = A$dY.in  + res$dY.in
    A$dY.out = A$dY.out + res$dY.out
  }
  A
}
add.matmul.dY=function(A,f,M,Y,include=F){
  if (include){
    res      = f(M,Y)
    A$dY     = A$dY     + res$dY
    A$dY.in  = A$dY.in  + res$dY.in
    A$dY.out = A$dY.out + res$dY.out
  }
  A
}



incidence.from.model.run=function(out,params){
  sel         = which(out$t %in% params$inci.output.years)
  inci        = list()
  inci$t      = out$t[sel]
  inci$Y      = list()
  inci$dY     = list()
  inci$dY.in  = list()
  inci$dY.out = list()
  for (i in seq_along(inci$t)){
    out.index        = sel[i]
    inci$Y[[i]]      = out$state[[out.index]]
    inci.output.t    = incidence.output.from.Y.matrix(t=out$t[out.index],out$state[[out.index]],params)
    inci$dY[[i]]     = inci.output.t$dY
    inci$dY.in[[i]]  = inci.output.t$dY.in 
    inci$dY.out[[i]] = inci.output.t$dY.out
  }
  inci
}

incidence.output.from.Y.matrix=function(t,Y,p){
  
  dZ = list(dY = 0.*Y, dY.in = 0.*Y, dY.out = 0.*Y)
  
  inci.spec = p$incidence.output$output.dims
  sel       = inci.spec$dim=="TB"
  tb.dim    = inci.spec[sel,]    
  
  dZ    = add.matmul.dY(dZ,matmul.by.age.group.in.out,p$Ti,Y,tb.dim$progression)
  
  if (p$incidence.output$include.natural.deaths){
    dZ$dY = dZ$dY + derivs.nat.death(t,Y,p,colSums(dZ$dY[!p$ALIVE,]))
  }

  # update the contact matrix to be compatible with current population age distribution
  
  update.contact.matrix(p, colSums(Y[p$ALIVE,]))
  
  dZ    = add.dY(dZ,derivs.Tm.in.out,t,Y,p,tb.dim$transmission)  
  
  if (!is.null(p$Tr)){
    dZ  = add.dY(dZ,derivs.Tr.in.out,t,Y,p,tb.dim$treatment)
  }
  
  for (i in seq_along(p$inci)){
    q   = p$inci[[i]]
    sel = (inci.spec$dim==q$dim)
    dZ = add.dY.inci(dZ,derivs.inci.in.out,t,Y,p,q,inci.spec[sel,]$from.data)
  }
  
  for (i in seq_along(p$DIMNNAMES)){
    dim = p$DIMNNAMES[i]
    if (dim !="TB" && p$DIMLENGTHS[i]>1 && !is.null(p$PROGRESSION[[dim]])){
      sel = inc.spec$dim == dim
      dZ = add.matmul.dY(dZ,matmul.by.age.group.in.out,p$PROGRESSION[[dim]],Y,inci.spec[sel,]$progression)
    }
  }
  dZ
}
