# pop sizes
N = c(100,120,150,80,60)
n = length(N)
A = matrix(N,n,n)
B = 1/(1+t(A)/A)

M = matrix(runif(n*n),n,n) 
diag(M)=1
# M is the transposed contact matrix
P = M + t(M)
# P is a symmetric matrix with sums of diagonal and off-diagonal elements
balanced.contact.matrix = P * B
Z = balanced.contact.matrix
# Z is the balanced contact matrix
Z
# to prove that:
abs(Z[1,2]*N[2] - Z[2,1]*N[1])<1e-10
abs(Z[1,3]*N[3] - Z[3,1]*N[1])<1e-10
abs(Z[2,3]*N[3] - Z[3,2]*N[2])<1e-10
abs(Z[1,2] + Z[2,1] - M[1,2]-M[2,1])<1e-10
abs(Z[1,3] + Z[3,1] - M[1,3]-M[3,1])<1e-10
abs(Z[2,3] + Z[3,2] - M[2,3]-M[3,2])<1e-10
# etc

# CONCLUSION:
# (after some thought) it is straightforward to balance the contact matrix in accordance with age group size
# 
# Issues encountered previously (July 8, 2020):
# after adding a couple of lines of code to initialize state at birth (e.g. 5% HIV+):
# values of state variables < 0 occurred frequently
# always in Un TB state (i.e. susceptible and also HIV1 Un and HIV2 Un)
# issue could be 'solved' by decreasing time step
# HOWEVER: in my opinion, there was 'something rotten in the state of Denmark' ....
# also: there appeared to be a relation with birth rate i.e. age group size over time
# major discontinuities in age group size appeared to worsen the issue (of negative state var values)
# after more thought and analysis (and questioning the code for transmission including using contact matrices):
# the code for calculating the part of the derivative due to transmission is correct
# HOWEVER: the contact matrix should be balanced for age group sizes !!!!!!
# This may very well explain the odd behaviour of the model




