create.parameters.matrix=function(A){
  B = aperm(A)
  ndim=length(dim(B))
  n   = dim(B)[1]
  assert_that(dim(B)[2]==n)
  dim(B)=c(n,n,prod(dim(B)[3:ndim]))
  M = matrix(0,n*dim(B)[3],n*dim(B)[3])
  nsubmat = dim(B)[3]
  for (i in 1:nsubmat){
    from = (i-1)*n + 1
    thru =  i   *n 
    M[from:thru,from:thru] = B[1:n,1:n,i]
  }
  M  
}

if (F){ # code for testing
  rm(list=ls())
  VAX=c("V0","V1","V3")
  nVAX=length(VAX)
  SES=c("S0","S1")
  nSES=length(SES)
  RISK=c("R0","R1","R2")
  nRISK=length(RISK)
  HIV=c("H0","H1","H2","H3","H4")
  nHIV=length(HIV)
  nTB=3
  TB=LETTERS[1:nTB]
  
  A = array(data=runif(nVAX,nSES*nRISK*nHIV*nTB*nTB),dim=c(nVAX,nSES,nRISK,nHIV,nTB,nTB))
  
  for (vax in 1:nVAX)
    for (hiv in 1:nHIV)
      for (risk in 1:nRISK)
        for (ses in 1:nSES)
          for (tb in 1:nTB)
            for (tb2 in 1:nTB)
              A[vax,ses,risk,hiv,tb,tb2]=matrix(vax*1e5+ses*10000+risk*1000+hiv*100+tb+10*tb2)
  
  M=create.parameters.matrix(A)
  dim(M)
  M[170:180,170:180]
}





