rm(list=ls())
require(assertthat)
require(stringi)
require(Matrix)
require(xml2)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

source("./R/TBVx-matrix-etc-fncs-v7.R")
source("./R/TBVx-data-reading-fncs-v7.R")
source("./R/TBVx-parsing-xml-fncs-v7.R")
source("./R/TBVx-initialization-fncs-v7.R")
source("./R/TBVx-derivs-v7.R")

params=init.parameters(xmlfile         = "./TBVx-A.xml",
                datapath               = "./data/", 
                countrycode            = "IN", 
                initial.population.txt = NA, #"IN_initial_population_as_fraction.txt", 
                population.csv         = "demographics_total_population.csv",
                deathrate.txt          = "IN_mort_age.txt",
                contact.matrix.txt     = "IN_all_contacts.txt",
                birthrate              = NA, # e.g. 21 , # NA if to be derived from #newborns in population data 
                birthrate.as.number    = F, # F if birthrate as fraction (CBR per 1000 pop)
                seed                   = list(TB.stages=c("Ds","Dc"),age.from.thru=c("A20","A24"),n=c(250,50)),
                hiv.incidence.txt      = "HIV-incidence.txt",
                art.incidence.txt      = "ART-incidence.txt",
                vxa.incidence.txt      = "VXA-incidence.txt")

# do a simulation run during 150 years and (if needed) write final (Y2050) population fractions to a file
yearz=2000:2050
ycal=run(derivs, dt=1/2, years = yearz, fparams=params)#, write.final.alive.population.to = "./data/IN_ALL_F_2050.txt") 
View(ycal[[2]][[20]])

require(microbenchmark)
microbenchmark(run(derivs, dt=1/2, years = yearz, fparams=params),times=5)

# transform the output to a multidimensional array
zcal=output.to.array(ycal,params) # zcal is now a multidimensional array
dim(zcal)
# the dimensions are 201 years, 1 Vx, 2 SES, 2 RISK, 5 HIV, 11 TB, 82 AGE
zcal[51,1,1,1,,,]
# demography
# NOTE exclude the deaths i.e. TB 9 and 10 and HIV 6
pop.detailed     = apply(zcal[,,,,-6,-9,],c(1,7),sum) # pop by year and detailed age group excl dead 
#View(pop.detailed)
# note that the apply function also works with multi-dimensional arrays
# apply(zcal[,1,,,,-c(9:11),],c(1,6),sum)
# means to sum over all except dimension 1 and 6 which would be year and TB (note that the 2nd dim does not count as there is only 1 class in that dimension)
# the command below would lead to exactly the same results even though the 2nd dim (Vx) was not explicitly set to 1 (and therefore not counted) 
# because the size of the dimension was 1 to start with
# pop.detailed.2     = apply(zcal[,,,,,-c(9:11),],c(1,6),sum) # pop by year and detailed age group excl dead 

pop.by.age.group = sum.by.age.groups(pop.detailed,c(0,15,50,70),sumcols=F) # pop by year and aggregated age group 
rownames(pop.by.age.group)=dimnames(pop.detailed)$YEAR

# par(mfrow=c(2,1))
# device =png("./output/pop.png")
years = as.integer(rownames(pop.by.age.group))
plot (years,pop.by.age.group[,1],ylim=c(0,1.5e6),type="l",col="blue",lwd=2) 
lines(years,pop.by.age.group[,2],type="l",col="darkgreen",lwd=2) 
lines(years,pop.by.age.group[,3],type="l",col="purple",lwd=2) 
lines(years,pop.by.age.group[,4],type="l",col="red",lwd=2) 
legend("topright", inset=.05, title="age group ",c("0-14","15-49","50-69","70+"), fill=c("blue","darkgreen","purple","red"),horiz=F)
# dev.off()

# TB states:
# "Un"      "Uc"      "Lf"      "Ls"      "Ds"      "Dc"      "T"       "R"       "TBdead" 

HIV.cases = apply(zcal[,,,,-6,-9,],c(1,5),sum)
pop=rowSums(pop.by.age.group)
prev=100*HIV.cases/pop
dim(prev)
# device =png("./output/TB-cases-F.png")
years = as.integer(rownames(pop.by.age.group))
plot(years,prev[,1],type="l",col="darkgreen",lwd=2,ylim=c(0,20),ylab="HIV prev [%]",xlab="year")
lines(years,prev[,2],type="l",col="red",lwd=2)
lines(years,prev[,3],type="l",col="magenta",lwd=2)
lines(years,prev[,4],type="l",col="green",lwd=2)
lines(years,prev[,5],type="l",col="blue",lwd=2)
legend("topright", inset=.05, title="HIV ",c("HIV-","HIV1","HIV2","ART1","ART2"), fill=c("darkgreen","red","magenta","green","blue"), horiz=F)
# dev.off()  

# TB states:
# "Un"      "Uc"      "Lf"      "Ls"      "Ds"      "Dc"      "T"       "R"       "TBdead"  "HIVdead" "NATdead"

TB.cases = apply(zcal[,,,,,c(5,6),],c(1,6),sum)
pop=rowSums(pop.by.age.group)
prev=100000*TB.cases/pop
dim(prev)
# device =png("./output/TB-cases-F.png")
years = as.integer(rownames(pop.by.age.group))
plot(years,prev[,1],type="l",col="blue",lwd=2,ylim=c(0,1000),ylab="TB cases [per 100 000]",xlab="year")
lines(years,prev[,2],type="l",col="magenta",lwd=2)
legend("topright", inset=.05, title="TB ",c("Ds","Dc"), fill=c("blue","magenta"), horiz=F)
# dev.off()  


LTBI.cases = apply(zcal[,,,,,c(3,4),],c(1,6),sum)
pop=rowSums(pop.by.age.group)
prev=100*LTBI.cases/pop
dim(prev)
# device =png("./output/Lf-Ls-cases-F.png")
years = as.integer(rownames(pop.by.age.group))
plot(years,prev[,1],type="l",col="blue",lwd=2,ylim=c(0,100),ylab="Lf+Ls cases [%]",xlab="year")
lines(years,prev[,2],type="l",col="magenta",lwd=2)
legend("topright", inset=.05, title="LTBI ",c("Lf","Ls"), fill=c("blue","magenta"), horiz=F)
# dev.off()  
