# derivs(t,     Y,       fparams)

RKCONST = new.env()
with(RKCONST,{
  a2  =       0.2          ; a3  =        0.3         ; a4  =        0.6         ; a5  =    1.0        ; a6  =     0.875 
  b21 =       0.2          ; b31 =        3.0/40.0    ; b32 =        9.0/40.0    ; b41 =    0.3        ; b42 =    -0.9   ; b43 = 1.2
  b51 =     -11.0/54.0     ; b52 =        2.5         ; b53 =      -70.0/27.0    ; b54 =   35.0/27.0
  b61 =    1631.0/55296.0  ; b62 =      175.0/512.0   ; b63 =      575.0/13824.0
  b64 =   44275.0/110592.0 ; b65 =      253.0/4096.0 
  c1  =      37.0/378.0    ; c3  =      250.0/621.0   ; c4  =      125.0/594.0   ; c6  =  512.0/1771.0
  dc1 = c1-2825.0/27648.0  ; dc3 = c3-18575.0/48384.0 ; dc4 = c4-13525.0/55296.0 ; dc5 = -277.0/14336.0 ; dc6 = c6-0.25
  
  SAFETY =  0.9
  PGROW  = -0.2
  PSHRNK = -0.25
  ERRCON =  1.89e-4
  MINH   = 1e-10
  TINY   = 1e-30
  MAXSTP = 10000
  
})

# from Numerical Recipes in C Teukolsky, Press, et al
rkck = function(derivs, y, dydt, t, h, fparams, CONST){
  ytemp = y + h *  CONST$b21 * dydt
  ak2   = derivs(t + CONST$a2 * h, ytemp, fparams)
  ytemp = y + h * (CONST$b31 * dydt + CONST$b32 * ak2)
  ak3   = derivs(t + CONST$a3 * h, ytemp, fparams)
  ytemp = y + h * (CONST$b41 * dydt + CONST$b42 * ak2 + CONST$b43 * ak3)
  ak4   = derivs(t + CONST$a4 * h, ytemp, fparams)
  ytemp = y + h * (CONST$b51 * dydt + CONST$b52 * ak2 + CONST$b53 * ak3 + CONST$b54 * ak4)
  ak5   = derivs(t + CONST$a5 * h, ytemp, fparams)
  ytemp = y + h * (CONST$b61 * dydt + CONST$b62 * ak2 + CONST$b63 * ak3 + CONST$b64 * ak4 + CONST$b65 * ak5);
  ak6   = derivs(t + CONST$a6 * h, ytemp, fparams)
  yout  = y + h * (CONST$c1  * dydt + CONST$c3  * ak3 + CONST$c4  * ak4 + CONST$c6  * ak6)
  yerr  =     h * (CONST$dc1 * dydt + CONST$dc3 * ak3 + CONST$dc4 * ak4 + CONST$dc5 * ak5 + CONST$dc6 * ak6)
  list(yout=yout,yerr=yerr)
}

# call this routine with dydt estimated by derivs func
# the question is: what to use for yscal ????
# probably just dydt !
rkqs = function(derivs, y, dydt, t, h, eps, yscal=NULL, fparams, CONST){
  if (is.null(yscal)){
    yscal = 1.
  }
  while(T){ # find an acceptible h
    result = rkck(derivs, y, dydt, t, h, fparams, CONST)
    errmax = max(abs(result$yerr/yscal)) / eps
    if (errmax <= 1.0)
      break
    h = max(0.1*h,CONST$SAFETY*h*(errmax^CONST$PSHRNK))
    if (abs(h)<abs(CONST$MINH)) 
      stop("stepsize underflow in rkqs")
  } 
  if (errmax > CONST$ERRCON) 
    hnext = CONST$SAFETY*h*(errmax^CONST$PGROW)
  else 
    hnext = 5.0 * h
  list(ynew= result$yout, tnew=t+h, hdid=h, hnext=hnext)
}







