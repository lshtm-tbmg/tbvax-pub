setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
require(xml2)
xmldoc = read_xml("../TB-ALL/parameters/TB-Vx-TB-ALL.xml")
xml_validate(xmldoc, read_xml("../TB-Vx-schema.xsd"))

xmlparams=xml_find_all(xmldoc,"//TB/TB.progression/TB.parameter")
node=xmlparams[1]
xml_set_attr(node,"name","modified")
write_xml(xmldoc,"modified.xml")


