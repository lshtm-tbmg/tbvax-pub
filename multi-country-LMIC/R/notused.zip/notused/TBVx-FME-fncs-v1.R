init.model.parameters.targets.seed = function(targets.file=NA,fitparams.file=NA,xml.file=NA,xmlrun.file=NA,seed=123){
  model = new.env()
  fit.parameters = read.csv(fitparams.file,stringsAsFactors = F, header=T, fileEncoding = 'UTF-8-BOM')
  const = fit.parameters$dist == "constant"
  with (model,{
    targets = read.targets(targets.file)
    constant.params = fit.parameters[ const,]
    fitted.params   = fit.parameters[!const,]
    param.values = fitted.params$mean
    names(param.values)=fitted.params$unique.name
    param.values.lower = fitted.params$min
    param.values.upper = fitted.params$max
    fixed.params         = init.parameters(xmlfile=xml.file,xmlrunfile=xmlrun.file)
    fixed.params$xml$doc = update.constant.parameters(model$fixed.params,model$constant.params)
    seed = seed
  })
  model
}
fit.model = function(model=NULL){
  assert_that(!is.null(model))
  targets = model$targets
  fparams = model$fixed.params
  fitted.params = model$fitted.params
  param.values = model$param.values
  fparams$xml$doc = update.fitted.parameters(fparams,fitted.params,param.values, print=T)
  params = init.parameters(fparams$xmlfile,fparams$xmlrunfile, fparams)
  output = run.model(params,atol=1e-3,rtol=1e-6)
  fit    = eval.output.vs.targets(output,targets)
  return(fit)
}

fit.FME = function(param.values=NA, fitted.params=NA, fparams=NA, targets=NA){
  fparams$xml$doc = update.fitted.parameters(fparams,fitted.params,param.values, print=T)
  params = init.parameters(fparams$xmlfile,fparams$xmlrunfile, fparams)
  output = run.model(params,atol=1e-3,rtol=1e-6)
  fit    = eval.output.vs.targets(output,targets)
  # print(fit$weighted_residuals)
  #result = data.frame(name=fit$name,year=fit$year,w_resid=fit$weighted_residuals,data=fit$value,model=fit$model,rss=fit$weighted_residuals^2)
  #rez = result[order(result$w_resid^2),]
  #RSS=sum(rez$w_resid^2)
  #print(rez)
  print(sum(fit$weighted_residuals^2))
  return(fit$weighted_residuals)
}
# NOTE: though fit.model returns residuals, only Marq uses these. Nelder Mead takes the TSS

FME.optimize = function(fn=fit.FME, model=NA, control = NA, method="Marq"){
  modFit(f=fn,p=model$param.values,fitted.params=model$fitted.params, fparams=model$fixed.params, 
         targets=model$targets, lower=model$param.values.lower, upper=model$param.values.upper, 
         method=method, control=control)
}

