aging.and.births.and.update.contact.matrix.event <- function(t,X,p){
  if (t>p$years[1]){
    if (p$print.aging){ 
      print(paste("aging, birth and update contact matrix at t=",t))
    }
    Y        = matrix(X,p$nVXaSESRISKHIVTB,p$nAGES) ; rownames(Y)=p$VXaSESRISKHIVTB ; colnames(Y)=names(p$AGES)
    alive.by.age.group = colSums(Y[p$ALIVE,])
    update.contact.matrix(p, alive.by.age.group)
    dY       = t(tcrossprod(p$aging.matrix, Y))
    if (p$birthrate.is.number){
      dY[,1] = dY[,1] + p$birthrate(t)
    }else{
      dY[,1] = dY[,1] + p$birthrate(t)*sum(alive.by.age.group)*p$at.birth
    }
    Y = Y + dY
    Y[!p$ALIVE,]=0.
    assert_that(sum(Y<0.)==0,msg=paste("error in run function @ t=",t,": one or more state variables < 0 !?"))
    assert_that(sum(Y>1e10)==0,msg=paste("error in run function @ t=",t,": one or more state variables > 1e10 !?"))
    
    return(as.vector(Y))
  }else{
    return(X)
  }
}

derivs.Tr=function(t,Y,parms){
  tparams = parms$Tr$timed.parameters
  if (is.null(tparams))
    return(matmul.by.age.group(parms$Tr,Y))
  else{
    mult=1.0
    nms = names(tparams)
    for (nm in nms)
      mult = mult * get(nm,envir=tparams)(t)
    return(matmul.by.age.group(parms$Tr,Y))
  }
}

derivs.Tr.in.out=function(t,Y,parms){
  tparams = parms$Tr$timed.parameters
  if (is.null(tparams))
    return(matmul.by.age.group.in.out(parms$Tr,Y))
  else{
    mult=1.0
    nms = names(tparams)
    for (nm in nms)
      mult = mult * get(nm,envir=tparams)(t)
    return(matmul.by.age.group.in.out(parms$Tr,Y,mult))
  }
}

derivs.Tm.in.out=function(t,Y,parms){
  infc = matmul.by.age.group(parms$Infc, Y) # always > 0
  mult = 1.0
  tparams = parms$Tm$timed.parameters
  if (!is.null(tparams)){
    nms = names(tparams)
    for (nm in nms)
      mult = mult * get(nm,envir=tparams)(t)
  }
  foi  = mult * parms$DAYSPERYEAR * rowSums(parms$contacts.M %*% (colSums(infc)/colSums(Y[parms$ALIVE,]))) # foi is a column vector of foi by age ; ipv tcrossprod(M,infc)
  susc.list = matmul.by.age.group.in.out(parms$Tm, Y) # the Tm matrices have both positive and negative elements
  dY.in  = t(t(susc.list$dY.in ) * foi )
  dY.out = t(t(susc.list$dY.out) * foi )
  list(dY=(dY.in+dY.out),dY.in=dY.in,dY.out=dY.out)
}

derivs.Tm=function(t,Y,parms){
  infc = matmul.by.age.group(parms$Infc, Y)
  mult = 1.0
  tparams = parms$Tm$timed.parameters
  if (!is.null(tparams)){
    nms = names(tparams)
    for (nm in nms)
      mult = mult * get(nm,envir=tparams)(t)
  }
  foi  = mult * parms$DAYSPERYEAR * rowSums(parms$contacts.M %*% (colSums(infc)/colSums(Y[parms$ALIVE,]))) # foi is a column vector of foi by age ; ipv tcrossprod(M,infc)
  susc = matmul.by.age.group(parms$Tm, Y)
  t(t(susc) * foi )
}
derivs.inci=function(t=NA,Y=NA,p=NA,p.inci=NA){ 
  x_inci = as.numeric(p.inci$inci[p.inci$inci.fn(t),])
  if (sum(x_inci)>0){
    X = t(Y)
    dX = 0*X
    dX[,p.inci$susc]   = x_inci * X[,p.inci$susc] # OK - that is simple
    return(as.matrix(p.inci$inci.matrix %*% t(dX)))     
  }else{
    return(0.*Y)
  }
}
derivs.inci.in.out=function(t=NA,Y=NA,p=NA,p.inci=NA){ 
  x_inci = as.numeric(p.inci$inci[p.inci$inci.fn(t),])
  if (sum(x_inci)>0){
    X = t(Y)
    dX = 0*X
    dX[,p.inci$susc]   = x_inci * X[,p.inci$susc] # OK - that is simple
    P = Q = p.inci$inci.matrix
    P[p.inci$inci.matrix<0]=0.
    Q[p.inci$inci.matrix>0]=0.
    dY.in  = P %*% t(dX)
    dY.out = Q %*% t(dX) 
    return(list(dY=as.matrix(dY.in+dY.out),dY.in=as.matrix(dY.in),dY.out = as.matrix(dY.out)))     
  }else{
    return(list(dY=0.*Y,dY.in=0.*Y,dY.out = 0.*Y))     
  }
}

# in principe kunnen ART matrixen worden gecombineerd (van HIV1 -> ART1 en van HIV2 -> ART2)
# de techniek voor HIV en ART incidentie kunnen ook worden gebruikt voor vaccinatie
# data: file met kolommen YEAR from to en leeftijden in de overige kolommen
# YEAR from to    0 5 10 etc
# 2025 never vac  0.2 0.4 0.8 etc
# In feite is de techniek identiek voor incidentie van sterft, HIV, vaccinatie .....

derivs.nat.death=function(t,Y,parms,dY.TB.and.HIV.deaths){ 
  correction = dY.TB.and.HIV.deaths / colSums(Y[parms$ALIVE,])
  correction[is.infinite(correction)|is.nan(correction)]=0.
  mu = as.numeric(get.deathrate(parms,t)) - correction
  # if (sum(mu<0)>0){
  #  print(paste("number of TB and HIV deaths is larger than background deaths at t=",t))
  #}
  mu[mu<0]=0.
  X = t(Y)
  dX = 0*X
  dX[,parms$ALIVE]   = mu * X[,parms$ALIVE] # OK - that is simple
  dY = parms$DEATH.matrix %*% t(dX) 
  as.matrix(dY)     
}

scale.alive.population=function(Y,parms){
  Y[-parms$ALIVE,] = 0.
  Y                = sum(parms$y.ini)/sum(Y)*Y
  dimnames(Y)      = dimnames(parms$y.ini)
  Y
}



# called for every t listed and using prev matrix Y as input

derivs.deSolve=function(t,X,p){
  if (p$print.t){
    if (abs(t %% 1)<1e-6)
      cat('\n')
    cat(formatC(t,digits=3,format="f"),"  ")
  }
  Y = matrix(X,p$nVXaSESRISKHIVTB,p$nAGES)
  rownames(Y)=p$VXaSESRISKHIVTB
  colnames(Y)=names(p$AGES)
  dY.Ti = matmul.by.age.group(p$Ti,Y)
  dY.nat.death = derivs.nat.death(t,Y,p,colSums(dY.Ti[!p$ALIVE,]))
  dY =  derivs.Tm(t,Y,p) + dY.Ti + dY.nat.death 
  for (i in seq_along(p$inci))
    dY = dY + derivs.inci(t,Y,p,p$inci[[i]])
  if (!is.null(p$Tr))
    dY = dY + derivs.Tr(t,Y,p)
  if (p$nHIV>1)
    dY = dY + matmul.by.age.group(p$HIVp, Y)
  if (p$nRISK>1 & !is.null(p$RISKp))
    dY = dY + matmul.by.age.group(p$RISKp, Y)
  if (p$nSES>1  & !is.null(p$SESp))
    dY = dY + matmul.by.age.group(p$SESp, Y)
  if (p$nVXa>1  & !is.null(p$VXAp))
    dY = dY + matmul.by.age.group(p$VXAp, Y)
  assert <<- F
  list(dY=as.vector(dY))
}

run.deSolve = function(params = NULL, atol=NULL,rtol=NULL,method=NA){
  assert <<- T
  rawout = rk(   y = as.vector(params$y.ini), 
             times = params$years, 
             func  = derivs.deSolve, 
             parms = params, 
              rtol = rtol, 
              atol = atol, 
            method = method, 
            events = list(func = aging.and.births.and.update.contact.matrix.event, 
                          time = unique(trunc(params$years))[-1]))

  t         = rawout[,1]
  out       = vector("list",length(t)) 
  nr        = params$nVXaSESRISKHIVTB
  nc        = params$nAGES
  N         = nr*nc
  for (i in 1:length(t)){
      M = matrix(rawout[i,2:(N+1)],nr,nc)
      colnames(M)=params$AGES
      rownames(M)=params$VXaSESRISKHIVTB
      out[[i]] = M
  }
  list(times=t,state=out)
}

basic.run.model = function(p=NULL, atol=1e-3, rtol=1e-3, method="ode23", print.t=F, print.aging=F){
  p$print.t     = print.t
  p$print.aging = print.aging
  out           = run.deSolve(p, atol, rtol, method)
  if (!is.na(p$final.population.as.fraction)){
    nyrz  = length(out$times)
    y.fin   = out$state$Y[[nyrz]]
    y.alive = y.fin[p$ALIVE,]
    y.alive = y.alive[rowSums(y.alive)>1e-6,]
    y.alive.frac = y.alive/sum(y.alive)
    write.table(as.data.frame(y.alive.frac),file=p$final.population.as.fraction,sep="\t", row.names = T, quote=F)
  }
  out
}
run.model = function(p=NULL, write.to.file=F, atol=1e-3, rtol=1e-3, method="ode23", print.t=F, print.aging=F, report.inci=F,long.format=T){
  p$print.t     = print.t
  p$print.aging = print.aging
  out           = run.deSolve(p, atol, rtol, method)
  if (!is.na(p$final.population.as.fraction)){
    nyrz  = length(out$times)
    y.fin   = out$state$Y[[nyrz]]
    y.alive = y.fin[p$ALIVE,]
    y.alive = y.alive[rowSums(y.alive)>1e-6,]
    y.alive.frac = y.alive/sum(y.alive)
    write.table(as.data.frame(y.alive.frac),file=p$final.population.as.fraction,sep="\t", row.names = T, quote=F)
  }
  prev.out = generate.output(t=out$times,state=out$state,params=p,long.format=long.format)$data
  if (write.to.file){
    filename = generate.filename(p,"_prev")
    write.output(prev.out,filename)
    if (report.inci){
      inci = incidence.from.model.run(out,p)
      filename = generate.filename(p,"_dY_net")
      write.output(generate.output(t=inci$t,state=inci$dY,params=p,long.format=long.format)$data,filename)
      filename = generate.filename(p,"_dY_in")
      write.output(generate.output(t=inci$t,state=inci$dY.in,params=p,long.format=long.format)$data,filename)
      filename = generate.filename(p,"_dY_out")
      write.output(generate.output(t=inci$t,state=inci$dY.out,params=p,long.format=long.format)$data,filename)
      filename = generate.filename(p,"_Y")
      write.output(generate.output(t=inci$t,state=inci$Y,params=p,long.format=long.format)$data,filename)
    }      
  }else{
    if (!report.inci){
      return(prev.out)
    }else{
      inci    = incidence.from.model.run(out,p)
      Y       = generate.output(t=inci$t,state=inci$Y,params=p,long.format=long.format)$data
      dY      = generate.output(t=inci$t,state=inci$dY,params=p,long.format=long.format)$data
      dY.in   = generate.output(t=inci$t,state=inci$dY.in,params=p,long.format=long.format)$data
      dY.out  = generate.output(t=inci$t,state=inci$dY.out,params=p,long.format=long.format)$data
      return(list(prev=prev.out,Y=Y,dY=dY,dY.in=dY.in,dY.out=dY.out))
    }
  }
}


