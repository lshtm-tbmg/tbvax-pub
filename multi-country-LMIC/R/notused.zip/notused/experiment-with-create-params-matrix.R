rm(list=ls())
VAX=c("V0","V1","V3")
nVAX=length(VAX)
SES=c("S0","S1")
nSES=length(SES)
RISK=c("R0","R1")
nRISK=length(RISK)
HIV=c("H0","H1","H2")
nHIV=length(HIV)
TB=c("Un","Uc","Lf","Ls")
nTB=length(TB)

# A = array(data=NA,dim=c(nRISK,nRISK,nHIV,nHIV,nTB,nTB))
# dimnames(A)=list(RISK,RISK,HIV,HIV,TB,TB)

# A = array(data=NA,dim=c(nTB,nTB,nHIV,nHIV,nRISK,nRISK))
# dimnames(A)=list(TB,TB,HIV,HIV,RISK,RISK)

A = array(data=NA,dim=c(nTB,nTB,nHIV,nHIV,nRISK,nRISK,nSES,nSES))
dimnames(A)=list(TB,TB,HIV,HIV,RISK,RISK,SES,SES)


C = array(data=0,dim=c(nTB,nHIV,nRISK,nSES,nTB,nHIV,nRISK,nSES))
for (ses in 1:nSES){
  for (risk in 1:nRISK){
    for (hiv in 1:nHIV){
      m = matrix(0,nTB,nTB) # the SES, RISK, HIV dependent transition matrix for TB
      diag(m)=runif(nTB)
      m[2,1]=-m[1,1]
      m[3,2]=-m[2,2]
      m[4,3]=-m[3,3]
      m[1,4]=-m[4,4]
      C[,hiv,risk,ses,,hiv,risk,ses]=m
    }
  }
}
m = nTB*nHIV*nRISK*nSES
Cm = matrix(C,m,m)
round(Cm,2)



for (ses in 1:nSES){
  for (risk in 1:nRISK){
  for (hiv in 1:nHIV){
    m = matrix(NA,nTB,nTB)
    diag(m)=paste("-SES",ses,"RISK",risk,"HIV",hiv,TB,sep="")
    m[2,1]=paste("+SES",ses,"RISK",risk,"HIV",hiv,"Un",sep="")
    m[3,2]=paste("+SES",ses,"RISK",risk,"HIV",hiv,"Uc",sep="")
    m[4,3]=paste("+SES",ses,"RISK",risk,"HIV",hiv,"Lf",sep="")
    m[1,4]=paste("+SES",ses,"RISK",risk,"HIV",hiv,"Ls",sep="")
    
    A[,,hiv,hiv,risk,risk,ses,ses]=m
  }
  }
}
A2 = aperm(A,c(1,3,5,7,2,4,6,8))
#A2 = aperm(A,c(5,3,1,6,4,2))
A2m = matrix(A2,12*2*2,12*2*2)
A2m
A2m[21:48,21:48]

B = array(data=NA,dim=c(nTB,nTB,nHIV,nHIV,nRISK,nRISK))
for (risk in 1:nRISK){
  for (tb in 1:nTB){
    m = matrix(NA,nHIV,nHIV)
    diag(m)=paste("RISK",risk,HIV,sep="")
    B[tb,tb,,,risk,risk]=m
  }
}

B2 = aperm(B,c(1,3,5,2,4,6))
B2m = matrix(B2,12*2,12*2)
B2m



# the XML input file may specify TB progression dependent on:
# VAX, SES, RISK, HIV, AG
# we need to expand the input file XML specs to a data frame
# this would lead to a data frame with 
# nVAX * nSES * nRISK * nHIV * nAG = e.g. 3 * 2 * 3 * 5 * 3 = 270 rows per parameter 
# which will be used to create 90 TB transition matrices per age group ; these 90 matrices will be put in one (1) parameters matrix per age group
# the size of these parameters matrices will be 3 * 2 * 3 * 5 * 10 = 900 x 900 per AG
# of course these huge parameters matrices will consist of a diagonal of nTB * nTB progression matrices i.e. just TB progression
# state variables will be in a matrix of 900 * 82 

# how to handle HIV / SES / RISK / VAX progression ????
# start with HIV progression ... derive progression matrix from data frame based on XML and in the end produce a 900 * 82 matrix per age group ..

