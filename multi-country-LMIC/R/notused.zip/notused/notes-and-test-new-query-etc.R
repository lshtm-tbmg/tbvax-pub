# notes regarding code reorganization
#
# 1. force user to either specify ALL or NONE of the parameter dependencies
# 
# <TB.parameter name="a" value="1.0" age.group="A0" />
# <TB.parameter name="a" value="1.0" age.group="A15" />
# <TB.parameter name="a" value="1.0" age.group="A55" />
# would be OK (if no more age groups than A0, A15, A55)
# as would
# <TB.parameter name="a" value="1.0" />
# which would end up (due to the default NA for age group) as
# <TB.parameter name="a" value="1.0" age.group="NA" />
# though 
# <TB.parameter name="a" value="1.0" age.group="A0" />
# <TB.parameter name="a" value="1.0" age.group="A15" />
# would not be accepted and generate an error message and stop execution of the program
# 

# 2. fix code regarding col names (just those derived from XML Schema )
# 3. fix code regarding apply using rows of a data frame i.e. use plyr and ddply or adply
# 4. remove expanding parameter data frames from code (MUCH faster :-)
# 5. modify query to include matching NAs

# that is ALL :-)

