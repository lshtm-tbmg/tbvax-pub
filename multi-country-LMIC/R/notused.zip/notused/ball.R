source("./rkfncs-v1.R")


parameters = new.env()
with (parameters,{
  k = 1e4
  g = -10
  demping=0.5
  m=1
  r= 0.1
})

ball = function(t, y, params){
  h = y[1]
  v = y[2]
  n = 0
  if (h<params$r)
    n=1 
  a = v*params$demping+(h-params$r)*params$k*n/params$m
  dhdt=v
  dvdt=params$g-a
  y[1]=dhdt
  y[2]=dvdt
  y
}

require(microbenchmark)
epsilon=1e-5
microbenchmark(odeint(ball,c(1.,0.),0,5,eps=epsilon, yscal=c(1,1),hnext=0.1,hmin=1e-20,fparams=parameters,CONST=RKCONST),times=10)
out=odeint(ball,c(1.,0.),0,5,eps=epsilon,yscal=c(1,1),hnext=0.1,hmin=1e-20,fparams=parameters,CONST=RKCONST)
z=out[[1]]
out$nok
out$nbad


sel=(z$t[2:length(z$t)]-z$t[1:(length(z$t)-1)])<1e-3
(z$t[2:length(z$t)]-z$t[1:(length(z$t)-1)])[sel]
sel=(z$t[2:length(z$t)]-z$t[1:(length(z$t)-1)])>1e-1
(z$t[2:length(z$t)]-z$t[1:(length(z$t)-1)])[sel]
plot(z$t,z$h,type="b",pch="+",col="red")

z$t[(length(z$t)-10):length(z$t)]
z$h[(length(z$t)-10):length(z$t)]
z$v[(length(z$t)-10):length(z$t)]

