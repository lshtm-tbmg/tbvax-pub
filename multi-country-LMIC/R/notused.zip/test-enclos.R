aap = new.env()


test = function(noot, doit=F){
  with(noot,{
    argenv = parent.frame(1)$enclos
    if(argenv$doit){
      print("yes, do it")
    }
  })
}

test(aap,T)
