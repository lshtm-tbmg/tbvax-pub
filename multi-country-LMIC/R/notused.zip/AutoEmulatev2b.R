## Command line run
# Example usage:
# "C:\Program Files\R\R-4.0.2\bin\Rscript.exe" AutoEmulatev2.R -c RUS -n 5 -i 1

rm(list = ls())

library(lhs)
library(here)
library(emulatorr)

## Not strictly required, nowadays. Kept in for debugging purposes
if (F) {
  opts = list()
  opts$countrycode = "BEN"
  opts$seed = 7
  opts$workdir = here("tbvax")
  opts$countrydir = here("countries", opts$countrycode)
  opts$taskenvvar = "taskID"
}else{
  ## This bit is the bit that gets called.
  library(getopt)
  opts = getopt(
    matrix(
      c('countrycode', 'c', 1, 'character',
        'taskenvvar', 'e', 2, 'character',
        'seed', 's', 2, 'integer',
        'workdir', 'd', 2, 'character',
        'n_waves', 'n', 1, 'integer',
        'idemc', 'i', 2, 'integer'),
      byrow = T, ncol = 4
    )
  )
}
## Set up the path to the model code and import all dependencies
paths = list()
paths$src = here("R")
source(here(paths$src, "include-v11.R"))
## Set up all the other paths (to xml files and targets/inputs csv files)
paths = set.paths(paths, mydir = "", countrycode = opts$countrycode, targets = "target.csv", xml = "XMLinput.xml", parameters = "input.csv")

## Check we've at least got the country code!
assert_that(!is.null(opts$countrycode), msg = "Specify 3 character ISO country code with -c")
if (is.null(opts$taskenvvar)) opts$taskenvvar = "taskID"

checkBackup <- grepl(".*_backup.RData", dir(here(paths$country.output.dir)))
isBacked <- any(checkBackup)
if (isBacked) {
  backupfile <- dir(here(paths$country.output.dir), full.names = TRUE)[checkBackup]
  if (sum(checkBackup) > 1)
    backupfile <- backupfile[order(file.info(backupfile)$ctime, decreasing = TRUE)][1]
  else backupfile <- backupfile[1]
  load(backupfile)
  old_RUNID_TS <- RUNID_TS
}

## RUNID stuff: verbatim from Chathika
# Standard format for log file names, RData dumps and dump-frames
# Values in LOGNAME / OUTPUTTYPE can be replaced with whatever is necessary, 
# e.g., "model", "emulator", "backup" etc etc
# [RUNID_TS]_CONSOLEOUTPUT.err
# [RUNID_TS]_[LOGNAME].log
# [RUNID_TS]_[OUTPUTTYPE].RData
# [RUNID_TS]_DUMPFRAMES.rda
# Get RUNIDTS from environment variable - on the clusters, this is set by the cluster calling shell script
# This has a fixed format:
# YYYY-MM-DD-HHMM_JOBNAME_ARRAYID_COUNTRY
# It should be the common prefix for _all_ log filenames
# For ease of use, default ALL DATETIME stamps to UTC
RUNID_TS = Sys.getenv("RUNID_TS")
# If the RUNIDTS environment variable is blank, this implies the script is running locally.
# Set RUNID_TS to local defaults
if (RUNID_TS == "") {
  LTS <- format.Date(Sys.time(), format = "%Y-%m-%d-%H%M", tz = "UTC")
  RUNID_TS <- sprintf("%s_%s_%s", LTS, "LOCAL", opts$countrycode)
}

## Create the RData paths for backup, failure and success (for later)
if (isBacked) {
  file.remove(backupfilename)
}
backupfilename <- here(paths$country.output.dir, paste0(RUNID_TS, "_backup.RData"))
failurefilename <- here(paths$country.output.dir, paste0(RUNID_TS, "_failed.RData"))
successfilename <- here(paths$country.output.dir, paste0(RUNID_TS, "_complete.RData"))
if (isBacked) {
  save.image(file = backupfilename)
}

## Make sure output and log folders are created for writing into
dir.create(here(paths$country.dir, "logs"), showWarnings = F)
dir.create(here(paths$country.dir, "output"), showWarnings = F)

## Create loggers. The first is for the model; the second records information given during the emulation process.
logr <- create.logger(logfile = here(paths$country.dir, "logs", paste0(RUNID_TS, "_model.log")), level = "INFO")
logr2 <- create.logger(logfile = here(paths$country.dir, "logs", paste0(RUNID_TS, "_emulator.log")), level = "INFO")
logger <- function(level = "FATAL", msg = NULL) {
  levellog(logr, level = level, message = msg)
}
emlog <- function(level = "INFO", msg = NULL) {
  levellog(logr2, level = level, message = msg)
}

## Temporary directory to put modifed xml files in
dir.create(here("temp"), showWarnings = F)

## Runs a single parameter set, given the paths and parameter values.
# Reads in the unmodified XML file, makes changes, and saves the modified version in the temp folder
# before running the model using it.
run.one = function(paths, p_values){
  targets = read.targets(paths$country.targets)
  selected.parameters = read.csv(paths$country.params, stringsAsFactors = F, header=T, fileEncoding = 'UTF-8-BOM')
  constant            = grepl("^con.*", selected.parameters$dist) | !selected.parameters$choose
  params              = init.parameters(paths = paths)
  params$xml$doc      = update.constant.parameters(params, selected.parameters[constant,])
  params$xml$doc      = update.fitted.parameters(params, selected.parameters, p_values)
  write_xml(params$xml$doc, file = here("temp", "temp.xml"), option="as_xml")
  temp.paths          = paths
  temp.paths$country.xml = here("temp", "temp.xml")
  params              = init.parameters(paths = paths, params = params)
  output              = run.model(params, write.to.file=F)
  out                 = eval.output.vs.targets(output, targets, params)
  return(out)
}

## A function for batch-running multiple parameter sets in the model (basically a wrapper for run.one)
## A wrapper for running multiple points into the model
run.many <- function(points) {
  colnames(points)[colnames(points) == "emu"] <- 'etamul2000'
  outputs <- t(apply(points, 1, function(x) {
    point_res <- run.one(paths = paths, x)
    output_names <- paste0(point_res$name, point_res$year, sep = "")
    return(setNames(c(x, point_res$model), c(names(points), output_names)))
  }))
  out_dat <- data.frame(outputs)
  colnames(out_dat)[colnames(out_dat) == 'etamul2000'] <- 'emu'
  out_dat[is.na(out_dat)] <- 0
  out_dat[mapply(is.infinite, out_dat)] <- 0
  out_dat <- out_dat[which(apply(out_dat, 1, function(x) !(any(x < 0) || any(x > 1e10)))),]
  if ("TB_subclinpr_0_992019.5" %in% names(out_dat))
    out_dat <- out_dat[which(apply(out_dat, 1, function(x) x['TB_subclinpr_0_992019.5']) <= 1),]
  return(out_dat)
}

## Function for checking acceptability of points to targets.
in_bounds <- function(point, targets, out_stat = 'sum') {
  fits <- purrr::map_lgl(names(targets), function(i) {
    point[[i]] <= targets[[i]][2] && point[[i]] >= targets[[i]][1]
  })
  eval_func = get(out_stat)
  return(eval_func(fits))
}

## CSV generation function
create.csvs <- function(res) {
  res$n_hit <- apply(res, 1, in_bounds, target_bounds)
  res$uid <- apply(res, 1, function(x) digest::digest(paste0(x, collapse = ""), 'md5', serialize = FALSE))
  input.table <- res[,c('uid', 'n_hit', names(em_ranges))]
  colnames(input.table)[colnames(input.table) == "emu"] <- "etamul2000"
  name_year_pairs <- setNames(data.frame(do.call('rbind', purrr::map(names(target_bounds), ~stringr::str_match(., "(TB_\\w+_\\d+_\\d\\d|\\w+_\\d+_\\d\\d)(20\\d\\d\\.5)")[c(3,2)]))), c('year', 'name'))
  mapped_out <- purrr::map(1:nrow(res), function(x) {
    out_df <- name_year_pairs
    out_df$model <- unlist(res[x, names(target_bounds)], use.names = F)
    out_df$fit <- in_bounds(res[x,], target_bounds, 'c')
    out_df$uid <- rep(res[x,'uid'], nrow(out_df))
    return(out_df)
  })
  output.table <- data.frame(do.call('rbind', mapped_out))
  return(list(inp = input.table, outp = output.table))
}

if (!isBacked) {
  ## Try to import the input parameter ranges and target ranges
  tryCatch(
    {
      param.data <- subset(read.csv(paths$country.params, stringsAsFactors = FALSE, header = TRUE, fileEncoding = "UTF-8-BOM"), choose == TRUE)
      ranges <- setNames(purrr::map(1:nrow(param.data), ~c(param.data[.,'min'], param.data[.,'max'])), param.data$unique.name)
      ranges$etamul2000 <- NULL
  
      target.data <- read.csv(paths$country.targets, header = TRUE, stringsAsFactors = FALSE, fileEncoding = "UTF-8-BOM")
      target_bounds <- setNames(purrr::map(1:nrow(target.data), ~c(target.data[.,'lo'], target.data[.,'hi'])), purrr::map_chr(1:nrow(target.data), ~paste(target.data[.,'name'], target.data[.,'year'], sep = "")))
    },
    error = function(e) {
      emlog(level = "FATAL", paste("Could not read in parameter.csv and/or target.csv - missing?"))
      stop("Error in reading parameter file and/or target file")
    }
  )
  
  em_ranges <- ranges
  ## Not sure if this line is necessary now (but keeping it in for safety)
  names(em_ranges)[names(em_ranges) == "etamul2000"] <- "emu"
  
  ## Convert the target bounds into (val, sigma) pairs such that val +(-) 3*sigma represents the upper(lower) limit
  ci <- 0.997
  em_targets <- purrr::map(target_bounds, function(x) {
    if (x[1] == x[2]) {
      emlog(level = "WARN", "Target has interval length 0 (lo = hi). Changing to 10% bounds.")
      x[1] <- 0.9*x[1]
      x[2] <- 1.1*x[2]
    }
    est_mean <- (x[1]*qnorm(ci) - x[2]*qnorm(1-ci)) / (qnorm(ci) - qnorm(1-ci))
    est_sig <- (x[2] - x[1]) / (qnorm(ci) - qnorm(1-ci))
    return(list(val = est_mean, sigma = est_sig))
  })

  emlog(msg = "Finished preliminary set-up. Beginning first model runs.")

  ## Set up the global parameters for storing data
  results.list <- list()
  emulators.list <- c()
  targets.list <- c()
  
  # Define the number of points per wave.
  npoints <- 400
  
  # Generate an initial Latin Hypercube of runs. Take 25% more points than desired to guard against failures in weird model runs.
  initial_points <- data.frame(t(apply(randomLHS(npoints*1.05, length(ranges)), 1, function(x) purrr::map_dbl(ranges, ~.[1]) + x * purrr::map_dbl(ranges, ~.[2]-.[1]))))
  # Try to run these points.
  tryCatch(
    results.list[[1]] <- run.many(initial_points),
    error = function(e) {
      save.image(file = failurefilename)
      emlog(level = "FATAL", paste("Model runs failed - see errors for model failure reason:", e))
      stop("Model runs failed. Check emulator log for reason for failure.")
    }
  )
  # If the model runs have given more points than we need, sample the required number from the result.
  if (nrow(results.list[[1]]) > npoints){
    results.list[[1]] <- results.list[[1]][sample(nrow(results.list[[1]]), npoints),]
  }
} else {
    emlog(level = "INFO", paste("Restarted from save state", old_RUNID_TS, "- see corresponding logs."))
    emlog(level = "INFO", paste("Backup file", backupfile, "deleted and replaced with", backupfilename))
}
if (isBacked) {
  tab_hits <- setNames(data.frame(do.call('rbind', purrr::map(1:length(results.list), ~t(tabulate(apply(results.list[[.]], 1, in_bounds, target_bounds) + 1, nbins = length(target_bounds)+1))))), 0:length(target_bounds))
  write.csv(tab_hits, file = here(paths$country.output.dir, paste0(RUNID_TS, "_nhits.csv")), row.names = F)
} else {
  tab_hits <- setNames(data.frame(t(tabulate(apply(results.list[[length(results.list)]], 1, in_bounds, target_bounds) + 1, nbins = length(target_bounds)+1))), 0:length(target_bounds))
  write.csv(tab_hits, file = here(paths$country.output.dir, paste0(RUNID_TS, "_nhits.csv")), row.names = F)
}
if(!isBacked) rm(isBacked)
save.image(file = backupfilename)

# Keep track of if the emulation naturally exited the loop or was kicked out prematurely
kicked_out <- FALSE

## Take parameters from command line (if they were provided)
# Default is: perform 10 waves, use IDEMC if you get stuck
n_waves <- if(is.null(opts$n_waves)) 10 else opts$n_waves
use_idemc <- if(is.null(opts$idemc)) 1 else opts$idemc

## Start the loop over the waves!
for (i in length(results.list):n_waves) {
  emlog(msg = paste("Wave",i,"starting. Training emulators."))
  # Define the current wave ranges.
  e_ranges <- setNames(purrr::map(names(em_ranges), ~c(min(results.list[[i]][,.]), max(results.list[[i]][,.]))), names(em_ranges))
  # Train a set of emulators. Put in a try-catch in case something goes weird
  tryCatch(
    {
      samp <- sample(nrow(results.list[[i]]), ceiling(npoints/2))
      train <- results.list[[i]][samp,]
      valid <- results.list[[i]][!seq_along(results.list[[i]][,1])%in%samp,]
      pre_ems <- emulator_from_data(train, names(em_targets), e_ranges, quad = FALSE)
      ems <- purrr::map(seq_along(pre_ems), ~pre_ems[[.]]$adjust(train, names(em_targets)[[.]]))
    },
    error = function(e) {
      tryCatch(
        {
          samp <<- sample(nrow(results.list[[i]]), ceiling(npoints/2))
          train <<- results.list[[i]][samp,]
          valid <<- results.list[[i]][!seq_along(results.list[[i]][,1])%in%samp,]
          pre_ems <<- emulator_from_data(train, names(em_targets), e_ranges, quad = FALSE)
          ems <<- purrr::map(seq_along(pre_ems), ~pre_ems[[.]]$adjust(train, names(em_targets)[[.]]))
        },
        error = function(e2) {
          if (file.exists(backupfilename)) file.remove(backupfilename)
          save.image(failurefilename)
          emlog(level = "FATAL", paste("Emulator training failed - perhaps due to anomolous model point. Check diagnostics by hand.", e2))
          kicked_out <<- TRUE
          stop("Emulator training failed. Error details are in emulator log.")
        }
      )
    }
  )
  ## Keep an eye on the emulator uncertainty compared to the target uncertainty (for later in the loop)
  uncert_prods <- purrr::map_dbl(seq_along(pre_ems), ~sqrt(pre_ems[[.]]$u_sigma^2 + em_targets[[.]]$sigma)/em_targets[[.]]$sigma)
  emlog(msg = paste("Wave", i, "emulators trained. Performing diagnostics."))
  cutoff <- 3
  n_failed <- nrow(validation_diagnostics(ems, valid, names(em_targets), targets = em_targets, cutoff = cutoff, plt = F))
  if (n_failed > ceiling(nrow(valid)/4)) {
    cutoff <- 4
    n_failed <- nrow(validation_diagnostics(ems, valid, names(em_targets), targets = em_targets, cutoff = cutoff, plt = F))
    if (n_failed > ceiling(nrow(valid)/4)) {
      if (file.exists(backupfilename)) file.remove(backupfilename)
      save.image(file = failurefilename)
      emlog(level = "FATAL", paste("Emulator diagnostics failed.",  n_failed, "of 200 points did not pass diagnostics. See output RData file."))
      stop("Emulator diagnostics failed. Consult RData file to examine the points.")
    }
  }
  ## Order the emulators from most restrictive to least restrictive.
  tryCatch(
    {
      em_order <- purrr::map_dbl(seq_along(ems), ~sum(ems[[.]]$implausibility(results.list[[i]][,names(em_ranges)], em_targets[[.]], cutoff)))
    },
    error = function(e) {
      if (file.exists(backupfilename)) file.remove(backupfilename)
      save.image(file = failurefilename)
      emlog(level = "FATAL", paste("Something odd happened - see failure RData file:", e))
      stop("Unexpected error occured. See emulator log.")
    }
  )
  ## Calculate the acceptance rate for the current wave of emulators.
  accept_rate <- sum(nth_implausible(ems, results.list[[i]], em_targets, n = 1) <= cutoff)/nrow(results.list[[i]])
  emlog(msg = paste("Estimated acceptance rate for wave ",i," at implausibility cutoff ",cutoff,": ",accept_rate, sep =))
  if (accept_rate == 0) emlog(level = "WARN", "Point generation may have to increase implausibility threshold, or use IDEMC.")
  ems <- ems[order(em_order)]
  targs <- em_targets[order(em_order)]
  ## Append the (ordered) emulators and targets to the complete lists.
  emulators.list <- c(ems, emulators.list)
  targets.list <- c(targs, targets.list)
  emlog(msg = paste("Generating new runs from emulators at wave ", i, ".", sep = ""))
  ## Generate new points. At first, try 'naive' generation with an implausibility cutoff of 3.
  # If this fails to generate points, increase the implausibility by 1 up to a maximum of 6.
  new_points <- NULL
  while((is.null(new_points) || nrow(new_points) == 0) && cutoff < 6) {
    new_points <- generate_new_runs(emulators.list, e_ranges, npoints, targets.list, cutoff = cutoff, verbose = F)
    if (nrow(new_points) == 0) {
      emlog(level = "WARN", paste("Can't generate points at implausibility cutoff ", cutoff, ". Moving to cutoff ", cutoff+1, sep = ""))
      cutoff <- cutoff + 1
    }
  }
  # If this doesn't work, allow for one target to be missed.
  if (nrow(new_points) == 0) {
    emlog(level = "WARN", "Higher implausibility still not generating points. Allowing for one target to be missed.")
    new_points <- generate_new_runs(emulators.list, e_ranges, npoints, targets.list, cutoff = cutoff, nth = 2, verbose = F)
  }
  # If this still hasn't worked, and idemc is enabled, use that to generate points (but this is last-ditch stuff)
  if (nrow(new_points) == 0) {
    if (use_idemc == 1) {
      tryCatch(
        {
          emlog(msg = paste("Default point generation failed. Using IDEMC..."))
          idemc_ladder <- IDEMC(rbind(train, valid)[,names(e_ranges)], emulators.list, targets.list, floor(npoints/2), npoints, p = 0.3, imp = cutoff)
          new_points <- idemc_ladder[[length(idemc_ladder)]]
        },
        error = function(e) {
          if(file.exists(backupfilename)) file.remove(backupfilename)
          save.image(file = failurefilename)
          emlog(level = "FATAL", "Something went wrong in IDEMC generation. See output RData file.")
          kicked_out <<- TRUE
          stop("IDEMC generation failed.")
        }
      )
    }
    else {
      if(file.exists(backupfilename)) file.remove(backupfilename)
      save.image(file = failurefilename)
      emlog(level = "FATAL", "Parameter space too small to be explored without IDEMC generation (perhaps overrestrictive targets or parameter ranges). Consider constraints, or rerun with '-i 1' in command line.")
      kicked_out <<- TRUE
      stop("Default point generation failed, and IDEMC is not enabled.")
    }
  }
  if (!kicked_out) {
    ## If successful, put the new points in the model!
    emlog(msg = "New points generated. Running model for these new points.")
    results.list[[i+1]] <- run.many(new_points)
    ## Save a backup in case something unexpected happens (i.e. an error that isn't being actively handled)
    save.image(file = backupfilename)
    ## Append this wave's results to tab_hits
    tab_hits <- setNames(data.frame(t(tabulate(apply(results.list[[length(results.list)]], 1, in_bounds, target_bounds)+1, nbins = length(target_bounds)+1))), 0:length(target_bounds))
    write.table(tab_hits, file = here(paths$country.output.dir, paste0(RUNID_TS, "_nhits.csv")), append = T, col.names = F, row.names = F, sep = ",")
    ## If the emulator uncertainties are practically the same as the target uncertainties, no greater predictive power will be gained from doing more waves.
    # So kick out early.
    if (all(uncert_prods < 1.2)) {
      emlog(msg = "All emulator uncertainties are comparable to target uncertainties, and further waves will not be useful. Terminating early.")
      break
    }
  }
}

## Provided we've not been kicked out due to an error, we've been successful. Save the success RData file and generate final csvs.
if (!kicked_out) {
  emlog(msg = paste(i, "waves completed: check environment for points."))
  save.image(file = successfilename)
  if (file.exists(backupfilename)) file.remove(backupfilename)
  total_runs <- do.call('rbind', results.list)
  good_runs <- total_runs[which(apply(total_runs, 1, in_bounds, target_bounds) == length(em_targets)),]
  towrite <- if (nrow(good_runs) != 0) good_runs else results.list[[length(results.list)]]
  csvs <- create.csvs(towrite)
  write.csv(csvs$inp, file = here(paths$country.output.dir, paste0(RUNID_TS, "_inputPoints.csv")))
  write.csv(csvs$outp, file = here(paths$country.output.dir, paste0(RUNID_TS, "_outputPoints.csv")))
}
