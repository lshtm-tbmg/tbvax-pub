# NOTE: large parts of this code should be rewritten to take advantage of FP principles and reduce duplication of code

aging.and.births.and.update.contact.matrix.event <- function(t,X,p){
  if (t>p$years[1]){
    Y = matrix(X,p$nVXaSESRISKHIVTB,p$nAGES) ; rownames(Y)=p$VXaSESRISKHIVTB ; colnames(Y)=names(p$AGES)
    if (t==as.numeric(rownames(p$removalrate)[1])){
      Y = scale.alive.population(Y,p)
    }
    alive.by.age.group = colSums(Y[p$ALIVE,])
    update.contact.matrix(p, alive.by.age.group)
    dY       = t(tcrossprod(p$aging.matrix, Y))
    dY[!p$ALIVE,] = 0. # the dead do not age
    if (p$birthrate.is.number){
      dY[,1] = dY[,1] + p$birthrate(t)
    }else{
      dY[,1] = dY[,1] + p$birthrate(t)*sum(alive.by.age.group)*p$at.birth # it would be possible to have dead newborns (HIV)
    }
    Y = Y + dY
    # allow deaths to cumulate over time
    # alternative:
    Y[!p$ALIVE,]=0. 
    if (sum(is.nan(Y))>0){
      logger(level='FATAL',msg=paste0(" at t = ",t," NaNs in state variables ; reduce euler / rk2 / rk4 time step"))
    }else if (sum(Y<0.)>0){
      neg = p$run.params$min.value.for.state.var
      Y[Y<0. & Y>=neg] = 0.
      if (sum(Y<neg)>0){
        idx = which(Y<neg)
        r   = idx %% nrow(Y)
        c   = (idx %/% nrow(Y))+1 
        for (i in seq_along(idx)){
          logger(level='WARN',paste0(" at t = ",t," state variables < ",neg," :",
          " state = ",rownames(Y)[r[i]]," ; age group = ",colnames(Y)[c[i]],"; value = ",signif(Y[r[i],c[i]])," ; please reconsider parameter values"))
        }
      }
    }
    return(as.vector(Y))
  }else{
    return(X)
  }
}

derivs.Tr=function(t,Y,Tr,fn){
  tparams = Tr$timed.parameters
  if (is.null(tparams)){
    return(fn(Tr,Y))
  }
  else{
    mult=1.0
    nms = names(tparams)
    for (nm in nms)
      mult = mult * get(nm,envir=tparams)(t)
    return(fn(Tr,Y,mult))
  }
}

foi=function(t,Y,parms){
  infc = matmul.by.age.group(parms$Infc, Y) # always > 0
  mult = 1.0
  tparams = parms$Tm$timed.parameters
  if (!is.null(tparams)){
    nms = names(tparams)
    for (nm in nms)
      mult = mult * get(nm,envir=tparams)(t)
  }
  mat  = (colSums(infc)/colSums(Y[parms$ALIVE,]))
  mat[is.nan(mat)]=0.
  mult * parms$DAYSPERYEAR * rowSums(parms$contacts.M %*% mat) # return the foi ; foi is a column vector of foi by age ; ipv tcrossprod(M,infc)
}  

derivs.Tm=function(t,Y,parms,fn){
  foi = foi(t=t,Y=Y,parms=parms)
  susc = fn(parms$Tm, Y)
  if (is.list(susc)){
    dY.in  = t(t(susc$dY.in ) * foi )
    dY.out = t(t(susc$dY.out) * foi )
    return( list(dY=(dY.in+dY.out),dY.in=dY.in,dY.out=dY.out) )
  }else{
    return( t(t(susc) * foi ))
  }
}

derivs.inci.common=function(t=NA,Y=NA,p=NA,p.inci=NA){ 
  dX=NULL
  x_inci = as.numeric(p.inci$inci[p.inci$inci.fn(t),])
  if (sum(x_inci)>0){
    if (!is.null(p.inci$inci.trend.fn)){
      x_inci = x_inci * p.inci$inci.trend.fn(t)
    }
    X = t(Y)
    dX = 0*X
    if (!p.inci$inci.proportions){
      if (p.inci$inci.denominator=="all"){
        denom   = rowSums(X[,p.inci$susc])
        denom   = sapply(denom, max, 1e-6)
        scaleby = rowSums(X[,p.inci$alive])/denom
        scaleby = sapply(sapply(scaleby, max, 1.),min,10)
      }else{
        scaleby = 1.0
      }
    }else{
      if (p.inci$inci.denominator=="all"){
        denom   = rowSums(X[,p.inci$alive])
      }else{
        denom   = rowSums(X[,p.inci$susc])
      }
      denom   = sapply(denom, max, 1e-3)
      scaleby = sum(denom)/denom
    }
    dX[,p.inci$susc]   = x_inci * X[,p.inci$susc] * scaleby # OK - that is simple
  }
  dX
}  

derivs.inci=function(t=NA,Y=NA,p=NA,p.inci=NA){ 
  dX = derivs.inci.common(t=t,Y=Y,p=p,p.inci=p.inci)
  if (!is.null(dX)){
    return(as.matrix(p.inci$inci.matrix %*% t(dX)))
  }else{
    return(0.*Y)
  }
}
derivs.inci.in.out=function(t=NA,Y=NA,p=NA,p.inci=NA){ 
  dX = derivs.inci.common(t=t,Y=Y,p=p,p.inci=p.inci)
  if (!is.null(dX)){
    P = Q = p.inci$inci.matrix
    P[p.inci$inci.matrix<0]=0.
    Q[p.inci$inci.matrix>0]=0.
    dY.in  = P %*% t(dX)
    dY.out = Q %*% t(dX) 
    return(list(dY=as.matrix(dY.in+dY.out),dY.in=as.matrix(dY.in),dY.out = as.matrix(dY.out)))     
  }else{
    return(list(dY=0.*Y,dY.in=0.*Y,dY.out = 0.*Y))     
  }
}

# in principe kunnen ART matrixen worden gecombineerd (van HIV1 -> ART1 en van HIV2 -> ART2)
# de techniek voor HIV en ART incidentie kunnen ook worden gebruikt voor vaccinatie
# data: file met kolommen YEAR from to en leeftijden in de overige kolommen
# YEAR from to    0 5 10 etc
# 2025 never vac  0.2 0.4 0.8 etc
# In feite is de techniek identiek voor incidentie van sterft, HIV, vaccinatie .....

derivs.demography=function(t,Y,parms,dY.deaths){ 
  # dY.TB.and.HIV.deaths : entry into TBdead etc i.e. only for Y[!parms$ALIVE,]
  # note that dY.TB.and.HIV.deaths is positive i.e. moving into death states
  # whereas deathrate < 0 if decreasing towards next higher age group and year
  mu = get.removalrate(parms,t) + dY.deaths / colSums(Y[parms$ALIVE,])
  mu[is.infinite(mu) | is.nan(mu)]=0.
  X = t(Y)
  dX = 0*X
  dX[,parms$ALIVE]   =  -mu * X[,parms$ALIVE] # we need to multiply with -mu as the death matrix has -1 in cells to move from
  dY = parms$DEATH.matrix %*% t(dX) 
  as.matrix(dY)     
}

scale.alive.population=function(Y,parms){
  Y[!parms$ALIVE,] = 0.
  ini.age.dist     = apply(parms$y.ini,2,sum)
  current.age.dist = apply(Y,2,sum)
  Y = scale(Y,center=F,scale = current.age.dist / ini.age.dist) 
  Y[is.nan(Y) | is.infinite(Y)]=0 
  Y 
}

colsums = function(M){
  if (is.null(dim(M)))
    return(sum(M))
  else
    return(colSums(M))
}

# called for every t listed and using prev matrix Y as input
derivs.deSolve=function(t,X,p){
  ntimesteps <<- ntimesteps+1
  #if (p$print.t){
  #if (abs(t %% 1)<1e-6)
  #    cat('\n')
  #cat(formatC(t,digits=3,format="f")," ")
  #}
  Y = matrix(X,p$nVXaSESRISKHIVTB,p$nAGES)
  rownames(Y)=p$VXaSESRISKHIVTB
  colnames(Y)=names(p$AGES)

  dY.Ti = matmul.by.age.group(p$TBp,Y)
  dY =  derivs.Tm(t,Y,p,fn=matmul.by.age.group) + dY.Ti
  
  for (i in seq_along(p$inci$TB)){
    dY = dY + derivs.inci(t,Y,p,p$inci$TB[[i]])
  }
  
  if (!is.null(p$TBtr)){
    for (i in seq_along(p$TBtr)){
      dY = dY + derivs.Tr(t,Y,p$TBtr[[i]],fn=matmul.by.age.group)
    }
  }
  
  # BUG fix in v17: the function dY.nat.death was called with dY.Ti and dY.HIVp so no other causes of TB and HIV death were included
  # other possible causes are Tr and inci
  
  if (p$nHIV>1){
    dY.HIVp = matmul.by.age.group(p$HIVp, Y)
    if (!is.null(p$HIVtr)){
      for (i in seq_along(p$HIVtr)){
        dY.HIVp = dY.HIVp + derivs.Tr(t,Y,p$HIVtr[[i]],fn=matmul.by.age.group)
      }
    }
    dY = dY + dY.HIVp 
    for (i in seq_along(p$inci$HIV))
      dY = dY + derivs.inci(t,Y,p,p$inci$HIV[[i]])
  }
  
  if (p$nRISK>1 & !is.null(p$RISKp))
    dY = dY + matmul.by.age.group(p$RISKp, Y)
  if (p$nSES>1  & !is.null(p$SESp))
    dY = dY + matmul.by.age.group(p$SESp, Y)
  if (p$nVXa>1){
    if(!is.null(p$VXap))
      dY = dY + matmul.by.age.group(p$VXap, Y)
    for (i in seq_along(p$inci$VXa))
      dY = dY + derivs.inci(t,Y,p,p$inci$VXa[[i]])
  }
  
  # include TB and HIV deaths (and possibly deaths due to SES, RISK, what else) here
  dY.demog = derivs.demography(t,Y,p,colSums(dY[!p$ALIVE,]))
  dY = dY + dY.demog

  assert_that(sum(is.nan(dY))==0,msg=paste0("NaNs in derivs.deSolve @ t=",t))
  assert <<- F
  # note that we could output the full dY or detailed deaths by not summing over columns
  list(dY=as.vector(dY),dY.saved=as.vector(colSums(dY[!p$ALIVE,])),dY.demog = as.vector(colSums(dY.demog)))
}

run.deSolve = function(params = NULL){
  assert <<- T
  ntimesteps <<- 0
  started.at = proc.time()
  rawout = rk(   y = as.vector(params$y.ini), 
             times    = params$years, 
             func     = derivs.deSolve, 
             parms    = params, 
             rtol     = params$run.params$rtol, 
             atol     = params$run.params$atol, 
             method   = params$run.params$method,
             maxsteps = params$run.params$maxsteps,
             hini     = params$run.params$hini,
             hmin     = params$run.params$hmin,
             events   = list(func = aging.and.births.and.update.contact.matrix.event, 
                          time = unique(trunc(params$years))[-1]))
  if (ntimesteps>(max(params$years)-min(params$years))*50){
    logger(level='WARN',msg=paste0(" ntimesteps = ",ntimesteps," in ",timetaken(started.at)," which may be excessive ; please reconsider parameter values"))
  }else{
    logger(level='INFO',msg=paste0(" ntimesteps = ",ntimesteps," in ",timetaken(started.at)))
  }

  t         = rawout[,1]
  out       = vector("list",length(t)) 
  dYdeadfr  = vector("list",length(t)) 
  dYadjfr   = vector("list",length(t)) 
  nr        = params$nVXaSESRISKHIVTB
  nc        = params$nAGES
  N         = nr*nc
  for (i in seq_along(t)){
      M = matrix(rawout[i,2:(N+1)],nr,nc)
      colnames(M)=params$AGES
      rownames(M)=params$VXaSESRISKHIVTB
      out[[i]] = M
      P = as.vector(rawout[i,(N+2):(N+nc+1)])
      names(P)=params$AGES
      dYdeadfr[[i]] = P / colSums(M[params$ALIVE,])
      Q = as.vector(rawout[i,(N+nc+2):(N+2*nc+1)])
      names(Q)=params$AGES
      dYadjfr[[i]] = Q / colSums(M[params$ALIVE,])
  }
  list(times=t,state=out,dstatefr=dYdeadfr,dadjfr=dYadjfr)
}

run.model = function(p=NULL, write.to.file=F, path=NULL){
  out           = run.deSolve(p)
  logger(level="DEBUG",msg="successful result of run.deSolve()")
  if (!is.na(p$final.population.as.fraction)){
    nyrz  = length(out$times)
    y.fin   = out$state$Y[[nyrz]]
    y.alive = y.fin[p$ALIVE,]
    y.alive = y.alive[rowSums(y.alive)>1e-6,]
    y.alive.frac = y.alive/sum(y.alive)
    write.table(as.data.frame(y.alive.frac),file=p$final.population.as.fraction,sep="\t", row.names = T, quote=F)
  }
  demography.output = demography.from.model.run(out,params=p)

  prev.output = generate.prevalence.output(t=out$times,state=out$state,fparams=p)
  if (suppress_zeros_stocks){
    prev.output = prev.output[value>1e-4,]
  }
  logger(level="DEBUG",msg="successful generation of prevalence output from generate.prevalence.output()")

  flow.output = generate.output(incidence.from.model.run(out,p),params=p)
  if (suppress_zeros_flows){
    flow.output = flow.output[abs(value)>1e-6,]
  }
  logger(level="DEBUG",msg="successful generation of flow output from generate.flow.output()")
  
  if (write.to.file){
    filename = paste0(create.filename(path=path,params=p,runtype="stocks"),".txt")
    write.output(prev.output,filename)
    filename = paste0(create.filename(path=path,params=p,runtype="flows"),".txt")
    write.output(flow.output,filename)
    filename = paste0(create.filename(path=path,params=p,runtype="population"),".txt")
    write.output(demography.output$pop,filename)
    filename = paste0(create.filename(path=path,params=p,runtype="TBHIV_X"),".txt")
    write.output(demography.output$deaths,filename)
    filename = paste0(create.filename(path=path,params=p,runtype="frdTBHIV_X"),".txt")
    write.output(demography.output$ddeath.dt.as.frac,filename)
    filename = paste0(create.filename(path=path,params=p,runtype="frdpopadj"),".txt")
    write.output(demography.output$dadjdt.as.frac,filename)
    return(list(deaths=demography.output$deaths,population=demography.output$pop,stocks=prev.output,flows=flow.output,out=out))
  }else{
    return(list(deaths=demography.output$deaths,population=demography.output$pop,stocks=prev.output,flows=flow.output,out=out))
  }
}


