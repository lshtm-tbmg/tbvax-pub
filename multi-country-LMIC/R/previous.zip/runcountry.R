  # "c:\Program Files\R\R-4.0.3\bin\Rscript.exe" runcountry.R -c CHN -m RB
  # or just
  # "c:\Program Files\R\R-4.0.3\bin\Rscript.exe" runcountry.R -c CHN 
  # 
  # There are defaults for all parameters except country code [-c CHN]
  # the default folder structure from either the root folder (i.e. where this script is located) or the users folder (mydir) [-m mydir]
  # is encoded in the paths list (see include-v11.R):
  # paths$country.code       = countrycode
  # paths$my.dir             = here::here(mydir)
  # paths$logfile            = here::here(mydir,"logs/logfile.log")
  # paths$countries          = here::here(mydir,countries.dir)
  # paths$country.dir        = here::here(mydir,countries.dir,countrycode)
  # paths$country.log.dir    = here::here(mydir,countries.dir,countrycode,"logs")
  # paths$country.data.dir   = here::here(mydir,countries.dir,countrycode,"data")
  # paths$country.params     = here::here(mydir,countries.dir,countrycode,"parameters",parameters)
  # paths$country.targets    = here::here(mydir,countries.dir,countrycode,"parameters",targets)
  # paths$country.xml        = here::here(mydir,countries.dir,countrycode,"parameters",xml)
  # paths$country.xmlrun     = here::here(mydir,countries.dir,xmlrun)
  # paths$country.output.dir = here::here(mydir,countries.dir,countrycode,"output")
  
  rm(list=ls())
  here::here()
  paths = list()
  paths$src = here::here("R")
  source(here::here(paths$src,"include-v11.R"))
  
  if (T){
    mydir            = "."
    logr <- create.logger(logfile = here::here(mydir,"logs/logfile.log"), level="DEBUG")
    logger <- function(level='FATAL',msg=NULL){
      levellog(logr,level=level,message=msg)
    }
    countrycode      = "TZA"
    
    paths            = set.paths(paths, mydir=".", 
                                 countries.dir = "countries",
                                 countrycode = countrycode, 
                                 targets="target.csv", 
                                 xml = "XMLinput.xml",
                                 # baseline = "XMLinput",
                                 # xml = "XMLinput_chris_updated_to_2_0_3.xml", 
                                 parameters="input.csv")
    
    opts=list()
    opts$countrycode = countrycode
    opts$seed        = 7
    opts$taskenvvar  = "taskID"
    options(warn=2)
  }else{
    require(getopt)
    opts = getopt(matrix(c('countrycode','c',1,"character",
                           'taskenvvar','e',2,"character",
                           'targets','t',2,"character",
                           'xmlinput','x',2,"character",
                           'seed','s',2,"integer",
                           'mydir','m',2,"character",
                           'countries.dir','d',2,"character",
                           'warn','w',2,"integer",
                           'baseline','b',2,"character"), byrow=TRUE, ncol=4))
    if(is.null(opts$mydir )){opts$mydir  = "" }
    logr <- create.logger(logfile = here::here(mydir,"logs/logfile.log"), level="DEBUG")
    logger <- function(level='FATAL',msg=NULL){
      levellog(logr,level=level,message=msg)
    }
    assert_that(!is.null(opts$countrycode),msg=" specify either 3 char ISO countrycode with or the LMIC country number with -c")
    countrynum = strtoi(opts$countrycode)
    if (!is.na(countrynum)){
      countries = read.csv(here("countries/LMIC_numbers.csv"),fileEncoding = "UTF-8-BOM",stringsAsFactors = F, header=T)
      sel = countries$CountryNumber == countrynum
      assert_that(sum(sel)==1,msg="country number not found or multiple matches in LMIC_numbers.csv")
      opts$countrycode = countries[sel,]$CountryCode
    }
    if(is.null(opts$warn)){options(warn=2)}
    if(is.null(opts$countries.dir)){opts$countries.dir = "countries"}
    if(is.null(opts$taskenvvar)){opts$taskenvvar = "taskID"}
    if(is.null(opts$targets )){opts$targets = "target.csv"}
    if(is.null(opts$xmlinput)){opts$xml = "XMLinput.xml" }
    paths = set.paths(paths,
                      opts$mydir,
                      countries.dir = opts$countries.dir,
                      countrycode = opts$countrycode, 
                      targets=opts$targets, 
                      xml=opts$xml, 
                      baseline=opts$baseline)
    if (is.null(opts$seed)){set.seed(NULL)} else{ set.seed(opts$seed)}
  }

  run.one = function(paths=NULL, countrycode=NULL, baseline=NULL, xml="XMLinput.xml",targets="target.csv",parameters="input.csv"){

    assert_that(!is.null(paths$countries.dir),msg="paths$countries.dir should not be NULL")
    assert_that(!is.null(countrycode),msg="countrycode should not be NULL")
    
    with(paths,{
      country.code       = countrycode
      country.dir        = here::here(countries.dir,countrycode)
      country.log.dir    = here::here(country.dir,"logs")
      country.data.dir   = here::here(country.dir,"data")
      country.params.dir = here::here(country.dir,"parameters")
      country.output.dir = here::here(country.dir,"output")
      country.params     = here::here(params.dir,parameters)
      country.targets    = here::here(params.dir,targets)
      country.xml        = here::here(params.dir,xml)
      country.baseline   = here::here(params.dir,baseline)
    })
    
    if (is.null(logger)){
      RUNID_TS = Sys.getenv("RUNID_TS")
      # If the RUNIDTS environment variable is blank, this implies the script is running locally.
      # Set RUNID_TS to local defaults
      if (RUNID_TS == "") {
        LTS <- format.Date(Sys.time(), format = "%Y-%m-%d-%H%M", tz = "UTC")
        RUNID_TS <<- sprintf("%s_%s_%s", LTS, "LOCAL", countrycode)
      }
      ## Create model logger. 
      logr <- create.logger(logfile = here(paths$country.dir, "logs", paste0(RUNID_TS, "_model.log")), level = "INFO")
      logger <<- function(level = "INFO", msg = NULL) {
        levellog(logr, level = level, message = msg)
      }
    }
    
    targets = read.targets(paths$country.targets)
    model   = init.model(paths=paths)
    output  = run.model(model, write.to.file=T)
                        # , baseline = opts$baseline)
    # output is a list with the following elements:
    # flow (i.e. inflows and outflows), prev (prevalence), and 
    # out: the simulation results for each of the time points in out$times as 
    # a list of matrices of state (rows) vs age (cols)) in out$state
    out    = eval.output.vs.targets(output,targets,model)
    out    = cbind(country=model$run.params$countrycode,out)
    outfname  = paste0(create.filename(paths$country.output, params = model, runtype = "hits"),".txt")
    write.table(out,outfname,sep="\t",quote=F, row.names=F)
    print(outfname)
  }
  run.one(paths, opts$countrycode)
  microbenchmark::microbenchmark(run.one(paths, opts$countrycode),times=5)
                                
  microbenchmark::microbenchmark(init.model(paths=paths),times=5)
  
  
  
