require(tools)
require(assertthat)
require(stringi)
require(Matrix)
require(xml2)
require(digest)
require(deSolve)
require(data.table)
require(FME)
require(minpack.lm)
require(lubridate)
require(log4r)
setDTthreads(threads=1) 
source(paste0(opts$sourcedir,"/TBVx-age-related-fncs-v11.R"))
source(paste0(opts$sourcedir,"/TBVx-matrix-fncs-v10.R"))
source(paste0(opts$sourcedir,"/TBVx-data-reading-fncs-v9.R"))
source(paste0(opts$sourcedir,"/TBVx-parsing-xml-fncs-v11.R"))
source(paste0(opts$sourcedir,"/TBVx-initialization-fncs-v13.R"))
source(paste0(opts$sourcedir,"/TBVx-derivs-v14.R"))
source(paste0(opts$sourcedir,"/TBVx-output-fncs-v14.R"))
source(paste0(opts$sourcedir,"/TBVx-output-query-fncs-v4.R"))
source(paste0(opts$sourcedir,"/TBVx-mod-xml-fncs-v2.R"))
source(paste0(opts$sourcedir,"/TBVx-FME-fncs-v6.R"))

model_version_ = "1_8_4"
modelversion = function(){
  return(model_version_)
}



