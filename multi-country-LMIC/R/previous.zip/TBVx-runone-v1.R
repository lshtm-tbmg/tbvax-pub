set.options=function(){
  options("warnPartialMatchDollar"=T)
}
redirect.errors=function(paths){
  sink(file(paths[["logfile"]],'wt'),append=T,type="message")
}

set.paths = function(mydir         = here(), 
                        countries     = "countries", 
                        countrycode   = NA, 
                        xml           = NA, 
                        parameters    = NA, 
                        targets       = NA, 
                        baseline      = NA, 
                        VXa.incidence.files=NA){
  
  assert_that(!is.null(paths),msg="model$paths should not be NULL")
  
  paths        = update.paths(paths,mydir,countries,countrycode,targets,xml,baseline,parameters,VXa.incidence.files)
  modlog       <<- setup.model.log(paths)
  paths
}

write.updated.xml = function(parameters=NULL, xml=NULL){
  assert_that(!is.null(parameters))
  assert_that(!is.null(xml))
  write_xml(parameters$xml$doc, file = here(parameters$paths$params.dir, xml), option="as_xml")
}

merge.stocks.and.flows=function(output){
  widened.stocks = cbind(output$stocks[,1:7],dim=NA,subject=NA,flow=NA,output$stocks[,8:10])
  rbind(widened.stocks,output$flows)
}

update.paths = function(paths         = NULL,
                        mydir         = here(), 
                        countries     = "countries", 
                        countrycode   = NA, 
                        targets       = NA, 
                        xml           = NA, 
                        baseline      = NA, 
                        parameters    = NA, 
                        VXa.incidence.files=NA){
  assert_that(!is.null(paths),msg="paths should not be NULL ")
  assert_that(is.environment(paths),msg="paths should be an R environment")
  if (!(mydir)==here()){ paths$mydir          = mydir}
  paths$country.code  = countrycode   
  paths$xml           = xml
  paths$parameters    = parameters
  paths$targets       = targets
  paths$baseline      = baseline
  paths$VXa.incidence.files = VXa.incidence.files 
  assert_that(!is.na(paths$country.code),msg="country code should not be NA")
  assert_that(!is.na(paths$xml),msg="xml should not be NA")
  paths$countries      = countries 
  paths$country.dir    = here(mydir,countries,countrycode) 
  paths$log.dir        = here(paths$country.dir,"logs")
  paths$data.dir       = here(paths$country.dir,"data")
  paths$params.dir     = here(paths$country.dir,"parameters")
  paths$output.dir     = here(paths$country.dir,"output")
  if (!is.na(paths$xml))       { paths$xml        = here(paths$params.dir,xml)}
  if (!is.na(paths$parameters)){ paths$parameters = here(paths$params.dir,parameters)}
  if (!is.na(paths$targets))   { paths$targets    = here(paths$params.dir,targets)}
  if (!is.na(paths$baseline))  { paths$baseline   = here(paths$params.dir,baseline)}
  if (!is.na(baseline)){
    popadj.fnames=dir(paths$output.dir,pattern=paste0("^\\[",countrycode,"\\].*\\[",baseline,"\\]\\[dfrPOPadj\\]\\.txt"))
    if (length(popadj.fnames)!=1){
      modlog(level='FATAL', msg= paste0("either none or multiple matches for baseline popadj output of ",baseline))
    }
    assert_that(length(popadj.fnames)==1,msg=paste0("either none or multiple matches for baseline popadj output of ",baseline))
    paths$popadj = here::here(paths$output.dir,popadj.fnames[1])
    bgxfr.fnames=dir(paths$output.dir,pattern=paste0("^\\[",countrycode,"\\].*\\[",baseline,"\\]\\[dfrBGx\\]\\.txt"))
    if (length(bgxfr.fnames)!=1){
      modlog(level='FATAL', msg= paste0("either none or multiple matches for baseline background death fractions output of ",baseline))
    }
    assert_that(length(bgxfr.fnames)==1,msg=paste0("either none or multiple matches for baseline background death fractions output of ",baseline))
    paths$bgxfr = here::here(paths$output.dir,bgxfr.fnames[1])
  }
  paths
}

setup.model.log=function(paths){
  assert_that(!is.na(paths[["countries"]]),msg="paths$countries should not be NULL")
  assert_that(!is.na(paths[["country.code"]]),msg="paths$country.code should not be NULL")
  RUNID_TS = Sys.getenv("RUNID_TS")
  if (RUNID_TS == "") {
    LTS <- format.Date(Sys.time(), format = "%Y-%m-%d-%H%M", tz = "UTC")
    RUNID_TS <- sprintf("%s_%s_%s", LTS, "LOCAL", paths$country.code)
  }
  logr <- create.logger(logfile = here(paths$log.dir, paste0(RUNID_TS, "_model.log")), level = "INFO")
  return(function(level = "INFO", msg = NULL) { levellog(logr, level = level, message = msg)})
}

update.model.parameters = function(model.params=NULL,new.parameter.values=NULL){
  assert_that(!is.null(model.params),msg="model.params should not be NULL")
  paths = model.params$paths
  if (is.na(paths$parameters)){ 
    return(model.params)
  }
  selected.parameters  = read.csv(paths$parameters, stringsAsFactors = F, header=T, fileEncoding = 'UTF-8-BOM')
  constant             = grepl("^con.*", selected.parameters$dist) | !selected.parameters$choose
  model.params$xml$doc = update.constant.parameters(model.params, selected.parameters[constant,])
  if (!is.null(new.parameter.values)){ 
    model.params$xml$doc = update.fitted.parameters(model.params, selected.parameters, new.parameter.values)
  }
  return(model.params)
}


write.econ.output = function(output=NULL,model.params=NULL){
  
  fncname = match.call()[[1]]
  assert_that(!is.null(model.params),msg=paste("paths should not be NULL in",fncname))
  assert_that(!is.null(output),msg=paste("output should not be NULL in",fncname))

  if (!is.null(output$population)){
    filename = paste0(create.filename(model.params$paths$output.dir, model.params,runtype="POP"),".txt")
    write.output(output$population,filename)
    filename = paste0(create.filename(model.params$paths$output.dir, model.params,runtype="dBGx"),".txt")
    write.output(output$dBGx,filename)
    filename = paste0(create.filename(model.params$paths$output.dir, model.params,runtype="dTBHIVx"),".txt")
    write.output(output$dHIVTBx,filename)
    filename = paste0(create.filename(model.params$paths$output.dir, model.params,runtype="dALLx"),".txt")
    write.output(output$dALLx,filename)
    if (!model.params$intervention){
      filename = paste0(create.filename(model.params$paths$output.dir, model.params,runtype="dfrBGx"),".txt")
      write.output(output$dfrBGx,filename)
      filename = paste0(create.filename(model.params$paths$output.dir, model.params,runtype="dfrPOPadj"),".txt")
      write.output(output$dfrPOPadj,filename)
    }
  }
}

write.stocks.and.flows = function(output=NULL,model.params=NULL){
  fncname = match.call()[[1]]
  assert_that(!is.null(model.params$paths),msg=paste("paths should not be NULL in",fncname))
  assert_that(!is.null(output),msg=paste("output should not be NULL in",fncname))
  filename = paste0(create.filename(model.params$paths$output.dir, model.params,runtype="stocks"),".txt")
  write.output(output$stocks,filename)
  filename = paste0(create.filename(model.params$paths$output.dir, model.params,runtype="flows"),".txt")
  write.output(output$flows,filename)
}

get.target.hits = function(output=NULL,model.params=NULL){
  assert_that(!is.null(model.params),msg="model.params should not be NULL when evaluating targets")
  assert_that(!is.na(model.params$paths$targets),msg="targets.csv not set")
  targets = read.targets(model.params$paths$targets)
  hits    = eval.output.vs.targets(output,targets,model.params)
  hits    = cbind(country=model.params$run.params$countrycode,hits)
  hits
}

write.targets = function(output=NULL,model.params=NULL){
  assert_that(!is.null(output$hits),msg="output$hits should not be NULL when writing targets")
  outfname  = paste0(create.filename(model.params$paths$output.dir, model.params, runtype = "hits"),".txt")
  write.output(output$hits,outfname)
}
constant.parameters = function(parameters.file=NULL){
  fncname = match.call()[[1]]
  assert_that(!is.null(parameters.file),msg=paste("parameters.file should not be NULL in",fncname))
  selected.parameters = read.csv(parameters.file, stringsAsFactors = F, header=T, fileEncoding = 'UTF-8-BOM')
  constant            = grepl("^con.*", selected.parameters$dist) | !selected.parameters$choose
  selected.parameters[constant,]
}

fitted.parameters = function(parameters.file=NULL){
  fncname = match.call()[[1]]
  assert_that(!is.null(parameters.file),msg=paste("parameters.file should not be NULL in",fncname))
  selected.parameters = read.csv(parameters.file, stringsAsFactors = F, header=T, fileEncoding = 'UTF-8-BOM')
  constant            = grepl("^con.*", selected.parameters$dist) | !selected.parameters$choose
  varparams           = selected.parameters[!constant,]
  varparams
}

sample.fitted.parameters = function(parameters.file=NULL){
  fncname = match.call()[[1]]
  assert_that(!is.null(parameters.file),msg=paste("parameters.file should not be NULL in",fncname))
  selected.parameters = read.csv(parameters.file, stringsAsFactors = F, header=T, fileEncoding = 'UTF-8-BOM')
  constant            = grepl("^con.*", selected.parameters$dist) | !selected.parameters$choose
  varparams           = selected.parameters[!constant,]
  varparams$mean      = as.numeric(varparams$mean)
  varparams$min       = as.numeric(varparams$min)
  varparams$max       = as.numeric(varparams$max)
  newvalues           = runif(nrow(varparams),varparams$min,varparams$max)
  names(newvalues)    = varparams$unique.name
  newvalues
}




if (F){
  run = function(new.parameter.values=NULL){
    if (!is.null(new.parameter.values)){
      updated.parameters = update.model.parameters(read.parameters,new.parameter.values)
    }else{
      updated.parameters = read.parameters
    }
    model$initialized.parameters = initialize.model.parameters(updated.parameters)
    run.model(model$initialized.parameters)
  }
  initialize   = function(mydir         = here(), 
                          countries     = "countries", 
                          countrycode   = NA, 
                          xml           = NA, 
                          parameters    = NA, 
                          targets       = NA, 
                          baseline      = NA, 
                          VXa.incidence.files=NA){
    assert_that(!is.null(paths),msg="model$paths should not be NULL")
    paths        = update.paths(paths,mydir,countries,countrycode,targets,xml,baseline,parameters,VXa.incidence.files)
    modlog       <<- setup.model.log(paths)
    read.model.parameters()
  }
  
  run = function(model.params=NULL,new.parameter.values=NA, temp.xml=NA){
    assert_that(!is.null(model.params),msg="pass read model parameters as an argument")
    assert_that(exists("modlog"),msg="setup the model log before calling run()")
    updated.params = update.model.parameters(paths,model.params,new.parameter.values)
    if (!is.na(temp.xml)){ 
      write_xml(updated.params$xml$doc, file = here(paths$params.dir, temp.xml), option="as_xml")
    }
    initialized.params = initialize.model.parameters(updated.params)
    output             = run.model(initialized.params) 
    if (!is.na(paths$targets)){
      output$hits        = get.target.hits(output,initialized.params)
    }
    output
  }
  
  write.model.output = function(output=NULL, model.params=NULL){
    
    fncname = match.call()[[1]]
    assert_that(!is.null(paths),msg=paste("paths should not be NULL in",fncname))
    assert_that(!is.null(output),msg=paste("output should not be NULL in",fncname))
    assert_that(!is.null(model.params),msg=paste("model.params should not be NULL in",fncname))
    
    options = model.params$run.params$output
    
    if (!options$combine_stocks_and_flows){
      filename = paste0(create.filename(paths$output.dir, model.params,runtype="stocks"),".txt")
      write.output(output$stocks,filename)
      filename = paste0(create.filename(paths$output.dir, model.params,runtype="flows"),".txt")
      write.output(output$flows,filename)
    }else{
      filename = paste0(create.filename(paths$output.dir, model.params,runtype="onerun"),".txt")
      stocks.extra = cbind(output$stocks[,1:7],dim=NA,subject=NA,flow=NA,output$stocks[,8:10])
      all  = rbind(stocks.extra,output$flows)
      write.output(all,filename)
    }
    if (!is.null(output$population)){
      filename = paste0(create.filename(paths$output.dir, model.params,runtype="POP"),".txt")
      write.output(output$population,filename)
      filename = paste0(create.filename(paths$output.dir, model.params,runtype="dBGx"),".txt")
      write.output(output$dBGx,filename)
      filename = paste0(create.filename(paths$output.dir, model.params,runtype="dTBHIVx"),".txt")
      write.output(output$dHIVTBx,filename)
      filename = paste0(create.filename(paths$output.dir, model.params,runtype="dALLx"),".txt")
      write.output(output$dALLx,filename)
      if (!model.params$intervention){
        filename = paste0(create.filename(paths$output.dir, model.params,runtype="dfrBGx"),".txt")
        write.output(output$dfrBGx,filename)
        filename = paste0(create.filename(paths$output.dir, model.params,runtype="dfrPOPadj"),".txt")
        write.output(output$dfrPOPadj,filename)
      }
    }
    if (!is.na(paths$targets)){
      write.targets(output)
    }
  }
}


