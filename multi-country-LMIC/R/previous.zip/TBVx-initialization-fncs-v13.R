optimize.params=function(Ti){ # for example the transition matrix ...
  M.list = Ti$parameter.matrices
  n = length(M.list)
  if (n==1)
    return(Ti)
  M = M.list[[1]]
  n.elements = nrow(M)*ncol(M)
  uniq = 0*(1:n)+T
  uniq[1]=F
  for (i in 2:length(M.list)){
    if (sum(M.list[[i]]==M)==n.elements)
      uniq[i]=F
    else
      return(Ti)
  }
  if (sum(uniq)==0){
    Ti$parameter.matrices = list(M)
    Ti$age.groups = Ti$age.groups[1]
    Ti$age.from.index = Ti$age.from.index[1]
    Ti$age.thru.index = Ti$age.thru.index[n]
    return(Ti)
  }
}

# code below could be much improved - but time is scarce ...


fractions.by.stage.at.start=function(p,exclude = list(VXa=T,SES=F,RISK=F,HIV=T,TB=F), df=NULL){

  assert_that(!is.null(df),msg="data frame with initial TB distribution required (specify in run xml) ")
  
  n = p$nVXaSESRISKHIVTB
  c = length(p$DIMNAMES)-1
  M = matrix(0,n,c)
  colnames(M)=p$DIMNAMES[1:c]
  
  ind = calc.indices.for.dim(p,"VXa")
  if (!exclude$VXa){
    for (i in 1:p$nVXa)
      M[,"VXa"][ind==i]=p$iVXa[i]
  }else{
    M[,"VXa"][ind==1]=1.0
  }
  ind = calc.indices.for.dim(p,"SES")
  if (!exclude$SES){
    for (i in 1:p$nSES)
      M[,"SES"][ind==i]=p$iSES[i]
  }else{
    M[,"SES"][ind==1]=1.0
  }

  ind = calc.indices.for.dim(p,"RISK")
  if (!exclude$RISK){
    for (i in 1:p$nRISK)
      M[,"RISK"][ind==i]=p$iRISK[i]
  }else{
    M[,"RISK"][ind==1]=1.0
  }

  ind = calc.indices.for.dim(p,"HIV")
  if (!exclude$HIV){
    for (i in 1:p$nHIV)
      M[,"HIV"][ind==i]=p$iHIV[i]
  }else{
    M[,"HIV"][ind==1]=1.0
  }
  
  x = apply(M,1,prod) # we now have a vector of fractions of all dims except TB

  P = matrix(0,nrow=p$nVXaSESRISKHIVTB,ncol=p$nAGES)
  rownames(P)=p$VXaSESRISKHIVTB
  colnames(P)=names(p$AGES)
  if (!exclude$TB){
    for (i in 1:nrow(df)){
      rows = calc.indices.for.dim(p,"TB")==which(p$TB == df$stage[i])
      range = p$AGES >= df$age.from[i] & p$AGES <= df$age.thru[i]
      P[rows,range] = df$fraction[i]
    }
  }
  y = x * P
  assert_that(sum(colSums(y)-1.0)<1e-9,msg="something rotten in setting up the at.start matrix .....")
  y 
}


fractions.by.stage.at.birth=function(p){
  n = p$nVXaSESRISKHIVTB
  c = length(p$DIMNAMES)
  M = matrix(0,n,c)
  colnames(M)=p$DIMNAMES
  
  ind = calc.indices.for.dim(p,"VXa")
  for (i in 1:p$nVXa)
    M[,"VXa"][ind==i]=p$iVXa[i]
  
  ind = calc.indices.for.dim(p,"SES")
  for (i in 1:p$nSES)
    M[,"SES"][ind==i]=p$iSES[i]
  
  ind = calc.indices.for.dim(p,"RISK")
  for (i in 1:p$nRISK)
    M[,"RISK"][ind==i]=p$iRISK[i]
  
  ind = calc.indices.for.dim(p,"HIV")
  for (i in 1:p$nHIV)
    M[,"HIV"][ind==i]=p$iHIV[i]
  
  ind = calc.indices.for.dim(p,"TB")
  for (i in 1:p$nTB)
    M[,"TB"][ind==i]=p$iTB[i]

  x = apply(M,1,prod) # we now have a vector of fractions of all dims except TB
  
#  x = M[,1]
#  for (i in 2:c)
#    x = x * M[,i]
  x
}



replace.NAs.by=function(nodes,attrib,replace=0,first=NA,n=NA){
  v = as.numeric(xml_attr(nodes,attrib))
  if (sum(is.na(v))==n){
    v = rep(0.,n)
    if (!is.na(first))
      v[1]=first
  }else{
    v[is.na(v)]=0.
  }
  v
}

check.sum.to.1 = function(v){
  if (abs(sum(v)-1.0)>1e-6)
    stop(paste("values of ",names(v)," should add up to 1.0",sep=""))
  v
}

create.approx.fun.for.dataframe=function(df){
  x = as.integer(rownames(df))
  y = 1:nrow(df)
  if (nrow(df)==1){
    return(function(t){y})
  }else{
    return(approxfun(x,y,rule=2))
  }
}

get.deathrate=function(p, t){
  return(p$deathrate[p$deathfn(t),])
}

create.approx.fun=function(row, df=NULL){
  values = unlist(strsplit(row["values"],","))
  NAs = sum(is.na(suppressWarnings(as.numeric(values))))
  if (!is.null(df) & (NAs>0)){
    selcols  = which(names(df) %in% c("name","value"))
    df.left  = as.data.frame(df[,-selcols])
    sel = rowSums(is.na(df.left)) == ncol(df.left)
    df  = df[sel,selcols]
    eval(parse(text = paste0(df$name,"=",df$value)))
    x = as.numeric(unlist(strsplit(row["times" ],",")))
    y = 0 * x
    for (i in 1:length(y)){
      eval(parse(text = paste0("y[i]=",values[i])))
    }
    y = as.numeric(y)
    return(approxfun(x,y,rule=2))
  }else{
  x = as.numeric(unlist(strsplit(row["times" ],",")))
  y = as.numeric(values)
  return(approxfun(x,y,rule=2))
  }
}

calc.birthrate = function(fname=NA, countrycode=NA){
  if (!is.na(countrycode)){
    pop = read.csv(fname,header=F, fileEncoding = 'UTF-8-BOM')
    pop = pop[pop[,1]==countrycode,]
    nr  = nrow(pop)
    nc  = ncol(pop)
    x   = pop[2:nr,2]
    y   = pop[2:nr,3]/rowSums(pop[1:(nr-1),3:102])
    return(approxfun(x,y,rule=2))
  }
  return(NULL)
}

scale.population = function(pop=NA,fname=NA){
    if (!is.na(fname)){
      sumpop        = sum(pop)
      pop           = 0*pop
      pop.fracs     = as.matrix(read.delim(file=fname,sep="\t",header=T,stringsAsFactors = F, row.names=1, fileEncoding = 'UTF-8-BOM'))
      assert_that(dim(pop)[2]==dim(pop.fracs)[2])
      sum.pop.fracs = sum(pop.fracs)
      if (sum.pop.fracs<0.99 | sum.pop.fracs>1.01)
        warning(paste("The file ",fname, " does not appear to contain fractions adding up to 1.0 ?",sep=""))
      rowsel = rownames(pop) %in% rownames(pop.fracs)
      pop[rowsel,] = pop.fracs
      return(pop * sumpop)
    }
  NULL
}

seed.initial.population=function(parms, df){
  z = t(parms$y.ini[1,] * t(parms$at.start))
  assert_that(sum(abs(colSums(z)-parms$y.ini[1,]))<1e-3,msg="something rotten in seed.initial.population() ....")
  parms$y.ini = z
}

init.constants = function(p,xml){
  p$xml = xml
  with(p,{
    DAYSPERYEAR = 365.2425
    TB   = xml_attr(xml_find_all(xml$doc,"//TB/TB.stages/stage"),"name")     ; nTB   = length(TB) 
    HIV  = xml_attr(xml_find_all(xml$doc,"//HIV/HIV.stages/stage"),"name")   ; nHIV  = length(HIV) 
    RISK = xml_attr(xml_find_all(xml$doc,"//RISK/RISK.stages/stage"),"name") ; nRISK = length(RISK) 
    SES  = xml_attr(xml_find_all(xml$doc,"//SES/SES.stages/stage"),"name")   ; nSES  = length(SES) 
    VXa  = xml_attr(xml_find_all(xml$doc,"//VXa/VXa.stages/stage"),"name")   ; nVXa  = length(VXa)

    iTB   = check.sum.to.1(replace.NAs.by(xml_find_all(xml$doc,"//TB/TB.stages/stage"),"fraction.at.birth",0,1,nTB))  
    iHIV  = check.sum.to.1(replace.NAs.by(xml_find_all(xml$doc,"//HIV/HIV.stages/stage"),"fraction.at.birth",0,1,nHIV))     
    iRISK = check.sum.to.1(replace.NAs.by(xml_find_all(xml$doc,"//RISK/RISK.stages/stage"),"fraction.at.birth",0,1,nRISK))     
    iSES  = check.sum.to.1(replace.NAs.by(xml_find_all(xml$doc,"//SES/SES.stages/stage"),"fraction.at.birth",0,1,nSES))     
    iVXa  = check.sum.to.1(replace.NAs.by(xml_find_all(xml$doc,"//VXa/VXa.stages/stage"),"fraction.at.birth",0,1,nVXa))     

    # NOTE : the order below VXa - SES - RISK - HIV - TB should NEVER be changed !!!
    
    DIMNAMES     = c("VXa","SES","RISK","HIV","TB")
    DIMNAMESLIST = list(VXa=VXa,SES=SES,RISK=RISK,HIV=HIV,TB=TB)
    DIMLENGTHS   = c(nVXa,nSES,nRISK,nHIV,nTB)
    names(DIMLENGTHS)=DIMNAMES
    
    HIVTB = NULL ; RISKHIVTB = NULL ; SESRISKHIVTB = NULL ; VXaSESRISKHIVTB = NULL;
    nHIV  = length(HIV)
    for (i in 1:nHIV) 
      HIVTB = c(HIVTB,paste(HIV[i],TB,sep="-")) 
    nHIVTB  = length(HIVTB)
    for (i in 1:nRISK) 
      RISKHIVTB = c(RISKHIVTB,paste(RISK[i],HIVTB,sep="-")) 
    nRISKHIVTB  = length(RISKHIVTB)
    for (i in 1:nSES)  
      SESRISKHIVTB = c(SESRISKHIVTB,paste(SES[i],RISKHIVTB,sep="-"))
    nSESRISKHIVTB  = length(SESRISKHIVTB)
    for (i in 1:nVXa)  
      VXaSESRISKHIVTB = c(VXaSESRISKHIVTB,paste(VXa[i],SESRISKHIVTB,sep="-"))
    nVXaSESRISKHIVTB  = length(VXaSESRISKHIVTB)

    inci.dim.names = list(VXa=dim.names.for.all(environment(),"VXa"),
                         NULL,
                         NULL,
                         HIV=dim.names.for.all(environment(),"HIV"),
                         NULL)

    # AGES  = c(0:79,80,90); names(AGES) = paste("A",AGES,sep="") ; nAGES = length(AGES) 

    ALIVE     = !grepl(".*dead.*",VXaSESRISKHIVTB,ignore.case=F)
    
    DEATH.matrix = create.death.matrix(environment())
  })
}

init.parameters=function(xmlfile=NA, xmlrunfile=NA, params=NULL, opts=NULL, paths=NULL){
  assert <<- T
  if (is.null(params)){
    run.params = parse.run.spec(xmlrunfile)
    if (!is.null(opts)){
      run.params$countrycode = opts$countrycode
    }
    p = new.env()
    init.constants(p,xml=read.xml(xmlfile,"/TB.Vx.model.inputfile"))
  }else{
    p = params
  }
  with(p,{
    
    eval(parse(text=paste("AGES=c(",xml_attr(xml_find_all(xml$doc,"//ages"),"lower.limits"),")",sep="")))
    # AGES  = c(0:79,80,90)
    names(AGES) = paste("A",AGES,sep="") ; nAGES = length(AGES) 
    xmlfile = xmlfile
    xmlrunfile = xmlrunfile
    run.params = run.params
    h = run.params$dt 
    years = run.params$start+cumsum(c(0,rep(h,(run.params$stop-run.params$start)/h)))
    
    final.population.as.fraction = run.params$final.population.as.fraction
    
    detailed.output = run.params$detailed.output
    assert_that(all(detailed.output$years %in% years),msg=" not all years specified for detailed output within simulation years")
    incidence.output = run.params$incidence.output
    if (!is.null(incidence.output)){
      inci.output.years    = incidence.output$years
      inci.output.recorded = rep(F,length(inci.output.years)) 
    }
    aging.matrix = create.aging.matrix(environment())
    
    at.birth = fractions.by.stage.at.birth(environment())
    at.start = fractions.by.stage.at.start(environment(),df=run.params$seeded.infections)
    
    deathrate = NULL
    birthrate = NULL  
    birthrate.is.number = run.params$birthrate.is.number
    if (!is.na(run.params$population.csv)){
      y.ini = read.population(p           = environment(),
                              rownms      = p$VXaSESRISKHIVTB, 
                              colnms      = p$AGES, 
                              fname       = here(paths$country.dir,run.params$population.csv), 
                              countrycode = run.params$countrycode, 
                              year        = run.params$start)
      
      if (run.params$birthrate.from.data){
        birthrate = calc.birthrate(fname=here(paths$country.dir,run.params$population.csv), countrycode = run.params$countrycode)
      }
      if (run.params$deathrate.from.data){
        deathrate = deathrate.from.data(environment(),fname=here(paths$country.dir,run.params$population.csv), countrycode=run.params$countrycode)
      }
    }else if (!is.na(run.params$population.fractions)){
      y.ini = create.empty.population(rownms = p$VXaSESRISKHIVTB, colnms = p$AGES) 
      y.ini[1,1] = run.params$population.total # seems weird but should work
      y.ini = scale.population(pop = y.ini, fname = run.params$population.fractions) 
      
    }

    if (is.null(deathrate))
      deathrate     = read.mortality(environment(),fname=run.params$deathrate.txt)
    deathfn       = create.approx.fun.for.dataframe(deathrate)
    if (is.null(birthrate))
        birthrate = run.params$birthrate    

    if (!is.na(run.params$contact.matrix.txt)){
      if (!is.null(opts)){
        run.params$contact.matrix.txt=here(paths$country.dir,run.params$contact.matrix.txt)
        contactmatrixfname = stri_replace_last(str=run.params$contact.matrix.txt,replacement=paste0("/",run.params$countrycode,"_"),fixed="/")
      }else{
        contactmatrixfname = run.params$contact.matrix.txt
      }
      contacts.M = Matrix(expand.contact.matrix(environment(),read.contact.matrix(contactmatrixfname)))
      contacts.MplustM = contacts.M+t(contacts.M)
      update.contact.matrix(environment(),colSums(y.ini[ALIVE,]))
    }else{
      contacts = matrix(0,nAGES,nAGES)
      rownames(contacts) = colnames(contacts) = names(AGES)
    }

    inci = list()
    
    for (i in seq_along(run.params$incidence.files)){
        inci[[i]] = init.incidence(environment(), fname=here(paths$country.dir,run.params$incidence.files[[i]]), countrycode  = run.params$countrycode)
    }
    
    TBp    = init.parameters.from.xml(environment(), xmlpath=     "//TB/TB.progression", 
                                     xmlparameter="TB.parameter", 
                                     xmltransitions=xml_find_all(xml$doc,"//TB/TB.progression/transition.matrix/transition"))
    
    TBp = optimize.params(TBp) # for example the transition matrix ...
    
    nodeset = xml_find_all(xml$doc,"//TB/TB.progression/treatment.matrix")
    if (length(nodeset)>0){
      TBtr    = list()
      for (i in 1:length(nodeset)){
        TBtr[[i]] = init.parameters.from.xml(environment(), xmlpath=        "//TB/TB.progression",
                                       xmlparameter=   "TB.parameter",
                                       xmltransitions= xml_find_all(nodeset[i],"transition"),
                                       xmltimedparams= xml_find_all(nodeset[i],"multiplier"))
        names(TBtr)[i]=xml_attr(nodeset[i],"name")
      }
    }else
      TBtr = NULL
    
    rm(nodeset)
    # NOTE: TB death is included in the transition rates (mu_C and mu_S for subclinical and clinical)
    Tm    = init.parameters.from.xml(environment(), xmlpath=        "//TB/TB.transmission",
                                     xmlparameter=   "TB.parameter",
                                     xmltransitions= xml_find_all(xml$doc,"//TB/TB.transmission/transition.matrix/transition"),
                                     xmltimedparams= xml_find_all(xml$doc,"//TB/TB.transmission/contact.rate.multiplier"))
    Tm = optimize.params(Tm) 
    
    Infc  = init.parameters.from.xml(environment(), xmlpath=    "//TB/TB.infectivity",
                                     xmlparameter   = "TB.parameter",
                                     xmltransitions = xml_find_all(xml$doc,"//TB/TB.infectivity/infectivity.matrix/infectivity"),
                                     values=T)  
    Infc = optimize.params(Infc) 
    
    PROGRESSION = list()
    
    HIVp = RISKp = SESp = VXAp = HIVtr = NULL
    
    if (nHIV>1){
      xmlpath = "//HIV/HIV.progression"
      if (length(xml_find_all(xml$doc,xmlpath))>0){
        HIVp  = init.parameters.from.xml(environment(), xmlpath=xmlpath,
                                         xmlparameter="HIV.parameter",
                                         xmltransitions= xml_find_all(xml$doc,"//HIV/HIV.progression/transition.matrix/transition"))
        HIVp  = optimize.params(HIVp) 
        
        for (i in seq_along(inci)){
          if (inci[[i]]$dim=="HIV"){
            nodeset = xml_find_all(xml$doc,"//HIV/HIV.progression/HIV.incidence.trend")
            if (length(nodeset)>0){
              inci[[i]]$inci.trend.fn = list()
              inci[[i]]$inci.trend.fn = parse.timed.parameters(environment(), nodeset, HIVp$fixed.parameters)
            }
          }
        }
        PROGRESSION$HIV=HIVp
      }
      nodeset = xml_find_all(xml$doc,"//HIV/HIV.progression/treatment.matrix")
      if (length(nodeset)>0){
        HIVtr    = list()
        for (i in 1:length(nodeset)){
          HIVtr[[i]] = init.parameters.from.xml(environment(), xmlpath=        "//HIV/HIV.progression",
                                             xmlparameter=   "HIV.parameter",
                                             xmltransitions= xml_find_all(nodeset[i],"transition"),
                                             xmltimedparams= xml_find_all(nodeset[i],"multiplier"))
          names(HIVtr)[i]=xml_attr(nodeset[i],"name")
        }
      }else
        HIVtr = NULL
        PROGRESSION$HIVtr=HIVtr
    }
    if (nRISK>1){
      xmlpath = "//RISK/RISK.progression"
      if (length(xml_find_all(xml$doc,xmlpath))>0){
        RISKp = init.parameters.from.xml(environment(),xmlpath,xmlparameter="RISK.parameter",
                                         xmltransitions= xml_find_all(xml$doc,"//RISK/RISK.progression/transition.matrix/transition"))
        PROGRESSION$RISK=RISKp
      }
    } 
    if (nSES>1){
      xmlpath = "//SES/SES.progression"
      if (length(xml_find_all(xml$doc,xmlpath))>0){
        SESp  = init.parameters.from.xml(environment(), xmlpath,xmlparameter= "SES.parameter",
                                         xmltransitions= xml_find_all(xml$doc,"//SES/SES.progression/transition.matrix/transition"))
        
        PROGRESSION$SES=SESp
      }
    }
    if (nVXa>1){
      xmlpath = "//VXa/VXa.progression"
      if (length(xml_find_all(xml$doc,xmlpath))>0){
        VXap  = init.parameters.from.xml(environment(), xmlpath,xmlparameter= "VXa.parameter",
                                         xmltransitions= xml_find_all(xml$doc,"//VXa/VXa.progression/transition.matrix/transition"))
        PROGRESSION$VXa=VXap
      }
    }
    seed.initial.population(environment())
    p$hash =  digest(p)
    local({
      df     = run.params$incidence.output$output.dims
      idx    = which(df$dim=="HIV")
      nohiv  = nHIV==1 & all(df[idx,]==F)
      hivp   = if(as.logical(df$progression[idx])){ nHIV>1  & length(p$HIVp$parameter.matrices)>=1 }else{T}
      hivtr  = if(as.logical(df$treatment[idx])){nHIV>1  & length(p$HIVtr)>=1}else{T}
      hivok  = nohiv | (hivp & hivtr & !as.logical(df$transmission[idx])) 
      idx    = which(df$dim=="VXa")
      novax  = nVXa==1 & all(df[idx,]==F)
      vaxp   = if(as.logical(df$progression[idx])){ nVXa>1  & length(p$VXAp$parameter.matrices)>=1 }else{T}
      vaxok  = novax | (vaxp & !as.logical(df$transmission[idx])) 
      assert_that(hivok,msg="inconsistencies in HIV incidence output defined in run XML file")
      assert_that(vaxok,msg="inconsistencies in VXa incidence output defined in run XML file")
    })
  })
  logger(level = 'DEBUG',msg="successful result of init.parameters()")
  p
}

