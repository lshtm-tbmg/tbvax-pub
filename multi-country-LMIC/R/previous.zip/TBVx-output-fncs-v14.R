output.to.array=function(Y,parms){
  years = Y[[1]]
  n     = length(years)
  idxs  = 1:n
  dimZ  = c(n,parms$nVXa, parms$nSES, parms$nRISK, parms$nHIV,parms$nTB,parms$nAGES)
  ndim  = length(dimZ)
  Z     = array(0,dim=dimZ)
  tb    = 1:parms$nTB
  if(ndim==7){
    for (i in idxs){
      for (vxa in 1:parms$nVXa)
        for (ses in 1:parms$nSES)
          for (risk in 1:parms$nRISK)
            for (hiv in 1:parms$nHIV){
              Z[i,vxa,ses,risk,hiv,,]=Y[[2]][[i]][calc.index.by.nr(parms,vxa,ses,risk,hiv,tb),]  
            }
    }
    dimnames(Z)=list(YEAR=years,VXa=names(parms$VXa), SES=names(parms$SES), RISK=names(parms$RISK), HIV=names(parms$HIV), TB=names(parms$TB), AGE=parms$AGES)
  }else{
    stop("unsupported number of dimensions in output")
  }
  Z
}

generate.filename = function(fparams,s,path="."){
  s1 = unlist(strsplit(fparams$xmlfile,"/",fixed=T))
  s2 = unlist(strsplit(s1[length(s1)],".xml",fixed=T))
  s3 = unlist(strsplit(fparams$xmlrunfile,"/",fixed=T))
  s4 = unlist(strsplit(s3[length(s3)],".xml",fixed=T))
  s5 = as.character(as.integer(seconds(now())) %% 100000)
  md5run = digest(fparams$run.params,algo="sha1")
  md5mdl = digest(fparams,algo="sha1")
  sig  = paste(substring(md5mdl,nchar(md5mdl)-4),"_",substring(md5run,nchar(md5run)-4),sep="")
  paste(path,"/output/",s2,"_",s4,"_",sig,"_",s5,s,".txt",sep="")
}

generate.prev.output.df=function(t,state,fparams,cols){
  nrows = nrow(state[[1]])
  detailed = fparams$detailed.output
  sel = which(t %in% detailed$years)
  assert_that(length(sel)>0,msg="no overlap between years specified for incidence output and detailed output")
  basic_df = data.frame(year=rep(0,nrows))
  basic_df = cbind(basic_df,cols)
  df = data.frame()
  for (i in sel){
    year = rep(t[i],nrows)
    M    = NULL
    if (sum(is.na(detailed$age.from))==0){
      M = aggregate.by.age.groups(state[[i]],detailed$age.from, sumcols=F, avg = F)
    }else{
      M = state[[i]]
    }  
    colnames(M)=paste("A",colnames(M),sep="")
    row.names(M)=NULL
    local_df = cbind(basic_df,M)
    local_df$year = year
    df = rbind(df,local_df)
  }
  y = as.data.frame(melt(setDT(df), measure.vars = patterns("^A\\d+$"),variable.name = "age_from", value.name = "value"))
  z = cbind(y[,1:(ncol(y)-1)],age_thru=as.integer(rep(0,nrow(y))),value=y[,ncol(y)])
  z$age_from = as.integer(substring(z$age_from,2))
  agesfrom   = unique(z$age_from)
  agesthru   = c(agesfrom[2:length(agesfrom)],100)-1
  for (i in seq_along(agesfrom)){
    sel = z$age_from==agesfrom[i]
    z[sel,'age_thru']=agesthru[i]
  }
  z[z$value>1e-4,]
}




generate.output.df=function(t,state,dim,subjectname,matname,fparams,cols){
  if (is.na(subjectname)){
    nrows = nrow(state[[1]])
    matname = NA
  }else{
    nrows = nrow(state[[1]][[subjectname]][[matname]])
  }
  # cat(subjectname,nrows,"\n")
  dim   = rep(dim,nrows)
  subject = rep(subjectname,nrows)
  flow = rep(matname,nrows)
  cols = cbind(cols,dim,subject,flow)
  detailed = fparams$detailed.output
  sel = which(t %in% detailed$years)
  assert_that(length(sel)>0,msg="no overlap between years specified for incidence output and detailed output")
  basic_df = data.frame(year=rep(0,nrows))
  basic_df = cbind(basic_df,cols)
  df = data.frame()
  for (i in sel){
    year = rep(t[i],nrows)
    M    = NULL
    if (sum(is.na(detailed$age.from))==0){
      if (is.na(subjectname)){
        M = aggregate.by.age.groups(state[[i]],detailed$age.from, sumcols=F, avg = F)
      }else{
        M = aggregate.by.age.groups(state[[i]][[subjectname]][[matname]],detailed$age.from, sumcols=F, avg = F)
      }
    }else{
      if (is.na(subjectname)){
        M = state[[i]]
      }else{
        M = state[[i]][[subjectname]][[matname]]
      }
    }  
    colnames(M)=paste("A",colnames(M),sep="")
    row.names(M)=NULL
    local_df = cbind(basic_df,M)
    local_df$year = year
    df = rbind(df,local_df)
  }
  y = as.data.frame(melt(setDT(df), measure.vars = patterns("^A\\d+$"),variable.name = "age_from", value.name = "value"))
  z = cbind(y[,1:(ncol(y)-1)],age_thru=as.integer(rep(0,nrow(y))),value=y[,ncol(y)])
  z$age_from = as.integer(substring(z$age_from,2))
  agesfrom   = unique(z$age_from)
  agesthru   = c(agesfrom[2:length(agesfrom)],100)-1
  for (i in seq_along(agesfrom)){
    sel = z$age_from==agesfrom[i]
    z[sel,'age_thru']=agesthru[i]
  }
  z
}

generate.detailed.output=function(t,state,fparams,dim=NA){
  VXa  = calc.names.for.dim(fparams,"VXa")
  SES  = calc.names.for.dim(fparams,"SES")
  RISK = calc.names.for.dim(fparams,"RISK")
  HIV  = calc.names.for.dim(fparams,"HIV")
  TB   = calc.names.for.dim(fparams,"TB")
  cols = cbind(VXa,SES,RISK,HIV,TB)
  subjects = names(state[[1]])
  if (is.null(subjects)){ # prev only
    return(generate.output.df(t,state,dim,NA,NA,fparams,cols))  
  }else{
    matnames = c("dY.in","dY.out")     
    df   = NULL
    for (subject in subjects){
      for (matname in matnames){
        if (!is.null(state[[1]][[subject]])){
          df = rbind(df,generate.output.df(t,state,dim,subject,matname,fparams,cols))  
        }
      }
    }
    return(df)
  }
}

generate.flow.output=function(inci,params){
  if (!is.null(params$detailed.output)){
    out = list(prev=NULL,TB=NULL,HIV=NULL,VXa=NULL)
    for (dim in names(inci)[-1]){
      if (!is.null(inci[[dim]])){
        out[[dim]]=generate.detailed.output(t=inci$t,state=inci[[dim]],params,dim=dim)
      }    
    }
    result = out$TB
    if (!is.null(out$HIV)){
      result = rbind(result,out$HIV)
    }
    if (!is.null(out$VXa)){
      result = rbind(result,out$VXa)
    }
    result$flow = as.character(result$flow)
    result$flow[result$flow == "dY.in"] = "in"
    result$flow[result$flow == "dY.out"] = "out"
    out$prev$flow = as.character(out$prev$flow)
    result = rbind(out$prev,result)
    result$flow = as.factor(result$flow)
    return(result)
  }
  NULL
}

write.output=function(data,filename){
  write.table(data,file=filename,row.names=F,sep="\t",quote=F)
  print(filename)
}


add.dY.inci=function(A,f,t,Y,p,q,include=F){
  if (include){
    res      = f(t,Y,p,q)
    A$dY     = A$dY     + res$dY
    A$dY.in  = A$dY.in  + res$dY.in
    A$dY.out = A$dY.out + res$dY.out
  }
  A
}

add.dY=function(A,f,t,Y,p,include=F){
  if (include){
    res      = f(t,Y,p)
    A$dY     = A$dY + res$dY
    A$dY.in  = A$dY.in  + res$dY.in
    A$dY.out = A$dY.out + res$dY.out
  }
  A
}
add.matmul.dY=function(A,f,M,Y,include=F){
  if (include){
    res      = f(M,Y)
    A$dY     = A$dY     + res$dY
    A$dY.in  = A$dY.in  + res$dY.in
    A$dY.out = A$dY.out + res$dY.out
  }
  A
}

incidence.from.model.run=function(out,params){
  sel         = which(out$t %in% params$inci.output.years)
  result      = list(t=out$t[sel])
  for (i in seq_along(result$t)){
    out.index           = sel[i]
    result$PREV[[i]]    = out$state[[out.index]]
    update.contact.matrix(params, colSums(result$PREV[[i]][params$ALIVE,]))
    df.sel = params$output.options[params$output.options$dim=="TB",]
    result$TB[[i]] = incidence.from.Y.matrix(t=out$t[out.index],out$state[[out.index]],params,sel.output=df.sel)
    if (params$DIMLENGTHS["HIV"]>1){
      df.sel = params$output.options[params$output.options$dim=="HIV",]
      result$HIV[[i]] = incidence.from.Y.matrix(t=out$t[out.index],out$state[[out.index]],params,sel.output=df.sel)
    }    
    if (params$DIMLENGTHS["VXa"]>1){
      df.sel = params$output.options[params$output.options$dim=="VXa",]
      result$VXa[[i]] = incidence.from.Y.matrix(t=out$t[out.index],out$state[[out.index]],params,sel.output=df.sel)
    }
    
  }
  logger(level="DEBUG",msg="successful call of incidence.from.model.run() [ NOTE: no output on VXa incidence yet ]")
  result
}

incidence.from.Y.matrix=function(t,Y,p,sel.output=NA){

  if (sum(is.na(sel.output))>0)
    return(NULL)

  if (sel.output$dim=="TB"){
     out = list()
     if (sel.output$transmission){
       out$Tm = list(dY = 0.*Y, dY.in = 0.*Y, dY.out = 0.*Y)
       out$Tm = add.dY(out$Tm,derivs.Tm.in.out,t,Y,p,sel.output$transmission) 
     }
     if (sel.output$progression){
       out$TBp = list(dY = 0.*Y, dY.in = 0.*Y, dY.out = 0.*Y)
       out$TBp = add.matmul.dY(out$TBp,matmul.by.age.group.in.out,p$TBp,Y,sel.output$progression)
     }
     if (sel.output$treatment){
       for (i in seq_along(p$TBtr)){
         name = paste0("TBtr_",names(p$TBtr)[i]) 
         out[[name]] = list(dY = 0.*Y, dY.in = 0.*Y, dY.out = 0.*Y)
         out[[name]] = add.dY(out[[name]],derivs.Tr.in.out,t,Y,p$TBtr[[i]],sel.output$treatment)
       }
     }
     if (sel.output$from.data){
       out$Xi  = list(dY = 0.*Y, dY.in = 0.*Y, dY.out = 0.*Y)
       for (i in seq_along(p$inci$TB)){
         q   = p$inci$TB[[i]]
         if (q$dim==sel.output$dim){
           out$Xi = add.dY.inci(out$Xi,derivs.inci.in.out,t,Y,p,q,sel.output$from.data)
         }
       }
     }
     return(out)
  }else{
    Tiname = paste0(sel.output$dim,"p")
    Xiname = paste0(sel.output$dim,"Xi")
    out = list()
    if (sel.output$progression){
      out[[Tiname]] = list(dY = 0.*Y, dY.in = 0.*Y, dY.out = 0.*Y)
      out[[Tiname]] = add.matmul.dY(out[[Tiname]],matmul.by.age.group.in.out,p$PROGRESSION[[sel.output$dim]],Y,sel.output$progression)
      if (sel.output$dim=="HIV"){
        for (i in seq_along(p$HIVtr)){
          name = paste0("HIVtr_",names(p$HIVtr)[i]) 
          out[[name]] = list(dY = 0.*Y, dY.in = 0.*Y, dY.out = 0.*Y)
          out[[name]] = add.dY(out[[name]],derivs.Tr.in.out,t,Y,p$HIVtr[[i]],sel.output$progression)
        }
      }
    }
    if (sel.output$from.data){
      out[[Xiname]]  = list(dY = 0.*Y, dY.in = 0.*Y, dY.out = 0.*Y)
      for (i in seq_along(p$inci[[sel.output$dim]])){
        q   = p$inci[[sel.output$dim]][[i]]
        if (q$dim==sel.output$dim){
          out[[Xiname]] = add.dY.inci(out[[Xiname]],derivs.inci.in.out,t,Y,p,q,sel.output$from.data)
        }
      }
    }
    return(out)
  }    
}


