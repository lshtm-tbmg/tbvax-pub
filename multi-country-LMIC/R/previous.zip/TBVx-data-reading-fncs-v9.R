generate.list.of.forcing.functions=function(z){
  apply(z,2,approxfun,x=z[,1],rule=2)
}

read.forcing.functions=function(params){
  generate.list.of.forcing.functions(read.delim(file=paste(params$params.path,params$time.dep.file,sep=""),sep="\t",header=T, fileEncoding = 'UTF-8-BOM'))
}
if (F){
read.xml.file = function(xmlfile){
  assert_that(is.readable(xmlfile))
  # read the XML document
  doc = read_xml(xmlfile)
  # find the reference to the XML Schema in the XML doc
  xmlschemafile = xml_attr(xml_find_first(doc,"/TB.Vx.model.inputfile"),"noNamespaceSchemaLocation")
  # make sure the XML schema is a readable file
  assert_that(is.readable(xmlschemafile))
  # read the XML Schema file (i.e. the .xsd)
  schema = read_xml(xmlschemafile)
  # and validate the XML doc
  assert_that(xml_validate(doc,schema))
  doc  
}
# what about this:
# xml_set_attr(x=xml_find_all(x = params_up, xpath = 'TB.parameter[@name = "phiF"]'), attr = "value", value = parameter_sets$phiF[i])
}
read.xml = function(xmlfile, schemapath){
  assert_that(is.readable(xmlfile),msg=paste0("reading the XML input file ", xmlfile," failed"))
  doc = read_xml(xmlfile)
  xmlschemafile = xml_attr(xml_find_first(doc,schemapath),"noNamespaceSchemaLocation")
  assert_that(is.readable(xmlschemafile),msg=paste0("reading the XML Schema file ", xmlschemafile," failed"))
  schema = read_xml(xmlschemafile)
  valid = xml_validate(doc,schema)
  if (!valid){
    for (i in seq_along(attr(valid,"errors")))
      logger(level='FATAL', msg= paste0("error when validating ",xmlfile," : ",attr(valid,"errors")[i]))
    stop(paste0("errors in ",xmlfile," ; see logfile for details"))
  }
  result = list(doc,schema)
  names(result)=c("doc","schema")
  result
}

read.contact.matrix=function(fname){
  assert_that(is.readable(fname),msg="contacts matrix cannot be read")
  contacts=as.matrix(as.data.frame(read.table(fname,header=T)))
  assert_that(nrow(contacts)==ncol(contacts) & ncol(contacts)==16,msg="expecting a contacts matrix of 16 rows and 16 columns")
  assert_that(sum(colnames(contacts)==paste0("A",5*(0:15)))==16,msg=paste0("expecting column names to be ",paste0("A",5*(0:15))))
  rownames(contacts)=colnames(contacts)
  contacts
}
deathrate.from.data = function(p,fname=NA, countrycode=NA){
  if (!is.na(countrycode) & !is.na(fname)){
    pop                 = read.csv(fname,header=F, fileEncoding = 'UTF-8-BOM')
    sel                 = pop[,1]==countrycode 
    x                   = pop[sel,3:102]
    names(x)            = c(0:99)
    nr                  = nrow(x)
    nk                  = ncol(x)
    survival            = x[2:nr,2:nk] / x[1:(nr-1),1:(nk-1)]
    deathrate           = cbind(0*(1:(nr-1)),-log(survival))
    colnames(deathrate) = names(x)
    deathrate           = aggregate.by.age.groups(deathrate,p$AGES,sumcols=F,avg=T)
    names(deathrate)    = names(p$AGES)
    row.names(deathrate)= pop[sel,][1:(nr-1),2]    
    return(deathrate)
  }
  return(NULL)
}

read.mortality = function(parms,fname=NA){
  x           = as.matrix(read.delim(fname,header=T,row.names=1, stringsAsFactors = F, fileEncoding = 'UTF-8-BOM'))
  colnames(x) = as.integer(substr(colnames(x),2,4))
  y           = adjust.age.groups(parms,x,F)
  y
}
create.empty.population = function(rownms, colnms){
  pop = matrix(0.,nrow=length(rownms),ncol=length(colnms)) 
  colnames(pop)=colnms ; rownames(pop)=rownms
  pop
}

read.population = function(p, rownms, colnms, fname=NA, countrycode=NA, year=NA){
  if (!is.na(countrycode)){
    pop           = read.csv(fname,header=F, fileEncoding = 'UTF-8-BOM')
    sel           = pop[,1]==countrycode
    assert_that(nrow(pop[sel,])>=1,msg=paste0("no rows for country code ",countrycode," in ",fname))
    years         = pop[sel,2]
    assert_that(all(years == cummax(years)),msg=paste0("the 2nd column in ",fname," is supposed to contain monotonously increasing years ..."))
    if(ncol(pop) > 102){
      warning("ignoring columns from col nr 103 i.e. using columns 3 thru 102 for ages 0 thru 99")
    } 
    assert_that(ncol(pop)>=102,msg=paste("expecting at least 102 columns in ",fname," (ignoring columns from 103)"))
    z             = pop[sel,3:min(ncol(pop),102)]
    names(z)      = 0:99
    rownames(z)   = years
    z             = z[order(rownames(z)),]
    yrsel         = approxfun(rownames(z),1:nrow(z),rule = 2)    
    y             = aggregate.by.age.groups(z[yrsel(year),],p$AGES, sumcols = F, avg = F)
    x             = create.empty.population(rownms, colnms)
    x[1,]         = y  
    return(x)
  }
  return(NULL)
}

read.incidence = function(parms, fname=NA, countrycode=NA){
  all.inci = read.delim(fname, header = T, stringsAsFactors = F, fileEncoding = 'UTF-8-BOM')
  dim = unique(all.inci$dim)
  assert_that(length(dim)==1, msg = "values in 'dim' column should be unique within file")
  from = unique(all.inci$from)
  assert_that(length(from)==1, msg="values in 'from' column should be unique within file")
  to = unique(all.inci$to)
  assert_that(length(to)==1, msg="values in 'to' column should be unique within file")
  sel = (all.inci$from==from & all.inci$to==to & all.inci$country==countrycode)
  names(all.inci)=stri_replace_all_fixed(names(all.inci),"X","")
  sel.inci = all.inci[sel,]
  rownames(sel.inci)=sel.inci$YEAR
  excl = names(sel.inci)=="dim" | names(sel.inci)=="from" | names(sel.inci)=="to" | names(sel.inci)=="country" | names(sel.inci)=="YEAR"
  inci = as.matrix(sel.inci[,!excl])
  dimindex = which(parms$DIMNAMES==dim)
  fromindex = which(parms$DIMNAMESLIST[[dimindex]]==from)
  list(dim=dim,from=from,to=to,inci=adjust.age.groups(parms,inci,compress.1st=(dim=="HIV" & fromindex==1))) # compress incidence in newborns
}

init.incidence=function(p,fname=NA,countrycode=NA){
  e = new.env()
  with(e,{
    z           = read.incidence(p,fname,countrycode)
    dim         = z$dim
    assert_that(z$dim %in% names(p$inci.dim.names),msg=paste0("incidence data not supported for ",z$dim))
    from        = z$from
    to          = z$to
    inci        = z$inci
    susc        = dim.names.for.all(p,dim)==from & p$ALIVE
    inci.fn     = create.approx.fun.for.dataframe(inci)
    inci.matrix = create.incidence.matrix(p,dim,from,to) 
  })
  e
}