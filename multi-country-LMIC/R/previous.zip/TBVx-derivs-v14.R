# NOTE: large parts of this code should be rewritten to take advantage of FP principles and reduce duplication of code

aging.and.births.and.update.contact.matrix.event <- function(t,X,p){
  if (t>p$years[1]){
    #if (p$print.aging){ 
    #  print(paste("aging, birth and update contact matrix at t=",t))
    #}
    Y = matrix(X,p$nVXaSESRISKHIVTB,p$nAGES) ; rownames(Y)=p$VXaSESRISKHIVTB ; colnames(Y)=names(p$AGES)
    if (t==as.numeric(rownames(p$deathrate)[1])){
      # cat("pop size = ",formatC(sum(Y[p$ALIVE,]),digits=2,format="f"),"\n")
      Y = scale.alive.population(Y,p)
      # cat("pop size = ",formatC(sum(Y[p$ALIVE,]),digits=2,format="f"),"\n")
      # cat(formatC(t,digits=3,format="f")," ; rescaled pop \n")
    }
    alive.by.age.group = colSums(Y[p$ALIVE,])
    update.contact.matrix(p, alive.by.age.group)
    dY       = t(tcrossprod(p$aging.matrix, Y))
    dY[!p$ALIVE,] = 0. # the dead do not age
    if (p$birthrate.is.number){
      dY[,1] = dY[,1] + p$birthrate(t)
    }else{
      dY[,1] = dY[,1] + p$birthrate(t)*sum(alive.by.age.group)*p$at.birth # it would be possible to have dead newborns (HIV)
    }
    Y = Y + dY
    # allow deaths to cumulate over time
    # alternative: Y[!p$ALIVE,]=0. 
    if (sum(is.nan(Y))>0){
      logger(level='FATAL',msg=paste0(" at t = ",t," NaNs in state variables ; reduce euler / rk2 / rk4 time step"))
    }else if (sum(Y<0.)>0){
      neg = p$run.params$min.value.for.state.var
      Y[Y<0. & Y>=neg] = 0.
      if (sum(Y<neg)>0){
        idx = which(Y<neg)
        r   = idx %% nrow(Y)
        c   = (idx %/% nrow(Y))+1 
        for (i in seq_along(idx)){
          logger(level='WARN',paste0(" at t = ",t," state variables < ",neg," :",
          " state = ",rownames(Y)[r[i]]," ; age group = ",colnames(Y)[c[i]],"; value = ",signif(Y[r[i],c[i]])," ; please reconsider parameter values"))
        }
      }
    }
    return(as.vector(Y))
  }else{
    return(X)
  }
}

derivs.Tr=function(t,Y,Tr){
  dY = 0.*Y
  for (i in seq_along(Tr)){
    treat   = Tr[[i]]
    tparams = treat$timed.parameters
    if (is.null(tparams)){
      dY = dY + matmul.by.age.group(treat,Y)
    }else{
      mult=1.0
      nms = names(tparams)
      for (nm in nms)
        mult = mult * get(nm,envir=tparams)(t)
      dY = dY + matmul.by.age.group(treat,Y,mult)
    }
  }
  dY
}
derivs.Tr.in.out=function(t,Y,Tr){
  tparams = Tr$timed.parameters
  if (is.null(tparams)){
    return(matmul.by.age.group.in.out(Tr,Y))
  }
  else{
    mult=1.0
    nms = names(tparams)
    for (nm in nms)
      mult = mult * get(nm,envir=tparams)(t)
    return(matmul.by.age.group.in.out(Tr,Y,mult))
  }
}


derivs.Tm.in.out=function(t,Y,parms){
  infc = matmul.by.age.group(parms$Infc, Y) # always > 0
  mult = 1.0
  tparams = parms$Tm$timed.parameters
  if (!is.null(tparams)){
    nms = names(tparams)
    for (nm in nms)
      mult = mult * get(nm,envir=tparams)(t)
  }
  foi  = mult * parms$DAYSPERYEAR * rowSums(parms$contacts.M %*% (colSums(infc)/colSums(Y[parms$ALIVE,]))) # foi is a column vector of foi by age ; ipv tcrossprod(M,infc)
  susc.list = matmul.by.age.group.in.out(parms$Tm, Y) # the Tm matrices have both positive and negative elements
  dY.in  = t(t(susc.list$dY.in ) * foi )
  dY.out = t(t(susc.list$dY.out) * foi )
  list(dY=(dY.in+dY.out),dY.in=dY.in,dY.out=dY.out)
}

derivs.Tm=function(t,Y,parms){
  infc = matmul.by.age.group(parms$Infc, Y)
  mult = 1.0
  tparams = parms$Tm$timed.parameters
  if (!is.null(tparams)){
    nms = names(tparams)
    for (nm in nms)
      mult = mult * get(nm,envir=tparams)(t)
  }
  mat  = (colSums(infc)/colSums(Y[parms$ALIVE,]))
  mat[is.nan(mat)]=0.
  foi  = mult * parms$DAYSPERYEAR * rowSums(parms$contacts.M %*% mat) # foi is a column vector of foi by age ; ipv tcrossprod(M,infc)
  susc = matmul.by.age.group(parms$Tm, Y)
  t(t(susc) * foi )
}
derivs.inci=function(t=NA,Y=NA,p=NA,p.inci=NA){ 
  x_inci = as.numeric(p.inci$inci[p.inci$inci.fn(t),])
  if (sum(x_inci)>0){
    if (!is.null(p.inci$inci.trend.fn)){
      tparams = p.inci$inci.trend.fn
      nms = names(tparams)
      mult = 1.0
      for (nm in nms){
        mult = mult * get(nm,envir=tparams)(t)
      }
      x_inci = x_inci * mult
    }
    X = t(Y)
    dX = 0*X
    dX[,p.inci$susc]   = x_inci * X[,p.inci$susc] # OK - that is simple
    return(as.matrix(p.inci$inci.matrix %*% t(dX)))     
  }else{
    return(0.*Y)
  }
}
derivs.inci.in.out=function(t=NA,Y=NA,p=NA,p.inci=NA){ 
  x_inci = as.numeric(p.inci$inci[p.inci$inci.fn(t),])
  if (sum(x_inci)>0){
    if (!is.null(p.inci$inci.trend.fn)){
      tparams = p.inci$inci.trend.fn
      nms = names(tparams)
      mult = 1.0
      for (nm in nms){
        mult = mult * get(nm,envir=tparams)(t)
      }
      x_inci = x_inci * mult
    }
    X = t(Y)
    dX = 0*X
    dX[,p.inci$susc]   = x_inci * X[,p.inci$susc] # OK - that is simple
    P = Q = p.inci$inci.matrix
    P[p.inci$inci.matrix<0]=0.
    Q[p.inci$inci.matrix>0]=0.
    dY.in  = P %*% t(dX)
    dY.out = Q %*% t(dX) 
    return(list(dY=as.matrix(dY.in+dY.out),dY.in=as.matrix(dY.in),dY.out = as.matrix(dY.out)))     
  }else{
    return(list(dY=0.*Y,dY.in=0.*Y,dY.out = 0.*Y))     
  }
}

# in principe kunnen ART matrixen worden gecombineerd (van HIV1 -> ART1 en van HIV2 -> ART2)
# de techniek voor HIV en ART incidentie kunnen ook worden gebruikt voor vaccinatie
# data: file met kolommen YEAR from to en leeftijden in de overige kolommen
# YEAR from to    0 5 10 etc
# 2025 never vac  0.2 0.4 0.8 etc
# In feite is de techniek identiek voor incidentie van sterft, HIV, vaccinatie .....

derivs.nat.death=function(t,Y,parms,dY.TB.and.HIV.deaths){ 
  # correction = dY.TB.and.HIV.deaths / colsums(Y[parms$ALIVE,])
  # correction[is.infinite(correction)|is.nan(correction)]=0.
  mu = as.numeric(get.deathrate(parms,t)) # - correction
  # if (sum(mu<0)>0){
  #  print(paste("number of TB and HIV deaths is larger than background deaths at t=",t))
  #}
  # mu[mu<0 | is.infinite(mu) | is.nan(mu)]=0.
  mu[mu<0 | is.infinite(mu) | is.nan(mu)]=0.
  X = t(Y)
  dX = 0*X
  dX[,parms$ALIVE]   = mu * X[,parms$ALIVE] # OK - that is simple
  dY = parms$DEATH.matrix %*% t(dX) 
  as.matrix(dY)     
}

scale.alive.population=function(Y,parms){
  Y[!parms$ALIVE,] = 0.
  sum(parms$y.ini)/sum(Y)*Y
}

colsums = function(M){
  if (is.null(dim(M)))
    return(sum(M))
  else
    return(colSums(M))
}

# called for every t listed and using prev matrix Y as input
derivs.deSolve=function(t,X,p){
  ntimesteps <<- ntimesteps+1
  #if (p$print.t){
  # if (abs(t %% 1)<1e-6)
  #    cat('\n')
  # cat(formatC(t,digits=3,format="f")," ")
  #}
  Y = matrix(X,p$nVXaSESRISKHIVTB,p$nAGES)
  rownames(Y)=p$VXaSESRISKHIVTB
  colnames(Y)=names(p$AGES)
  dY.Ti = matmul.by.age.group(p$TBp,Y)
  dY =  derivs.Tm(t,Y,p) + dY.Ti
  for (i in seq_along(p$inci))
    dY = dY + derivs.inci(t,Y,p,p$inci[[i]])

  if (!is.null(p$TBtr))
    dY = dY + derivs.Tr(t,Y,p$TBtr)

  if (p$nHIV>1){
    dY.HIVp = matmul.by.age.group(p$HIVp, Y)
    if (!is.null(p$HIVtr)){
      dY.HIVp = dY.HIVp + derivs.Tr(t,Y,p$HIVtr)
    }
    dY.nat.death = derivs.nat.death(t,Y,p,colsums((dY.Ti+dY.HIVp)[!p$ALIVE,]))
    dY = dY + dY.HIVp + dY.nat.death
  }else{
    dY = dY + derivs.nat.death(t,Y,p,colsums(dY.Ti[!p$ALIVE,]))
  }
  if (p$nRISK>1 & !is.null(p$RISKp))
    dY = dY + matmul.by.age.group(p$RISKp, Y)
  if (p$nSES>1  & !is.null(p$SESp))
    dY = dY + matmul.by.age.group(p$SESp, Y)
  if (p$nVXa>1  & !is.null(p$VXAp))
    dY = dY + matmul.by.age.group(p$VXAp, Y)
  assert_that(sum(is.nan(dY))==0,msg="NaNs in derivs.deSolve")
  assert <<- F
  list(dY=as.vector(dY))
}

run.deSolve = function(params = NULL){
  assert <<- T
  ntimesteps <<- 0
  started.at = proc.time()
  rawout = rk(   y = as.vector(params$y.ini), 
             times    = params$years, 
             func     = derivs.deSolve, 
             parms    = params, 
             rtol     = params$run.params$rtol, 
             atol     = params$run.params$atol, 
             method   = params$run.params$method,
             maxsteps = params$run.params$maxsteps,
             hini     = params$run.params$hini,
             hmin     = params$run.params$hmin,
             events   = list(func = aging.and.births.and.update.contact.matrix.event, 
                          time = unique(trunc(params$years))[-1]))
  if (ntimesteps>(max(params$years)-min(params$years))*50){
    logger(level='WARN',msg=paste0(" ntimesteps = ",ntimesteps," in ",timetaken(started.at)," which may be excessive ; please reconsider parameter values"))
  }else{
    logger(level='INFO',msg=paste0(" ntimesteps = ",ntimesteps," in ",timetaken(started.at)))
  }

  t         = rawout[,1]
  out       = vector("list",length(t)) 
  nr        = params$nVXaSESRISKHIVTB
  nc        = params$nAGES
  N         = nr*nc
  for (i in seq_along(t)){
      M = matrix(rawout[i,2:(N+1)],nr,nc)
      colnames(M)=params$AGES
      rownames(M)=params$VXaSESRISKHIVTB
      out[[i]] = M
  }
  list(times=t,state=out)
}

basic.run.model = function(p=NULL, atol=1e-3, rtol=1e-3, method="ode23", print.t=F, print.aging=F){
  p$print.t     = print.t
  p$print.aging = print.aging
  out           = run.deSolve(p, atol, rtol, method)
  if (!is.na(p$final.population.as.fraction)){
    nyrz  = length(out$times)
    y.fin   = out$state$Y[[nyrz]]
    y.alive = y.fin[p$ALIVE,]
    y.alive = y.alive[rowSums(y.alive)>1e-6,]
    y.alive.frac = y.alive/sum(y.alive)
    write.table(as.data.frame(y.alive.frac),file=p$final.population.as.fraction,sep="\t", row.names = T, quote=F)
  }
  out
}
run.model = function(p=NULL, write.to.file=F, path=NULL){
  out           = run.deSolve(p)
  logger(level="DEBUG",msg="successful result of run.deSolve()")
  if (!is.na(p$final.population.as.fraction)){
    nyrz  = length(out$times)
    y.fin   = out$state$Y[[nyrz]]
    y.alive = y.fin[p$ALIVE,]
    y.alive = y.alive[rowSums(y.alive)>1e-6,]
    y.alive.frac = y.alive/sum(y.alive)
    write.table(as.data.frame(y.alive.frac),file=p$final.population.as.fraction,sep="\t", row.names = T, quote=F)
  }
  #return(incidence.from.model.run(out,p))
  # prev.out = generate.detailed.output.prev(t=out$times,state=out$state,p,subject="prev")
  z = generate.output(incidence.from.model.run(out,p),params=p)
  logger(level="DEBUG",msg="successful generation of full output from generate.output()")
  
  setDT(z)
  # add 0 thru 99 age group
  output = rbind(z,z[,.(age_from=min(age_from),age_thru=max(age_thru),value=sum(value)),by=c(names(z)[1:9])])
  output = cbind(country=p$run.params$countrycode,output)
  if (write.to.file){
    filename = paste0(create.filename(path=path,params=p,runtype="onerun"),".txt")
    write.output(output,filename)
    return(list(z=output,out=out))
  }else{
    return(list(z=output,out=out))
  }
}


