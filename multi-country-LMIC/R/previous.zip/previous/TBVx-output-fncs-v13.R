output.to.array=function(Y,parms){
  years = Y[[1]]
  n     = length(years)
  idxs  = 1:n
  dimZ  = c(n,parms$nVXa, parms$nSES, parms$nRISK, parms$nHIV,parms$nTB,parms$nAGES)
  ndim  = length(dimZ)
  Z     = array(0,dim=dimZ)
  tb    = 1:parms$nTB
  if(ndim==7){
    for (i in idxs){
      for (vxa in 1:parms$nVXa)
        for (ses in 1:parms$nSES)
          for (risk in 1:parms$nRISK)
            for (hiv in 1:parms$nHIV){
              Z[i,vxa,ses,risk,hiv,,]=Y[[2]][[i]][calc.index.by.nr(parms,vxa,ses,risk,hiv,tb),]  
            }
    }
    dimnames(Z)=list(YEAR=years,VXa=names(parms$VXa), SES=names(parms$SES), RISK=names(parms$RISK), HIV=names(parms$HIV), TB=names(parms$TB), AGE=parms$AGES)
  }else{
    stop("unsupported number of dimensions in output")
  }
  Z
}

generate.filename = function(fparams,s){
  s1 = unlist(strsplit(fparams$xmlfile,"/",fixed=T))
  s2 = unlist(strsplit(s1[length(s1)],".xml",fixed=T))
  s3 = unlist(strsplit(fparams$xmlrunfile,"/",fixed=T))
  s4 = unlist(strsplit(s3[length(s3)],".xml",fixed=T))
  s5 = as.character(as.integer(seconds(now())) %% 100000)
  md5run = digest(fparams$run.params,algo="sha1")
  md5mdl = digest(fparams,algo="sha1")
  sig  = paste(substring(md5mdl,nchar(md5mdl)-4),"_",substring(md5run,nchar(md5run)-4),sep="")
  paste("./output/",s2,"_",s4,"_",sig,"_",s5,s,".txt",sep="")
}

generate.output.df=function(t,state,dim,subjectname,matname,fparams,round.to=2,cols){
  if (is.na(subjectname)){
    nrows = nrow(state[[1]])
    matname = NA
  }else{
    nrows = nrow(state[[1]][[subjectname]][[matname]])
  }
  dim   = rep(dim,nrows)
  subject = rep(subjectname,nrows)
  flow = rep(matname,nrows)
  cols = cbind(cols,dim,subject,flow)
  detailed = fparams$detailed.output
  sel = which(t %in% detailed$years)
  assert_that(length(sel)>0,msg="no overlap between years specified for incidence output and detailed output")
  basic_df = data.frame(year=rep(0,nrows))
  basic_df = cbind(basic_df,cols)
  df = data.frame()
  for (i in sel){
    year = rep(t[i],nrows)
    M    = NULL
    if (sum(is.na(detailed$age.from))==0){
      if (is.na(subjectname)){
        M = round(aggregate.by.age.groups(state[[i]],detailed$age.from, sumcols=F, avg = F),round.to)
      }else{
        M = round(aggregate.by.age.groups(state[[i]][[subjectname]][[matname]],detailed$age.from, sumcols=F, avg = F),round.to)
      }
    }else{
      if (is.na(subjectname)){
        M = round(state[[i]],round.to)
      }else{
        M = round(state[[i]][[subjectname]][[matname]],round.to)
      }
    }  
    colnames(M)=paste("A",colnames(M),sep="")
    row.names(M)=NULL
    local_df = cbind(basic_df,M)
    local_df$year = year
    df = rbind(df,local_df)
  }
  y = as.data.frame(melt(setDT(df), measure.vars = patterns("^A\\d+$"),variable.name = "age_from", value.name = "value"))
  z = cbind(y[,1:(ncol(y)-1)],age_thru=as.integer(rep(0,nrow(y))),value=y[,ncol(y)])
  z$age_from = as.integer(substring(z$age_from,2))
  agesfrom   = unique(z$age_from)
  agesthru   = c(agesfrom[2:length(agesfrom)],100)-1
  for (i in seq_along(agesfrom)){
    sel = z$age_from==agesfrom[i]
    z[sel,'age_thru']=agesthru[i]
  }
  z
}

generate.detailed.output=function(t,state,fparams,round.to=2,dim=NA){
  VXa  = calc.names.for.dim(fparams,"VXa")
  SES  = calc.names.for.dim(fparams,"SES")
  RISK = calc.names.for.dim(fparams,"RISK")
  HIV  = calc.names.for.dim(fparams,"HIV")
  TB   = calc.names.for.dim(fparams,"TB")
  cols = cbind(VXa,SES,RISK,HIV,TB)
  subjects = names(state[[1]])
  if (is.null(subjects)){ # prev only
    return(generate.output.df(t,state,dim,NA,NA,fparams,round.to=2,cols))  
  }else{
    matnames = c("dY.in","dY.out")     
    df   = NULL
    for (subject in subjects){
      for (matname in matnames){
        if (!is.null(state[[1]][[subject]])){
          df = rbind(df,generate.output.df(t,state,dim,subject,matname,fparams,round.to=2,cols))  
        }
      }
    }
    return(df)
  }
}

generate.output=function(inci,params,round.to=2){
  if (!is.null(params$detailed.output)){
    out = list(prev=NULL,TB=NULL,HIV=NULL)
    for (dim in names(inci)[-1]){
      if (dim=="PREV"){
        out$prev = generate.detailed.output(t=inci$t,state=inci[[dim]],params,dim=NA)
      }else if (!is.null(inci[[dim]])){
        out[[dim]]=generate.detailed.output(t=inci$t,state=inci[[dim]],params,dim=dim)
      }    
    }
    if (!is.null(out$HIV)){
      result = rbind(out$TB,out$HIV)
    }else{
      result = out$TB
    }
    result$flow = as.character(result$flow)
    result$flow[result$flow == "dY.in"] = "in"
    result$flow[result$flow == "dY.out"] = "out"
    out$prev$flow = as.character(out$prev$flow)
    result = rbind(out$prev,result)
    result$flow = as.factor(result$flow)
    return(result)
  }
  NULL
}

write.output=function(data,filename){
  write.table(data,file=filename,row.names=F,sep="\t",quote=F)
  print(filename)
}


add.dY.inci=function(A,f,t,Y,p,q,include=F){
  if (include){
    res      = f(t,Y,p,q)
    A$dY     = A$dY     + res$dY
    A$dY.in  = A$dY.in  + res$dY.in
    A$dY.out = A$dY.out + res$dY.out
  }
  A
}

add.dY=function(A,f,t,Y,p,include=F){
  if (include){
    res      = f(t,Y,p)
    A$dY     = A$dY + res$dY
    A$dY.in  = A$dY.in  + res$dY.in
    A$dY.out = A$dY.out + res$dY.out
  }
  A
}
add.matmul.dY=function(A,f,M,Y,include=F){
  if (include){
    res      = f(M,Y)
    A$dY     = A$dY     + res$dY
    A$dY.in  = A$dY.in  + res$dY.in
    A$dY.out = A$dY.out + res$dY.out
  }
  A
}

incidence.from.model.run=function(out,params){
  sel         = which(out$t %in% params$inci.output.years)
  result      = list(t=out$t[sel])
  for (i in seq_along(result$t)){
    out.index           = sel[i]
    result$PREV[[i]]    = out$state[[out.index]]
    update.contact.matrix(params, colSums(result$PREV[[i]][params$ALIVE,]))
    df.sel = params$incidence.output$output.dims[params$incidence.output$output.dims$dim=="TB",]
    result$TB[[i]] = incidence.from.Y.matrix(t=out$t[out.index],out$state[[out.index]],params,sel.output=df.sel)
    if (params$DIMLENGTHS["HIV"]>1){
      df.sel = params$incidence.output$output.dims[params$incidence.output$output.dims$dim=="HIV",]
      result$HIV[[i]] = incidence.from.Y.matrix(t=out$t[out.index],out$state[[out.index]],params,sel.output=df.sel)
    }
  }
  result
}

incidence.from.Y.matrix=function(t,Y,p,sel.output=NA){

  if (sum(is.na(sel.output))>0)
    return(NULL)

  if (sel.output$dim=="TB"){
     out = list()
     if (sel.output$transmission){
       out$Tm = list(dY = 0.*Y, dY.in = 0.*Y, dY.out = 0.*Y)
       out$Tm = add.dY(out$Tm,derivs.Tm.in.out,t,Y,p,sel.output$transmission) 
     }
     if (sel.output$progression){
       out$Ti = list(dY = 0.*Y, dY.in = 0.*Y, dY.out = 0.*Y)
       out$Ti = add.matmul.dY(out$Ti,matmul.by.age.group.in.out,p$Ti,Y,sel.output$progression)
     }
     if (sel.output$treatment){
       for (i in seq_along(p$Tr)){
         name = paste0("Tr_",names(p$Tr)[i]) 
         out[[name]] = list(dY = 0.*Y, dY.in = 0.*Y, dY.out = 0.*Y)
         out[[name]] = add.dY(out[[name]],derivs.Tr.in.out,t,Y,p$Tr[[i]],sel.output$treatment)
       }
     }
     if (sel.output$from.data){
       out$Xi  = list(dY = 0.*Y, dY.in = 0.*Y, dY.out = 0.*Y)
       for (i in seq_along(p$inci)){
         q   = p$inci[[i]]
         if (q$dim==sel.output$dim){
           out$Xi = add.dY.inci(out$Xi,derivs.inci.in.out,t,Y,p,q,sel.output$from.data)
         }
       }
     }
     return(out)
  }else{
    out = list(Ti=NULL,Xi=NULL)
    if (sel.output$progression){
      out$Ti = list(dY = 0.*Y, dY.in = 0.*Y, dY.out = 0.*Y)
      out$Ti = add.matmul.dY(out$Ti,matmul.by.age.group.in.out,p$PROGRESSION[[sel.output$dim]],Y,sel.output$progression)
      if (sel.output$dim=="HIV"){
        for (i in seq_along(p$HIVtr)){
          name = paste0("Tr_",names(p$HIVtr)[i]) 
          out[[name]] = list(dY = 0.*Y, dY.in = 0.*Y, dY.out = 0.*Y)
          out[[name]] = add.dY(out[[name]],derivs.Tr.in.out,t,Y,p$HIVtr[[i]],sel.output$progression)
        }
      }
      
    }
    if (sel.output$from.data){
      out$Xi  = list(dY = 0.*Y, dY.in = 0.*Y, dY.out = 0.*Y)
      for (i in seq_along(p$inci)){
        q   = p$inci[[i]]
        if (q$dim==sel.output$dim){
          out$Xi = add.dY.inci(out$Xi,derivs.inci.in.out,t,Y,p,q,sel.output$from.data)
        }
      }
    }
    return(out)
  }    
}


