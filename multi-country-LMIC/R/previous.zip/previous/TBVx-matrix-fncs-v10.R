roll.matrix.by.rows = function(M,by,negate=T){
  n = nrow(M)
  P = 0 * M
  if (by>=0){ # roll down
    P[(by+1):n ,] = -M[      1 :(n-by),] 
    P[    1 :by,] = -M[(n-by+1):n     ,]
  }else{ # roll up
    by = -by
    P[      1 :(n-by),] = -M[(by+1):n ,]  
    P[(n-by+1):n     ,] = -M[    1 :by,] 
  }
  if (negate){
    return(M+P)
  }else{
    return(M-P)
  }
}

create.incidence.matrix=function(p,dim,from,to){ # this function should work also for VXa (or any other dim)
  index      = which(p$DIMNAMES==dim)
  from.idx   =  p$ALIVE & grepl(from,p$inci.dim.names[[index]],ignore.case=F) 
  to.idx     =  p$ALIVE & grepl(to,  p$inci.dim.names[[index]],ignore.case=F)
  x = y = numeric(p$nVXaSESRISKHIVTB)
  x[from.idx]=-1
  M = diag( x)
  d = which(to.idx)[1]-which(from.idx)[1]
  M = roll.matrix.by.rows(M,by=d)
  assert_that(sum(colSums(M)!=0)==0,msg=paste("Error in creating incidence matrix for ",dim," from=",from," to=",to,sep=""))
  Matrix(M)
}

create.death.matrix=function(p){ 
  x = numeric(p$nVXaSESRISKHIVTB)
  x[p$ALIVE]=-1
  Matrix(diag(x))  
}

do.not.delete.create.death.mult.matrix=function(p){ 
  # note that the important difference with the create.incidence.matrix method is that 
  # deaths are collected from multiple stages into 1 stage
  ALIVETB.idx.offset   = which(!grepl("dead$",p$TB,ignore.case=F)) - p$nTB
  x = numeric(p$nVXaSESRISKHIVTB)
  x[p$ALIVE]=-1
  M = diag(x)
  indices = which(p$NATdead)
  for (i in indices){
    M[i,i+ALIVETB.idx.offset]=1    
  }
  assert_that(sum(colSums(M)!=0)==0,msg="Error in creating death multiplier matrix")
  Matrix(M)  
}


dim.names.for.all=function(p,dimname){
  dimindex = which(p$DIMNAMES==dimname)
  names    = rep(NA,p$nVXaSESRISKHIVTB)
  indices  = calc.indices.for.dim(p,dimname)
  for (i in 1:p$DIMLENGTHS[dimindex])
    names[indices==i]=p$DIMNAMESLIST[[dimindex]][i]
  names
}



calc.indices.for.dim=function(p,dimname){
  ndim = length(p$DIMLENGTHS)
  v = (1:p$nVXaSESRISKHIVTB)-1
  switch(dimname,
         "VXa" =  return(1+((v %/% prod(p$DIMLENGTHS[2:ndim])) %% p$nVXa )),
         "SES" =  return(1+((v %/% prod(p$DIMLENGTHS[3:ndim])) %% p$nSES )),
         "RISK"=  return(1+((v %/% prod(p$DIMLENGTHS[4:ndim])) %% p$nRISK)),
         "HIV" =  return(1+((v %/% prod(p$DIMLENGTHS[5:ndim])) %% p$nHIV )),
         "TB"  =  return(1+( v %% p$nTB ))
  )
  NULL
}

calc.names.for.dim=function(p,dimname){
  names    = p$DIMNAMESLIST[[which(p$DIMNAMES==dimname)]]
  v        = calc.indices.for.dim(p,dimname)
  names[v]
}  

calc.indices.from.list=function(p,list){
  # expected order: vax,ses,risk,hiv,tb
  vax = list[[1]]
  ses = list[[2]]
  risk = list[[3]]
  hiv  = list[[4]]
  tb   = list[[5]]
  (vax-1) *p$nSES*p$nRISK*p$nHIV*p$nTB + 
    (ses-1) *p$nRISK*p$nHIV*p$nTB +
    (risk-1)*p$nHIV*p$nTB + 
    (hiv-1) *p$nTB +
    tb
}

calc.index.by.nr=function(p,vax,ses,risk,hiv,tb){
    (vax-1) *p$nSES*p$nRISK*p$nHIV*p$nTB + 
    (ses-1) *p$nRISK*p$nHIV*p$nTB +
    (risk-1)*p$nHIV*p$nTB + 
    (hiv-1) *p$nTB + tb
}

calc.index.by.name=function(p,vax,ses,risk,hiv,tb){
  v = which(p$DIMNAMESLIST$VXa==vax)
  s = which(p$DIMNAMESLIST$SES==ses)
  r = which(p$DIMNAMESLIST$RISK==risk)
  h = which(p$DIMNAMESLIST$HIV==hiv)
  t = which(p$DIMNAMESLIST$TB==tb)
  calc.index.by.nr(p,v,s,r,h,t)
}


transition = function(M=NULL, from=NA, to=NA, rate=NULL){
  from=as.character(from)
  to  =as.character(to)
  M[from,from]=M[from,from]-rate
  M[  to,from]=M[  to,from]+rate
  M
}





