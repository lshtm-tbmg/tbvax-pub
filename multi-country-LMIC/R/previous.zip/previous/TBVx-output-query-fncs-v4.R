age.group.from.lower.age.limits = function(age.from,lower.age.limits){
  if (is.null(lower.age.limits)){
    age.group = rep("ALL",length(age.from))
  }else{
    lower=lower.age.limits
    upper=c(lower.age.limits[-1],200)
    age.group = rep(NA,length(age.from))
    for (i in seq_along(lower)){
      age.group[age.from %in% lower[i]:upper[i]]=paste0("A",lower[i])
    }
  }
  age.group
}

denom.query.from.target=function(target=NA, p=NULL){
  target = target[1:11]
  n = length(target)
  target[] = stri_replace(target,"",regex="[:space:]")
  subjects = unlist(strsplit(target$subject,","))
  allowed_subjects = c('Tm','Xi','Ti','prev',paste('Tr',names(p$Tr),sep="_"))
  assert_that(sum(subjects %in% allowed_subjects)==length(subjects), msg="undefined subject for inci or prev")
  mult = rep(F,n)
  mult[c(2:6)]=T # i.e. multiple states
  target[target$dim]=NA
  sel = mult & (target=="any" | target=="NA" | is.na(target))
  target[sel]=NA
  target[7:9]=paste0("is.na(",names(target)[7:9],")")
  NAs = is.na(target)
  target[NAs]=""
  target[!NAs & mult] = stri_replace(target[!NAs & mult],"','",regex=",")
  target[!NAs & mult] = stri_replace(target[!NAs & mult]," %in% c('",regex="^")
  target[!NAs & mult] = stri_replace(target[!NAs & mult],"') ",regex="$")
  target[!NAs & mult] = paste(names(target)[!NAs & mult],target[!NAs & mult])
  num = rep(F,n) ; num[c(1,10:11)]=T
  target[num] = paste0(names(target)[num],"==",target[num])
  stri_join(target[target!=""],collapse=" & ")
}

df = read.csv("./parameters-and-targets/example_new_target_definition.csv",fileEncoding = "UTF-8-BOM")
df = df[,-1]
target= df[1,1:6]
names(target)[2:6]=substring(names(target)[2:6],2)

target[6]="Dc,Ds"
target[3]="high"


stock.query.from.target=function(target=NA){ # NOTE the dead !!!!!
  n = length(target) # 6
  target[] = stri_replace(target,"",regex="[:space:]")
  assert_that(!is.na(target[1]),msg="NA not allowed in year column")
  mult = rep(F,n)
  mult[c(2:6)]=T # i.e. multiple states
  sel = mult & (target=="all" | target=="NA" | is.na(target))
  target[sel]=NA
  NAs = is.na(target)
  target[NAs]="" 
  target[!NAs & mult] = stri_replace(target[!NAs & mult],"','",regex=",")
  target[!NAs & mult] = stri_replace(target[!NAs & mult]," %in% c('",regex="^")
  target[!NAs & mult] = stri_replace(target[!NAs & mult],"') ",regex="$")
  target[!NAs & mult] = paste(names(target)[!NAs & mult],target[!NAs & mult])
  target[1] = paste0(names(target)[1],"==",target[1])
  stri_join(target[target!=""],collapse=" & ")
}

flow.query.from.target=function(target=NA, p=NULL){
  target = target[1:11]
  n = length(target)
  target[] = stri_replace(target,"",regex="[:space:]")
  subjects = unlist(strsplit(target$subject,","))
  allowed_subjects = c('Tm','Xi','Ti',paste('Tr',names(p$Tr),sep="_"))
  assert_that(sum(subjects %in% allowed_subjects)==length(subjects), msg="undefined subject for incidence")
  assert_that(sum(is.na(target[-c(2:6)]))==0,msg="NA not allowed in columns except 2 thru 6")
  mult = rep(F,n)
  mult[c(2:6,8)]=T # i.e. multiple states
  num = rep(F,n)
  num[c(1,10:11)]=T
  tochar = rep(F,n)
  tochar[c(7,9)]=T
  sel = mult & (target=="any" | target=="NA" | is.na(target))
  target[sel]=NA
  NAs = is.na(target)
  target[NAs]="" # i.e. empty, not part of query
  target[!NAs & mult] = stri_replace(target[!NAs & mult],"','",regex=",")
  target[!NAs & mult] = stri_replace(target[!NAs & mult]," %in% c('",regex="^")
  target[!NAs & mult] = stri_replace(target[!NAs & mult],"') ",regex="$")
  target[!NAs & mult] = paste(names(target)[!NAs & mult],target[!NAs & mult])
  target[!NAs & tochar] = paste0(names(target)[!NAs & tochar],"=='",target[!NAs & tochar],"'")
  target[num] = paste0(names(target)[num],"==",target[num])
  stri_join(target[target!=""],collapse=" & ")
}

read.targets = function(fname){
  df = read.csv(fname,header=T,stringsAsFactors = F, fileEncoding = 'UTF-8-BOM')
  assert_that(length(unique(df[,1]))==1,msg="a target file should contain only one country")
  df[,-1]  
}

calc.stock=function(z,target){
  q = stock.query.from.target(target)
  as.numeric(z[eval(parse(text=q)),.(value=sum(value))])
}

calc.flow=function(z,target,p=NULL){
  q = flow.query.from.target(target,p=p)
  as.numeric(z[eval(parse(text=q)),.(value=sum(value))])
}

calc.denominator=function(z,target,p=NULL){ 
  hivdead  = grepl("dead$",z$HIV,ignore.case = T) 
  tbdead   = grepl("dead$",z$TB,ignore.case = T) 
  riskdead = grepl("dead$",z$RISK,ignore.case = T) 
  y=z[!(hivdead | tbdead | riskdead),]
  q=denom.query.from.target(target,p=p)
  as.numeric(y[eval(parse(text=q)),.(value=sum(value))])
}


calc.targets = function(z,targets,round.to=2,p=NULL){
  model = rep(NA, nrow(targets))
  for (i in seq_along(targets[,1])){
    row = targets[i,]
    numrow = row[1:9]
    names(numrow)[3:9] = substring(names(numrow)[3:9],2)
    if (row$type == "stock"){
      num = calc.stock(z,row[1:7])
    }else if(row$type == "inflow"){
      calc.flow(z,numrow,p=p,T)
    }else if(row$type == "outflow"){
      calc.flow(z,numrow,p=p,F)
    }      
      
      
      
      model[i]  = 1e5*calc.prevalent.cases(z,row)/calc.denominator(z,row,p=p)
    }else if(row$subject == "prr"){
      rowhi = rowlo = row
      rowhi$SES = "high"
      rowlo$SES = "low"
      model[i]  = calc.prevalent.cases(z,rowhi)/calc.prevalent.cases(z,rowlo)
    }else if(!(is.na(row$subject) | row$subject == "")){
      print(row$subject)
      model[i] = 1e5*calc.incident.cases(z,row,p=p)/calc.denominator(z,row,p=p)
    }
  }
  fit = model >= targets$lo & model <= targets$hi
  residuals = model - targets$value
  weighted_residuals = residuals / targets$err
  cbind(targets,model=model,fit,residuals,weighted_residuals)
}

eval.output.vs.targets = function(output,targets,p=NULL){
  z = output$z
  sel=targets$year %in% unique(z$year)
  assert_that(sum(sel)==nrow(targets),msg="targets specified that are not in output, modify xml run file")
  # z$value = as.numeric(as.character(z$value))
  calc.targets(z,targets,p=p)
}

