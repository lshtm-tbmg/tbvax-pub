age.group.from.lower.age.limits = function(age.from,lower.age.limits){
  if (is.null(lower.age.limits)){
    age.group = rep("ALL",length(age.from))
  }else{
    lower=lower.age.limits
    upper=c(lower.age.limits[-1],200)
    age.group = rep(NA,length(age.from))
    for (i in seq_along(lower)){
      age.group[age.from %in% lower[i]:upper[i]]=paste0("A",lower[i])
    }
  }
  age.group
}

denom.query.from.target=function(target=NA, p=NULL){
  target = target[1:11]
  n = length(target)
  target[] = stri_replace(target,"",regex="[:space:]")
  subjects = unlist(strsplit(target$subject,","))
  allowed_subjects = c('Tm','Xi','Ti','prev',paste('Tr',names(p$Tr),sep="_"))
  assert_that(sum(subjects %in% allowed_subjects)==length(subjects), msg="undefined subject for inci or prev")
  mult = rep(F,n)
  mult[c(2:6)]=T # i.e. multiple states
  target[target$dim]=NA
  sel = mult & (target=="any" | target=="NA" | is.na(target))
  target[sel]=NA
  target[7:9]=paste0("is.na(",names(target)[7:9],")")
  NAs = is.na(target)
  target[NAs]=""
  target[!NAs & mult] = stri_replace(target[!NAs & mult],"','",regex=",")
  target[!NAs & mult] = stri_replace(target[!NAs & mult]," %in% c('",regex="^")
  target[!NAs & mult] = stri_replace(target[!NAs & mult],"') ",regex="$")
  target[!NAs & mult] = paste(names(target)[!NAs & mult],target[!NAs & mult])
  num = rep(F,n) ; num[c(1,10:11)]=T
  target[num] = paste0(names(target)[num],"==",target[num])
  stri_join(target[target!=""],collapse=" & ")
}

prev.query.from.target=function(target=NA){
  target = target[1:11]
  n = length(target)
  target[] = stri_replace(target,"",regex="[:space:]")
  assert_that(target$subject == 'prev' | target$subject == 'prr', msg="undefined subject for prevalence")
  assert_that(sum(is.na(target[-c(2:6,9)]))==0,msg="NAs not allowed except for columns 2:6 and 9")
  assert_that(is.na(target[9]),msg="column 9 should be NA for prev")
  mult = rep(F,n)
  mult[c(2:6)]=T # i.e. multiple states
  num = rep(F,n)
  num[c(1,10:11)]=T
  sel = mult & (target=="any" | target=="NA" | is.na(target))
  target[sel]=NA
  target[7:9]=paste0("is.na(",names(target)[7:9],")")
  NAs = is.na(target)
  target[NAs]="" 
  target[!NAs & mult] = stri_replace(target[!NAs & mult],"','",regex=",")
  target[!NAs & mult] = stri_replace(target[!NAs & mult]," %in% c('",regex="^")
  target[!NAs & mult] = stri_replace(target[!NAs & mult],"') ",regex="$")
  target[!NAs & mult] = paste(names(target)[!NAs & mult],target[!NAs & mult])
  target[num] = paste0(names(target)[num],"==",target[num])
  stri_join(target[target!=""],collapse=" & ")
}
inci.query.from.target=function(target=NA, p=NULL){
  target = target[1:11]
  n = length(target)
  target[] = stri_replace(target,"",regex="[:space:]")
  subjects = unlist(strsplit(target$subject,","))
  allowed_subjects = c('Tm','Xi','Ti',paste('Tr',names(p$Tr),sep="_"))
  assert_that(sum(subjects %in% allowed_subjects)==length(subjects), msg="undefined subject for incidence")
  assert_that(sum(is.na(target[-c(2:6)]))==0,msg="NA not allowed in columns except 2 thru 6")
  mult = rep(F,n)
  mult[c(2:6,8)]=T # i.e. multiple states
  num = rep(F,n)
  num[c(1,10:11)]=T
  tochar = rep(F,n)
  tochar[c(7,9)]=T
  sel = mult & (target=="any" | target=="NA" | is.na(target))
  target[sel]=NA
  NAs = is.na(target)
  target[NAs]="" # i.e. empty, not part of query
  target[!NAs & mult] = stri_replace(target[!NAs & mult],"','",regex=",")
  target[!NAs & mult] = stri_replace(target[!NAs & mult]," %in% c('",regex="^")
  target[!NAs & mult] = stri_replace(target[!NAs & mult],"') ",regex="$")
  target[!NAs & mult] = paste(names(target)[!NAs & mult],target[!NAs & mult])
  target[!NAs & tochar] = paste0(names(target)[!NAs & tochar],"=='",target[!NAs & tochar],"'")
  target[num] = paste0(names(target)[num],"==",target[num])
  stri_join(target[target!=""],collapse=" & ")
}
if (F){ # DO NOT USE THIS IS SLOW
paste.to.query=function(query,dim,state,any="any"){
  if (is.na(state)){
    if(is.null(query))
      return(paste("is.na(",dim,")"))
    else
      return(paste(query,"& is.na(",dim,")"))
  }
  if (sum(stri_cmp_eq(state,any))>0){
    return(query)
  }
  states = stri_trim_both(unlist(strsplit(state,",")))
  n = length(states)
  if (n>1){
    states = stri_join(states,collapse="','")
    q = paste0("c('",states,"')")
    if (is.null(query))
      return(paste(dim,"%in%",q))
    else
      return(paste(query,"&",dim,"%in%",q))
  }else{
    q = if (!(is.na(states)|states=="NA")){
      q = paste0("'",states,"'")
      if (is.null(query))
        return(paste(dim, "==",q))
      else
        return(paste(query,"&",dim, "==",q))
    }else{
      if (is.null(query))
        return(paste("is.na(",dim,")"))
      else
        return(paste(query,"& is.na(",dim,")"))
    }
  }
}
}

read.targets = function(fname){
  df = read.csv(fname,header=T,stringsAsFactors = F, fileEncoding = 'UTF-8-BOM')
  assert_that(length(unique(df[,1]))==1,msg="a target file should contain only one country")
  df[,-1]  
}

calc.prevalent.cases=function(z,target){
  q = prev.query.from.target(target)
  as.numeric(z[eval(parse(text=q)),.(value=sum(value))])
}

calc.incident.cases=function(z,target,p=NULL){
  q = inci.query.from.target(target,p=p)
  as.numeric(z[eval(parse(text=q)),.(value=sum(value))])
}

calc.denominator=function(z,target,p=NULL){ 
  hivdead  = grepl("dead$",z$HIV,ignore.case = T) 
  tbdead   = grepl("dead$",z$TB,ignore.case = T) 
  riskdead = grepl("dead$",z$RISK,ignore.case = T) 
  y=z[!(hivdead | tbdead | riskdead),]
  q=denom.query.from.target(target,p=p)
  as.numeric(y[eval(parse(text=q)),.(value=sum(value))])
}


calc.targets = function(z,targets,round.to=2,p=NULL){
  model = rep(NA, nrow(targets))
  for (i in seq_along(targets[,1])){
    row = targets[i,]
    if (row$subject == "prev"){
      model[i]  = 1e5*calc.prevalent.cases(z,row)/calc.denominator(z,row,p=p)
    }else if(row$subject == "prr"){
      rowhi = rowlo = row
      rowhi$SES = "high"
      rowlo$SES = "low"
      model[i]  = calc.prevalent.cases(z,rowhi)/calc.prevalent.cases(z,rowlo)
    }else if(!(is.na(row$subject) | row$subject == "")){
      model[i] = 1e5*calc.incident.cases(z,row,p=p)/calc.denominator(z,row,p=p)
    }
  }
  fit = model >= targets$lo & model <= targets$hi
  residuals = model - targets$value
  weighted_residuals = residuals / targets$err
  cbind(targets,model=round(model,round.to),fit,residuals,weighted_residuals)
}

eval.output.vs.targets = function(output,targets,p=NULL){
  z = output$z
  sel=targets$year %in% unique(z$year)
  assert_that(sum(sel)==nrow(targets),msg="targets specified that are not in output, modify xml run file")
  # z$value = as.numeric(as.character(z$value))
  calc.targets(z,targets,p=p)
}

